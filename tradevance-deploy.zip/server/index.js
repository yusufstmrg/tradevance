// ============================================================================
// TRADEVANCE — Local Node server entry point
// Runs the full Express app (56 API routes + static web/dist) on a real port.
// For Vercel serverless, use api/index.js instead (no listen needed).
// ============================================================================
import app from '../app.js';

const PORT = Number(process.env.PORT || 8787);

app.listen(PORT, () => {
  console.log(`\n🌐 Tradevance running → http://localhost:${PORT}`);
  console.log(`   API health → http://localhost:${PORT}/api/health\n`);
});
