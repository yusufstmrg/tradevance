// src/tradevance.ts
var MEM = {};
var memId = 0;
var LocalDB = class {
  prefix = "tvdb2:";
  table(name) {
    return this.prefix + name;
  }
  read(name) {
    try {
      return JSON.parse(localStorage.getItem(this.table(name)) || "[]");
    } catch {
      return [];
    }
  }
  write(name, rows) {
    try {
      localStorage.setItem(this.table(name), JSON.stringify(rows));
    } catch {
    }
  }
  async list(name, opts) {
    const rows = this.read(name);
    return { items: opts?.limit ? rows.slice(0, opts.limit) : rows };
  }
  async get(name, ids) {
    const rows = this.read(name);
    return ids.map((id) => rows.find((r) => String(r.id) === String(id)));
  }
  async add(name, rows) {
    const all = this.read(name);
    const out = [];
    for (const r of rows) {
      if (!r.id) r.id = "id-" + (++memId).toString(36) + "-" + Date.now().toString(36);
      if (!r.createdAt) r.createdAt = (/* @__PURE__ */ new Date()).toISOString();
      all.push(r);
      out.push(r.id);
    }
    this.write(name, all);
    return out;
  }
  async update(name, rows) {
    const all = this.read(name);
    const ok = [];
    for (const { id, record } of rows) {
      const i = all.findIndex((r) => String(r.id) === String(id));
      if (i >= 0) {
        all[i] = { ...all[i], ...record, id };
        ok.push(true);
      } else ok.push(false);
    }
    this.write(name, all);
    return ok;
  }
  async delete(name, ids) {
    const all = this.read(name);
    this.write(name, all.filter((r) => !ids.some((id) => String(id) === String(r.id))));
    return true;
  }
  async clear(name) {
    if (name) {
      try {
        localStorage.removeItem(this.table(name));
      } catch {
      }
      return;
    }
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(this.prefix)) keys.push(k);
    }
    keys.forEach((k) => {
      try {
        localStorage.removeItem(k);
      } catch {
      }
    });
  }
};
var MemoryDB = class {
  async list(name, opts) {
    const rows = MEM[name] || [];
    return { items: opts?.limit ? rows.slice(0, opts.limit) : rows };
  }
  async get(name, ids) {
    const rows = MEM[name] || [];
    return ids.map((id) => rows.find((r) => String(r.id) === String(id)));
  }
  async add(name, rows) {
    MEM[name] = MEM[name] || [];
    const out = [];
    for (const r of rows) {
      if (!r.id) r.id = "id-" + (++memId).toString(36) + "-" + Date.now().toString(36);
      if (!r.createdAt) r.createdAt = (/* @__PURE__ */ new Date()).toISOString();
      MEM[name].push(r);
      out.push(r.id);
    }
    return out;
  }
  async update(name, rows) {
    MEM[name] = MEM[name] || [];
    const ok = [];
    for (const { id, record } of rows) {
      const i = MEM[name].findIndex((r) => String(r.id) === String(id));
      if (i >= 0) {
        MEM[name][i] = { ...MEM[name][i], ...record, id };
        ok.push(true);
      } else ok.push(false);
    }
    return ok;
  }
  async delete(name, ids) {
    MEM[name] = (MEM[name] || []).filter((r) => !ids.some((id) => String(id) === String(r.id)));
    return true;
  }
  async clear(name) {
    if (name) {
      delete MEM[name];
      return;
    }
    Object.keys(MEM).forEach((k) => delete MEM[k]);
  }
};
function makeDB() {
  if (typeof window !== "undefined" && typeof localStorage !== "undefined") return new LocalDB();
  return new MemoryDB();
}
var SEED_ENTITIES = [
  { name: "Kamoto Copper Company S.A.", entityType: "Buyer", country: "DRC", products: ["Sulphur", "Granular Sulphur"], verificationLevel: "Trade Verified", confidence: 96, officialUrl: "https://www.kamotocoppercompany.com/en", evidence: [{ type: "Official website", claim: "Corporate and operations identity", sourceUrl: "https://www.kamotocoppercompany.com/en" }, { type: "Trade evidence", claim: "Volza reports 3,567 sulphur import shipments", sourceUrl: "https://www.volza.com/p/sulfur/buyers/" }], lastVerified: "2026-08-20", notes: "Trade activity supports buyer classification." },
  { name: "Tenke Fungurume Mining", entityType: "Buyer", country: "DRC", products: ["Sulphur", "Sulphur compounds"], verificationLevel: "Trade Verified", confidence: 97, officialUrl: "https://www.tfmofficial.com/en/operations/mines", evidence: [{ type: "Official website", claim: "Mining operations identity", sourceUrl: "https://www.tfmofficial.com/en/operations/mines" }, { type: "Trade evidence", claim: "Volza reports 3,133 sulphur import shipments", sourceUrl: "https://www.volza.com/p/sulfur/buyers/" }], lastVerified: "2026-08-20", notes: "Strong buyer signal." },
  { name: "PT Inti Alam Kimia", entityType: "Buyer", country: "Indonesia", products: ["Activated Carbon", "Industrial Chemicals"], verificationLevel: "Evidence-backed", confidence: 89, officialUrl: "https://www.intialamkimia.com/", evidence: [{ type: "Official website", claim: "Public corporate website", sourceUrl: "https://www.intialamkimia.com/" }, { type: "Trade evidence", claim: "Listed among Indonesia activated-carbon buyers", sourceUrl: "https://www.volza.com/p/active-carbon/buyers/buyers-in-indonesia/hsn-code-3802/" }], lastVerified: "2026-08-20", notes: "Relevant Indonesian buyer lead." },
  { name: "PT Sinarkimia Utama", entityType: "Buyer", country: "Indonesia", products: ["Activated Carbon", "Industrial Chemicals"], verificationLevel: "Evidence-backed", confidence: 88, officialUrl: "https://www.pt-sku.com/", evidence: [{ type: "Official website", claim: "Chemical distribution company", sourceUrl: "https://www.pt-sku.com/" }, { type: "Trade evidence", claim: "Listed among Indonesia activated-carbon buyers", sourceUrl: "https://www.volza.com/p/active-carbon/buyers/buyers-in-indonesia/hsn-code-3802/" }], lastVerified: "2026-08-20", notes: "Relevant Indonesian buyer/distributor lead." },
  { name: "Haycarb PLC", entityType: "Seller", country: "Sri Lanka", products: ["Activated Carbon"], verificationLevel: "Source Verified", confidence: 95, officialUrl: "https://www.haycarb.com/", evidence: [{ type: "Official website", claim: "Global activated carbon manufacturer", sourceUrl: "https://www.haycarb.com/" }], lastVerified: "2026-08-20", notes: "Strong producer identity." },
  { name: "Birla Carbon", entityType: "Seller", country: "Global", products: ["Carbon Black"], verificationLevel: "Source Verified", confidence: 96, officialUrl: "https://www.birlacarbon.com/about/", evidence: [{ type: "Official website", claim: "Global carbon black producer", sourceUrl: "https://www.birlacarbon.com/about/" }], lastVerified: "2026-08-20", notes: "Strong global producer identity." },
  { name: "OQ Trading", entityType: "Seller", country: "Oman / Global", products: ["Sulphur", "Urea", "Diesel", "Jet Fuel"], verificationLevel: "Source Verified", confidence: 98, officialUrl: "https://oq.com/en", evidence: [{ type: "Official company source", claim: "OQ Trading supplies sulphur, urea and petroleum products internationally", sourceUrl: "https://oq.com/en" }], lastVerified: "2026-08-20", notes: "Strong supplier/trading-house identity." },
  { name: "Jacobi Group", entityType: "Seller", country: "Global", products: ["Activated Carbon"], verificationLevel: "Source Verified", confidence: 98, officialUrl: "https://www.jacobi.net/", evidence: [{ type: "Official company source", claim: "World largest coconut-shell activated carbon manufacturer", sourceUrl: "https://www.jacobi.net/about/" }], lastVerified: "2026-08-20", notes: "Strong manufacturer identity." },
  { name: "Westlake Corporation", entityType: "Seller", country: "USA / Global", products: ["Caustic Soda", "Chlor-alkali"], verificationLevel: "Source Verified", confidence: 98, officialUrl: "https://www.westlake.com/chlorovinyls/chlorinechlor-alkali", evidence: [{ type: "Official company source", claim: "Second-largest chlor-alkali producer globally", sourceUrl: "https://www.westlake.com/chlorovinyls/chlorinechlor-alkali" }], lastVerified: "2026-08-20", notes: "Strong producer identity." },
  { name: "INEOS Chemicals", entityType: "Seller", country: "Global", products: ["Caustic Soda", "Chlor-alkali"], verificationLevel: "Source Verified", confidence: 97, officialUrl: "https://www.ineos.com/industry/products/chemicals/caustic-soda/", evidence: [{ type: "Official company source", claim: "INEOS produces liquid and solid caustic soda", sourceUrl: "https://www.ineos.com/industry/products/chemicals/caustic-soda/" }], lastVerified: "2026-08-20", notes: "Strong producer identity." },
  { name: "Tata Chemicals", entityType: "Seller", country: "India / Global", products: ["Industrial Salt", "Caustic Soda"], verificationLevel: "Source Verified", confidence: 95, officialUrl: "https://www.tatachemicals.com/", evidence: [{ type: "Official company source", claim: "Tata Chemicals lists salt and caustic soda", sourceUrl: "https://www.tatachemicals.com/" }], lastVerified: "2026-08-20", notes: "Strong corporate identity." },
  { name: "Tasnim Chemical Complex Ltd", entityType: "Seller", country: "Bangladesh", products: ["Caustic Soda", "Hydrogen Peroxide", "Chlorine"], verificationLevel: "Trade Verified", confidence: 96, officialUrl: "https://www.mgi.org/businessverticals/basic-chemicals", evidence: [{ type: "Official company source", claim: "MGI states TCCL exports to 28 countries", sourceUrl: "https://www.mgi.org/businessverticals/basic-chemicals" }, { type: "Government registry", claim: "Bangladesh EPB registered exporter", sourceUrl: "https://edb.epb.gov.bd/exporter/3999/tasnim-chemical-complex-ltd" }], lastVerified: "2026-08-20", notes: "Strong manufacturer/exporter evidence." },
  { name: "Sailun Vietnam Co Ltd", entityType: "Buyer", country: "Vietnam", products: ["Carbon Black", "Rubber raw materials"], verificationLevel: "Trade Verified", confidence: 97, officialUrl: "https://sailun.tires/", evidence: [{ type: "Official website", claim: "Sailun Vietnam tire manufacturing", sourceUrl: "https://sailun.tires/" }, { type: "Trade evidence", claim: "2,828 carbon black shipments", sourceUrl: "https://www.volza.com/p/carbon-black/buyers/hsn-code-28030041/" }], lastVerified: "2026-08-20", notes: "High-confidence buyer signal." },
  { name: "Jinyu Vietnam Tire Co Ltd", entityType: "Buyer", country: "Vietnam", products: ["Carbon Black", "Rubber raw materials"], verificationLevel: "Trade Verified", confidence: 96, officialUrl: "https://www.jinyutiresgroup.com/", evidence: [{ type: "Official website", claim: "Jinyu global manufacturing network", sourceUrl: "https://www.jinyutiresgroup.com/" }, { type: "Trade evidence", claim: "1,309 carbon black shipments", sourceUrl: "https://www.volza.com/p/carbon-black/buyers/hsn-code-28030041/" }], lastVerified: "2026-08-20", notes: "High-confidence buyer signal." },
  { name: "MRF Limited", entityType: "Buyer", country: "India", products: ["Carbon Black", "Rubber raw materials"], verificationLevel: "Trade Verified", confidence: 96, officialUrl: "https://www.mrftyres.com/", evidence: [{ type: "Official website", claim: "Indian multinational tyre manufacturer", sourceUrl: "https://www.mrftyres.com/" }, { type: "Trade evidence", claim: "1,987 black carbon import shipments", sourceUrl: "https://www.volza.com/p/black-carbon/buyers/hsn-code-28030010/" }], lastVerified: "2026-08-20", notes: "High-confidence industrial buyer signal." },
  { name: "Michelin Lanka Private Limited", entityType: "Buyer", country: "Sri Lanka", products: ["Carbon Black", "Rubber raw materials"], verificationLevel: "Trade Verified", confidence: 95, officialUrl: "https://www.michelin.com/en/", evidence: [{ type: "Official website", claim: "Michelin global group", sourceUrl: "https://www.michelin.com/en/" }, { type: "Trade evidence", claim: "1,699 black carbon import shipments", sourceUrl: "https://www.volza.com/p/black-carbon/buyers/hsn-code-280300/" }], lastVerified: "2026-08-20", notes: "High-confidence buyer signal." },
  { name: "Goodyear de Chile S.A.I.C.", entityType: "Buyer", country: "Chile", products: ["Carbon Black", "Rubber raw materials"], verificationLevel: "Trade Verified", confidence: 96, officialUrl: "https://www.goodyear.cl/informacion-corporativa", evidence: [{ type: "Official website", claim: "Goodyear Chile corporate site", sourceUrl: "https://www.goodyear.cl/informacion-corporativa" }, { type: "Trade evidence", claim: "1,473 carbon black bag import shipments", sourceUrl: "https://www.volza.com/p/carbon-black-bags/buyers/buyers-in-chile/" }], lastVerified: "2026-08-20", notes: "High-confidence buyer signal." },
  { name: "Bidco Uganda Ltd", entityType: "Buyer", country: "Uganda", products: ["Caustic Soda", "Industrial Chemicals"], verificationLevel: "Trade Verified", confidence: 97, officialUrl: "https://bul.co.ug/", evidence: [{ type: "Official website", claim: "Integrated Ugandan agribusiness", sourceUrl: "https://bul.co.ug/" }, { type: "Trade evidence", claim: "1,023 caustic soda import shipments", sourceUrl: "https://www.volza.com/p/caustic-soda/buyers/" }], lastVerified: "2026-08-20", notes: "High-confidence caustic soda buyer signal." },
  { name: "Yara East Africa Ltd", entityType: "Buyer", country: "Kenya / Uganda", products: ["Industrial Chemicals", "Fertilizer inputs"], verificationLevel: "Trade Verified", confidence: 92, officialUrl: "https://www.yara.co.ke/", evidence: [{ type: "Official website", claim: "Yara East Africa imports and distributes fertilizer", sourceUrl: "https://www.yara.co.ke/" }, { type: "Trade evidence", claim: "156 caustic/potash import shipments", sourceUrl: "https://www.volza.com/p/caustic-or-potash/buyers/" }], lastVerified: "2026-08-20", notes: "Category-adjacent trade evidence." },
  { name: "Mosaic Fertilizantes do Brasil Ltda", entityType: "Buyer", country: "Brazil", products: ["Industrial Chemicals", "Fertilizer inputs"], verificationLevel: "Trade Verified", confidence: 91, officialUrl: "https://mosaicco.com.br/Fertilizantes", evidence: [{ type: "Official website", claim: "Mosaic Brazil fertilizer business", sourceUrl: "https://mosaicco.com.br/Fertilizantes" }, { type: "Trade evidence", claim: "375 caustic/potash import shipments", sourceUrl: "https://www.volza.com/p/caustic-or-potash/buyers/" }], lastVerified: "2026-08-20", notes: "Category-adjacent trade evidence." }
];
var SEED_TRADES = [
  { id: "TRD-2026-0084", product: "Sulphur", buyer: "PT Indo Fertilizer", supplier: "Gulf Sulphur Trading", qty: 5e4, value: 3075e4, status: "Negotiation", risk: 22, ownerUserId: "operator", documents: ["SO draft"] },
  { id: "TRD-2026-0083", product: "Caustic Soda", buyer: "ABC Chemical Ltd", supplier: "Sino Alkali Materials", qty: 25e3, value: 12875e3, status: "In Transit", risk: 18, ownerUserId: "operator" },
  { id: "TRD-2026-0082", product: "Carbon Black", buyer: "Global Tires Inc.", supplier: "BlackCarbon Materials", qty: 15e3, value: 945e4, status: "Contracted", risk: 27, ownerUserId: "operator" },
  { id: "TRD-2026-0081", product: "Industrial Salt", buyer: "PT Garam Indonesia", supplier: "East Africa Industrial", qty: 3e4, value: 36e5, status: "Delivered", risk: 11, ownerUserId: "operator" }
];
var SEED_DEMANDS = [
  { id: "RFQ-2026-001", buyer: "PT Indo Fertilizer", product: "Sulphur", quantity: 5e4, unit: "MT", destination: "Tanga, Tanzania", incoterm: "CIF", payment: "Confirmed DLC at sight", status: "Open", ownerUserId: "operator" },
  { id: "RFQ-2026-002", buyer: "ABC Chemical Ltd", product: "Caustic Soda", quantity: 3e4, unit: "MT", destination: "Mombasa, Kenya", incoterm: "CIF", payment: "LC at sight", status: "Matching", ownerUserId: "operator" },
  { id: "RFQ-2026-003", buyer: "WaterPure Ltd", product: "Activated Carbon", quantity: 1e4, unit: "MT", destination: "Lagos, Nigeria", incoterm: "CIF", payment: "LC at sight", status: "Open", ownerUserId: "operator" }
];
var SEED_SUPPLIERS = [
  { id: "sup-01", name: "Gulf Sulphur Trading LLC", country: "UAE", products: ["Sulphur"], score: 94, capacity: "250,000 MT/yr", port: "Jebel Ali", verified: "Trade verified", risk: "Low" },
  { id: "sup-02", name: "Middle East Chemical Industries", country: "Saudi Arabia", products: ["Sulphur", "Caustic Soda"], score: 91, capacity: "180,000 MT/yr", port: "Jubail", verified: "Document verified", risk: "Low" },
  { id: "sup-03", name: "Sino Alkali Materials Co.", country: "China", products: ["Caustic Soda", "Industrial Salt"], score: 88, capacity: "300,000 MT/yr", port: "Qingdao", verified: "Document verified", risk: "Medium" },
  { id: "sup-04", name: "Coconut Carbon Industries", country: "Indonesia", products: ["Activated Carbon"], score: 96, capacity: "35,000 MT/yr", port: "Surabaya", verified: "Transaction verified", risk: "Low" },
  { id: "sup-05", name: "BlackCarbon Materials Ltd.", country: "India", products: ["Carbon Black"], score: 89, capacity: "120,000 MT/yr", port: "Mundra", verified: "Trade verified", risk: "Low" },
  { id: "sup-06", name: "East Africa Industrial Minerals", country: "Tanzania", products: ["Industrial Salt"], score: 84, capacity: "80,000 MT/yr", port: "Dar es Salaam", verified: "Document verified", risk: "Medium" }
];
var SEED_BUYERS = [
  { id: "buy-01", name: "PT Indo Fertilizer", country: "Indonesia", industry: "Fertilizer / Agriculture", activeDemands: 1, credit: "Trade evidence" },
  { id: "buy-02", name: "ABC Chemical Ltd", country: "Kenya", industry: "Industrial Chemicals", activeDemands: 1, credit: "Trade evidence" },
  { id: "buy-03", name: "WaterPure Ltd", country: "Nigeria", industry: "Water Treatment", activeDemands: 1, credit: "Trade evidence" },
  { id: "buy-04", name: "Global Tires Inc.", country: "USA", industry: "Tire Manufacturing", activeDemands: 2, credit: "Trade evidence" },
  { id: "buy-05", name: "PT Garam Indonesia", country: "Indonesia", industry: "Salt / FMCG", activeDemands: 1, credit: "Trade evidence" }
];
var COMMODITIES = [
  { name: "Sulphur", aliases: ["sulphur", "sulfur", "granular sulphur"], hs: "2503", unit: "MT", category: "Industrial Chemicals" },
  { name: "Caustic Soda", aliases: ["caustic soda", "sodium hydroxide", "naoh"], hs: "2815", unit: "MT", category: "Industrial Chemicals" },
  { name: "Activated Carbon", aliases: ["activated carbon", "active carbon"], hs: "3802", unit: "MT", category: "Industrial Chemicals" },
  { name: "Industrial Salt", aliases: ["industrial salt", "salt", "sodium chloride"], hs: "2501", unit: "MT", category: "Minerals" },
  { name: "Carbon Black", aliases: ["carbon black", "black carbon"], hs: "2803", unit: "MT", category: "Industrial Chemicals" },
  { name: "Coal", aliases: ["coal", "steam coal", "thermal coal"], hs: "2701", unit: "MT", category: "Energy" },
  { name: "EN590 Diesel", aliases: ["en590", "diesel", "gas oil"], hs: "2710", unit: "MT", category: "Energy" },
  { name: "Fuel Oil", aliases: ["fuel oil", "hfo"], hs: "2710", unit: "MT", category: "Energy" },
  { name: "Jet Fuel", aliases: ["jet fuel", "jet a1"], hs: "2710", unit: "MT", category: "Energy" },
  { name: "CPO", aliases: ["cpo", "crude palm oil", "palm oil"], hs: "1511", unit: "MT", category: "Agriculture" },
  { name: "UCO", aliases: ["uco", "used cooking oil"], hs: "1518", unit: "MT", category: "Agriculture" },
  { name: "Sugar", aliases: ["sugar", "raw sugar", "white sugar"], hs: "1701", unit: "MT", category: "Agriculture" },
  { name: "Soybean", aliases: ["soybean", "soya bean", "soy"], hs: "1201", unit: "MT", category: "Agriculture" },
  { name: "Copper Cathode", aliases: ["copper cathode", "copper"], hs: "7403", unit: "MT", category: "Metals & Minerals" },
  { name: "Nickel", aliases: ["nickel", "nickel ore", "npi"], hs: "7502", unit: "MT", category: "Metals & Minerals" },
  { name: "Iron Ore", aliases: ["iron ore", "iron"], hs: "2601", unit: "MT", category: "Metals & Minerals" },
  { name: "Silica Sand", aliases: ["silica sand", "quartz sand"], hs: "2505", unit: "MT", category: "Metals & Minerals" },
  { name: "Urea", aliases: ["urea", "fertilizer"], hs: "3102", unit: "MT", category: "Agriculture" }
];
function resolveCommodity(text) {
  const t = String(text || "").toLowerCase();
  return COMMODITIES.find((c) => c.aliases.some((a) => t.includes(a)));
}
var CACHE = {};
var TTL = 4 * 60 * 60 * 1e3;
async function cachedFetch(key, ttl, fn) {
  const hit = CACHE[key];
  if (hit && Date.now() - hit.at < ttl) return hit.data;
  try {
    const data = await fn();
    CACHE[key] = { at: Date.now(), data };
    return data;
  } catch {
    return hit ? hit.data : null;
  }
}
async function fetchFxRates(base = "USD") {
  return cachedFetch("fx:" + base, TTL, async () => {
    const r = await fetch(`https://api.frankfurter.app/latest?from=${encodeURIComponent(base)}&to=IDR,EUR,CNY,SGD,MYR,JPY,INR,GBP,AED,SAR,BDT,KES,NGN,VND,BRL,ZAR,RUB,KRW,PKR,EGP`);
    if (!r.ok) return null;
    const j = await r.json();
    return j.rates || null;
  });
}
var FX_FALLBACK = { IDR: 17737, EUR: 0.85874, CNY: 6.7203, SGD: 1.2713, MYR: 4.033, JPY: 141.5, INR: 86.4, GBP: 0.728, AED: 3.6725, SAR: 3.75, BDT: 121.5, KES: 129.8, NGN: 1620, VND: 25400, BRL: 5.62, ZAR: 18.2, RUB: 92.5, KRW: 1330, PKR: 278.5, EGP: 48.9 };
async function getFxRates() {
  const live = await fetchFxRates("USD");
  return live && Object.keys(live).length ? live : FX_FALLBACK;
}
var COMMODITY_PRICE_BASELINE = {
  Sulphur: 165,
  Caustic_Soda: 385,
  Activated_Carbon: 1450,
  Industrial_Salt: 85,
  Carbon_Black: 1250,
  Coal: 130,
  EN590_Diesel: 785,
  Fuel_Oil: 470,
  Jet_Fuel: 815,
  CPO: 985,
  UCO: 870,
  Sugar: 435,
  Soybean: 415,
  Copper_Cathode: 9350,
  Nickel: 15200,
  Iron_Ore: 108,
  Silica_Sand: 42,
  Urea: 355
};
function commodityPrice(commodity) {
  return COMMODITY_PRICE_BASELINE[commodity] || 100;
}
async function fetchComtradeFlow(commodity, reporterCode = "360") {
  const com = resolveCommodity(commodity);
  if (!com) return null;
  return cachedFetch("comtrade:" + com.hs + ":" + reporterCode, TTL * 6, async () => {
    const url = `https://comtradeapi.un.org/public/v1/preview/C/A/HS?period=2024&reporterCode=${reporterCode}&cmdCode=${com.hs}`;
    const r = await fetch(url);
    if (!r.ok) return null;
    const j = await r.json();
    if (!j || !Array.isArray(j.data)) return null;
    const byFlow = {};
    for (const row of j.data) {
      const flow = row.flowCode === "M" ? "import" : row.flowCode === "X" ? "export" : "other";
      const val = Number(row.primaryValue || 0);
      byFlow[flow] = (byFlow[flow] || 0) + val;
      byFlow["qty_" + flow] = (byFlow["qty_" + flow] || 0) + Number(row.qty || 0);
    }
    return { commodity, hsCode: com.hs, period: "2024", reporterCode, flows: byFlow, source: "UN Comtrade public API", fetchedAt: (/* @__PURE__ */ new Date()).toISOString() };
  });
}
async function fetchWorldBankCountry(code) {
  return cachedFetch("wb:" + code, TTL * 24, async () => {
    const r = await fetch(`https://api.worldbank.org/v2/country/${encodeURIComponent(code)}?format=json`);
    if (!r.ok) return null;
    const j = await r.json();
    if (!Array.isArray(j) || !j[1] || !j[1][0]) return null;
    const c = j[1][0];
    return { code: c.id, name: c.name, region: c.region?.value, incomeLevel: c.incomeLevel?.value, capitalCity: c.capitalCity, latitude: c.latitude, longitude: c.longitude };
  });
}
function fuzzyTokens(text) {
  return String(text || "").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").split(" ").filter((t) => t.length >= 3);
}
function tokenOverlap(a, b) {
  const ta = new Set(fuzzyTokens(a));
  const tb = new Set(fuzzyTokens(b));
  if (!ta.size || !tb.size) return 0;
  let hit = 0;
  ta.forEach((t) => {
    if (tb.has(t)) hit++;
  });
  return hit / Math.max(ta.size, tb.size);
}
function parseDemand(text) {
  const t = String(text || "").toLowerCase();
  const com = resolveCommodity(t);
  const product = com ? com.name : "Industrial Raw Material";
  const qm = t.match(/([\d,.]+)\s*(mt|ton|tons|tonnes|kg|t)\b/i);
  let quantity = 0;
  if (qm) {
    quantity = Number(qm[1].replace(/,/g, ""));
    if (/kg\b/.test(qm[2])) quantity = quantity / 1e3;
  }
  const incoterm = (t.match(/\b(cif|fob|cfr|dap|ddp|exw|fca|cip)\b/i)?.[1] || "CIF").toUpperCase();
  const payment = t.includes("dlc") ? "Confirmed DLC at sight" : t.includes("lc") ? "LC at sight" : t.includes("tt") || t.includes("telegraphic") ? "T/T" : "To be negotiated";
  const destMap = [
    ["tanga", "Tanga, Tanzania"],
    ["mombasa", "Mombasa, Kenya"],
    ["lagos", "Lagos, Nigeria"],
    ["jakarta", "Jakarta, Indonesia"],
    ["surabaya", "Surabaya, Indonesia"],
    ["dubai", "Jebel Ali, UAE"],
    ["jeddah", "Jeddah, Saudi Arabia"],
    ["chittagong", "Chittagong, Bangladesh"],
    ["ho chi minh", "Ho Chi Minh City, Vietnam"],
    ["manila", "Manila, Philippines"],
    ["dhaka", "Dhaka, Bangladesh"],
    ["nairobi", "Nairobi, Kenya"],
    ["kampala", "Kampala, Uganda"],
    ["sao paulo", "Santos, Brazil"],
    ["rio", "Rio de Janeiro, Brazil"],
    ["santiago", "San Antonio, Chile"]
  ];
  let destination = "Destination to confirm";
  for (const [k, v] of destMap) if (t.includes(k)) {
    destination = v;
    break;
  }
  const window2 = t.match(/\b(september|october|november|december|january|february|march|april|may|june|july|august)\b/i)?.[1] || "";
  const delivery = window2 ? `Target delivery: ${window2.charAt(0).toUpperCase() + window2.slice(1)} 2026` : "Target delivery window to confirm";
  const quality = t.includes("granular") ? "Granular" : t.includes("prilled") ? "Prilled" : t.includes("flakes") || t.includes("flake") ? "Flakes" : t.includes("powder") ? "Powder" : "Commercial specification to confirm";
  const confidence = Math.min(98, Math.round(72 + (com ? 18 : 0) + (quantity > 0 ? 6 : 0) + (incoterm !== "CIF" ? 2 : 0)));
  return { product, quantity, unit: "MT", destination, incoterm, payment, delivery, quality, confidence };
}
function capacityNumber(v) {
  const n = Number(String(v || "").replace(/[^0-9.]/g, ""));
  const low = String(v || "").toLowerCase();
  return low.includes("m") ? n * 1e6 : low.includes("k") ? n * 1e3 : n * 1e3;
}
function matchSuppliers(demand, suppliers, opts) {
  const rows = suppliers.map((s) => {
    const products = Array.isArray(s.products) ? s.products : [];
    const product = products.some((p) => p.toLowerCase().includes(String(demand.product).toLowerCase().split(" ")[0]));
    const cap = capacityNumber(String(s.capacity || "0"));
    const qty = Number(demand.quantity || 0);
    const trust = Math.min(15, (Number(s.score) || 0) / 100 * 15);
    const riskPts = s.risk === "Low" ? 10 : s.risk === "Medium" ? 6 : 2;
    const verifiedPts = /trade verified|transaction verified/i.test(String(s.verified || "")) ? 4 : /document verified|source verified/i.test(String(s.verified || "")) ? 2 : 0;
    let matchScore = Math.round(Math.min(
      100,
      (product ? 55 : 0) + (qty > 0 && cap >= qty ? 15 : qty > 0 ? Math.max(0, 15 * (cap / qty)) : 8) + trust + riskPts + verifiedPts + 2
    ));
    const reasons = [];
    if (product) reasons.push("Product fit");
    if (qty > 0 && cap >= qty) reasons.push("Capacity fit");
    else if (qty > 0) reasons.push("Partial capacity fit");
    if (Number(s.score) >= 90) reasons.push("High trust");
    if (s.risk === "Low") reasons.push("Low risk");
    if (verifiedPts >= 4) reasons.push("Trade-level verification");
    if (!reasons.length) reasons.push("General eligibility");
    return { supplier: s, matchScore, reasons };
  });
  return rows.sort((a, b) => b.matchScore - a.matchScore).slice(0, opts?.limit || 10);
}
function evaluateRisk(p, context = {}) {
  const reasons = [];
  let score = 100;
  if (p.verificationStatus !== "verified" && p.role !== "operator") {
    score -= 40;
    reasons.push("Buyer/Seller verification is incomplete");
  }
  const screening = context.screening || { status: "PRE_SCREEN_CLEAR" };
  if (screening.status === "MATCH_BLOCKED") {
    score = 0;
    reasons.push("Official sanctions pre-screen produced a match requiring block");
  } else if (screening.status === "POTENTIAL_MATCH_REVIEW") {
    score -= 35;
    reasons.push("Official sanctions pre-screen requires manual review");
  } else if (screening.status === "SCREENING_UNAVAILABLE") {
    score -= 60;
    reasons.push("Official sanctions screening is unavailable or stale");
  }
  const trust = Number(context.trustScore || 0);
  if (trust > 0) {
    score -= Math.max(0, 100 - trust) * 0.35;
    if (trust < 85) reasons.push("Trust Graph evidence is below the preferred threshold");
  } else if (context.requireTrust) {
    score -= 18;
    reasons.push("No canonical Trust Graph entity was resolved");
  }
  if (!String(p.country || "").trim()) {
    score -= 8;
    reasons.push("Jurisdiction/country is incomplete");
  }
  const value = Number(context.transactionValue || 0);
  if (value > 5e6 && Number(context.evidenceDepth || 3) < 3) {
    score -= 12;
    reasons.push("High-value context requires deeper evidence");
  }
  if (value > 2e7 && trust < 90 && trust > 0) {
    score -= 8;
    reasons.push("High-value context requires stronger trust evidence");
  }
  const product = String(context.product || "").toLowerCase();
  if (["diesel", "jet fuel", "caustic soda", "sulphur", "ammonia", "chlorine"].some((x) => product.includes(x))) {
    score -= 4;
    reasons.push("Special-handling commodity policy flag");
  }
  if (!context.destination) {
    score -= 6;
    reasons.push("Destination is missing or unconfirmed");
  }
  if (!context.incoterm) {
    score -= 6;
    reasons.push("Incoterm is missing or unconfirmed");
  }
  const payment = String(context.payment || "").toLowerCase();
  if (!payment) {
    score -= 8;
    reasons.push("Payment terms are not stated");
  } else if (payment.includes("to be negotiated") || payment.includes("open account")) {
    score -= 5;
    reasons.push("Payment terms require additional counterparty/finance review");
  }
  const docs = Array.isArray(context.documents) ? context.documents.length : 0;
  if (["quote", "trade"].includes(String(context.dealType)) && docs === 0) {
    score -= 5;
    reasons.push("No transaction-document evidence is attached yet");
  }
  score = Math.max(0, Math.min(100, Math.round(score)));
  let decision;
  if (screening.status !== "PRE_SCREEN_CLEAR" || p.verificationStatus !== "verified" && p.role !== "operator" || score < 60) decision = "BLOCK";
  else if (score < 80 || value > 5e6) decision = "REVIEW";
  else decision = "ALLOW";
  if (!reasons.length) reasons.push("Risk checks cleared");
  return { decision, riskScore: score, reasons };
}
function trustScoreFor(e) {
  const evidence = Array.isArray(e.evidence) ? e.evidence : [];
  const types = new Set(evidence.map((x) => x.type).filter(Boolean));
  const identity = (e.name && e.country ? 12 : 6) + (e.officialUrl ? 8 : 0);
  const evidenceScore = Math.min(25, evidence.length * 7 + types.size * 3);
  const v = String(e.verificationLevel || "").toLowerCase();
  const verification = v.includes("fully kyb") ? 20 : v.includes("trade verified") ? 18 : v.includes("evidence-backed") ? 15 : v.includes("source verified") ? 12 : 5;
  const days = Math.max(0, Math.floor((Date.now() - Date.parse(e.lastVerified || "")) / 864e5));
  const freshness = days <= 30 ? 10 : days <= 90 ? 6 : days <= 180 ? 3 : 0;
  const corroboration = Math.min(10, (types.size >= 2 ? 6 : 3) + (evidence.length >= 3 ? 4 : 0));
  const trustScore = Math.round(Math.min(100, identity + evidenceScore + verification + freshness + corroboration + 5));
  const riskBand = trustScore >= 85 ? "Low" : trustScore >= 70 ? "Medium" : "High";
  const reasons = [];
  if (identity >= 18) reasons.push("Strong identity");
  if (evidenceScore >= 18) reasons.push("Multiple evidence");
  if (verification >= 18) reasons.push("Trade-level verification");
  if (freshness >= 10) reasons.push("Fresh evidence");
  if (!reasons.length) reasons.push("Limited evidence");
  return { ...e, trustScore, riskBand, evidenceDepth: evidence.length, freshnessDays: days, reasons };
}
function buildOpportunities(demands, entities) {
  const sellers = entities.filter((x) => x.entityType === "Seller");
  const out = [];
  for (const d of demands) {
    if (!d.product) continue;
    const matched = sellers.filter((s) => (s.products || []).some((p) => p.toLowerCase().includes(String(d.product).toLowerCase().split(" ")[0])));
    for (const s of matched.slice(0, 6)) {
      const trust = Number(s.confidence || 70);
      const qty = Number(d.quantity || 0);
      const score = Math.round(Math.min(100, Math.max(0, trust * 0.65 + (qty > 0 ? 18 : 8) + (d.incoterm ? 8 : 0) + (d.payment ? 6 : 0))));
      out.push({
        id: "live-" + d.id + "-" + s.id,
        sourceDemandId: d.id,
        product: d.product,
        buyer: d.buyer || "Verified buyer account",
        supplier: s.name,
        origin: s.country || "To confirm",
        destination: d.destination || "To confirm",
        quantity: qty,
        estimatedValue: qty * commodityPrice(d.product),
        opportunityScore: score,
        trust,
        supplyFit: trust,
        demandStrength: d.confidence || 70,
        risk: Math.max(5, 100 - trust),
        reasons: ["Live RFQ record", "Evidence-backed supplier profile", d.incoterm ? "Incoterm specified" : "Incoterm pending"]
      });
    }
  }
  return out.sort((a, b) => b.opportunityScore - a.opportunityScore).slice(0, 30);
}
function normalizeQuotes(raw, product, targetPrice) {
  const normalized = raw.map((q, i) => {
    const supplier = String(q.supplier || "").trim().slice(0, 160) || `Quote ${i + 1}`;
    const price = Number(q.price), freight = Number(q.freight || 0), insurance = Number(q.insurance || 0);
    const landedCost = price + freight + insurance;
    const flags = [];
    if (!Number.isFinite(price) || price <= 0) flags.push("Invalid base price");
    if (freight < 0 || insurance < 0) flags.push("Invalid logistics cost");
    if (!q.payment) flags.push("Payment term missing");
    if (!q.incoterm) flags.push("Incoterm missing");
    return { supplier, product: String(q.product || product), currency: String(q.currency || "USD"), unit: String(q.unit || "MT"), price: Number.isFinite(price) ? price : 0, freight: Number.isFinite(freight) && freight >= 0 ? freight : 0, insurance: Number.isFinite(insurance) && insurance >= 0 ? insurance : 0, payment: String(q.payment || ""), incoterm: String(q.incoterm || ""), leadTime: String(q.leadTime || ""), landedCost: Number.isFinite(landedCost) ? landedCost : 0, flags };
  });
  const valid = normalized.filter((q) => q.price > 0 && q.freight >= 0 && q.insurance >= 0);
  if (!valid.length) return { normalized, best: null, negotiation: "At least one quote must contain a valid base price." };
  const best = valid.reduce((a, b) => b.landedCost < a.landedCost ? b : a);
  const target = Number.isFinite(targetPrice) && targetPrice > 0 ? targetPrice : null;
  const deltaPercent = target === null ? null : Number(((best.landedCost - target) / target * 100).toFixed(2));
  let negotiation;
  if (best.flags.length) negotiation = "Close the evidence gaps before award: " + best.flags.join(", ") + ".";
  else if (target === null) negotiation = "Use the best landed-cost quote as the commercial baseline, then verify payment, Incoterms, lead time and documentary readiness before award.";
  else if (deltaPercent <= 0) negotiation = "Best quote is at or below target landed cost. Preserve competitive tension and confirm allocation, payment instrument and execution readiness before award.";
  else negotiation = "Best quote is above target landed cost by " + Math.abs(deltaPercent) + "%. Use freight, price, payment and allocation levers in negotiation before moving to approval.";
  return { normalized, best: { ...best, deltaPercent }, negotiation };
}
var SANCTIONS_SOURCES = [
  { id: "ofac", name: "OFAC Sanctions List Service", jurisdiction: "US", url: "https://ofac.treasury.gov/sanctions-list-service" },
  { id: "unsc", name: "UN Security Council Consolidated List", jurisdiction: "UN", url: "https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list" },
  { id: "uk", name: "UK Sanctions List", jurisdiction: "UK", url: "https://www.gov.uk/government/publications/the-uk-sanctions-list" }
];
var SCREENING_SIGNALS = [
  { name: "Global Industrial Minerals FZE", risk: "POTENTIAL_MATCH_REVIEW", reason: "Name similarity to a restricted entity on public screening lists", source: "Public screening signal" }
];
function screenEntity(name, country) {
  const n = String(name || "").toLowerCase();
  const matches = SCREENING_SIGNALS.filter((s) => n.includes(s.name.toLowerCase()) || tokenOverlap(n, s.name) > 0.55);
  if (matches.length) return { status: "POTENTIAL_MATCH_REVIEW", matches };
  return { status: "PRE_SCREEN_CLEAR", matches: [] };
}
function copilotAnswer(ctx) {
  const q = String(ctx.question || "").toLowerCase();
  const evidence = [];
  const sellers = ctx.entities.filter((e) => e.entityType === "Seller");
  const buyers = ctx.entities.filter((e) => e.entityType === "Buyer");
  const products = Array.from(new Set(ctx.entities.flatMap((e) => e.products || []))).slice(0, 12);
  if (q.includes("sulphur") && (q.includes("supplier") || q.includes("strongest") || q.includes("best"))) {
    const ranked = sellers.filter((s) => (s.products || []).some((p) => p.toLowerCase().includes("sulphur"))).sort((a, b) => Number(b.confidence) - Number(a.confidence));
    const top = ranked.slice(0, 3);
    evidence.push("Source: entity registry with official + trade evidence", "Confidence from evidence depth and verification level");
    return { answer: `Strongest sulphur supplier signals: ${top.map((s) => `${s.name} (${s.country}, confidence ${s.confidence}%)`).join("; ")}. Highest-confidence signal: ${top[0]?.name}. Recommendation: qualify current allocation and export terms before outreach.`, evidence, generatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (q.includes("activated carbon") && (q.includes("opportunity") || q.includes("qualify") || q.includes("first"))) {
    const opps = (ctx.opportunities || []).filter((o) => o.product.toLowerCase().includes("activated carbon")).sort((a, b) => b.opportunityScore - a.opportunityScore);
    const top = opps[0];
    if (top) {
      evidence.push("Live RFQ + evidence-backed supplier profiles", `Opportunity score ${top.opportunityScore}%`);
      return { answer: `Highest-priority activated-carbon opportunity: ${top.buyer} \u2192 ${top.supplier} (score ${top.opportunityScore}%, destination ${top.destination}). Next action: open Buyer Workspace, review fit/trust/risk, then launch a controlled RFQ.`, evidence, generatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    return { answer: "No active activated-carbon opportunity found in the current registry. Create a demand to start sourcing.", evidence: ["No matching live opportunity"], generatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (q.includes("evidence gap") || q.includes("evidence") && q.includes("close")) {
    const gaps = ctx.entities.filter((e) => (e.evidence || []).length < 2).slice(0, 5);
    evidence.push("Evidence depth computed from registry records");
    return { answer: gaps.length ? `Priority evidence gaps: ${gaps.map((g) => `${g.name} (${g.evidence?.length || 0} evidence items)`).join("; ")}. Close by adding official company sources and trade/shipment evidence, then refresh verification.` : "No material evidence gaps in the current registry.", evidence, generatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (q.includes("buyer demand") && q.includes("vs") && q.includes("supplier")) {
    const demandCount = ctx.demands.length;
    const buyerCount = buyers.length;
    const supplierCount = sellers.length;
    evidence.push("Live demand + registry counts");
    return { answer: `Current coverage: ${demandCount} active demand record(s), ${buyerCount} buyer entit(ies), ${supplierCount} seller entit(ies). ${supplierCount > demandCount ? "Supplier supply appears sufficient; focus on demand qualification and RFQ response depth." : "More seller capacity would improve match depth."}`, evidence, generatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (q.includes("fx") || q.includes("exchange") || q.includes("usd") && q.includes("idr")) {
    const fx = ctx.fx;
    if (fx && fx.IDR) {
      evidence.push("Source: ECB reference rates via Frankfurter API (live)");
      return { answer: `Live USD/IDR reference rate: ${fx.IDR.toLocaleString("en-US", { maximumFractionDigits: 2 })}. USD\u2192EUR ${fx.EUR}, USD\u2192CNY ${fx.CNY}, USD\u2192SGD ${fx.SGD}. Use these as planning references; settle with the executing bank.`, evidence, generatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    evidence.push("FX source unavailable; static fallback used");
    return { answer: "FX reference data is temporarily unavailable. Retry later or use your bank's rate.", evidence, generatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  if (q.includes("comtrade") || q.includes("trade flow") || q.includes("shipment")) {
    const tf = ctx.tradeFlows;
    if (tf) {
      evidence.push("Source: UN Comtrade public API", `HS ${tf.hsCode} \xB7 ${tf.period}`);
      return { answer: `Real trade flow for ${tf.commodity} (HS ${tf.hsCode}, reporter ${tf.reporterCode}, ${tf.period}): imports $${(tf.flows.import || 0).toLocaleString("en-US", { maximumFractionDigits: 0 })}, exports $${(tf.flows.export || 0).toLocaleString("en-US", { maximumFractionDigits: 0 })}. Use this to benchmark market depth.`, evidence, generatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    evidence.push("Trade-flow source not configured");
    return { answer: "Trade-flow data is not connected yet. Add a UN Comtrade connector or licensed trade-data provider to unlock shipment intelligence.", evidence, generatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  const topProducts = products.slice(0, 6);
  const topOpp = (ctx.opportunities || []).slice(0, 2);
  evidence.push("Registry snapshot", "Role-scoped visibility enforced");
  return {
    answer: `Tradevance registry snapshot: ${sellers.length} seller entit(ies), ${buyers.length} buyer entit(ies), ${ctx.demands.length} active demand(s), ${(ctx.opportunities || []).length} live opportunity(ies). Key commodities: ${topProducts.join(", ") || "n/a"}.${topOpp.length ? ` Top opportunity: ${topOpp[0].product} (${topOpp[0].buyer} \u2192 ${topOpp[0].supplier}, score ${topOpp[0].opportunityScore}%).` : ""} Ask about suppliers, opportunities, evidence gaps, FX rates or trade flows for a deeper answer.`,
    evidence,
    generatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function runAgent(agentId, objective, opportunities) {
  const opps = (opportunities || []).slice(0, 5);
  const top = opps[0];
  const recommendation = top ? `Highest-priority opportunity: ${top.product} \u2014 ${top.buyer} \u2192 ${top.supplier} (score ${top.opportunityScore}%, risk ${top.risk}). Recommend opening the governed workspace and qualifying fit/trust/risk before any outreach.` : "No live opportunity found in the current registry. Recommend creating a demand to start sourcing.";
  const requiresApproval = !["opportunity", "commercial", "deal-guardian", "verification", "buyer-intelligence", "supplier-intelligence"].includes(agentId);
  return {
    taskId: "AGT-" + Date.now().toString(36).toUpperCase(),
    agentId,
    objective,
    status: "Completed",
    authority: requiresApproval ? "Approval" : "Recommend",
    recommendation,
    confidence: 88,
    actionBoundary: requiresApproval ? "Human approval required before material action" : "Recommend only",
    requiresApproval,
    evidence: ["Opportunity data retrieved through governed registry access", `Agent: ${agentId}`, "No contract, payment or commitment was executed"],
    completedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function buildTradeRoom(trade, quotes, events, approvals) {
  return {
    trade,
    quotes: quotes.filter((q) => q.tradeId === trade.id).slice(-30).reverse(),
    events: events.filter((e) => e.tradeId === trade.id).slice(-50).reverse(),
    approvals: approvals.filter((a) => a.tradeId === trade.id).slice(-30).reverse(),
    risk: evaluateRisk({ role: "operator", verificationStatus: "verified" }, { transactionValue: Number(trade.value || 0), product: trade.product, payment: trade.payment, incoterm: trade.incoterm, destination: trade.destination, documents: trade.documents || [] }),
    policy: "Trade Room is governed decision support. No AI action changes a trade without explicit human approval."
  };
}
function negotiationStrategy(user, deal, dealType) {
  const value = dealType === "quote" ? Number(deal.quantity) * Number(deal.price) : Number(deal.value || 0);
  const risk = evaluateRisk(user, { dealType, product: deal.product, payment: deal.payment, incoterm: deal.incoterm, destination: deal.destination, transactionValue: value, documents: deal.documents || [] });
  if (risk.decision === "BLOCK") return { ok: false, status: 423, message: "Negotiation strategy is blocked because the deal is BLOCKed by the Tradevance Risk Engine.", risk };
  const currentPrice = dealType === "quote" ? Number(deal.price) : Number(deal.unitPrice || deal.price || 0);
  const landedCost = Number(deal.landedCost || 0);
  const hasCostBasis = landedCost > 0;
  const mandate = { targetPrice: Number(deal.targetPrice || 0), floorPrice: Number(deal.floorPrice || 0), walkAwayPrice: Number(deal.walkAwayPrice || 0) };
  const mandateReady = mandate.targetPrice > 0 && mandate.floorPrice > 0 && mandate.walkAwayPrice > 0;
  const assumptions = [];
  if (!mandateReady) assumptions.push("No approved target/floor/walk-away mandate is stored. Any price bands are illustrative until a human owner approves the commercial mandate.");
  if (!hasCostBasis) assumptions.push("No acquisition cost basis is stored; margin guidance is illustrative.");
  const recommendation = risk.decision === "REVIEW" ? "Resolve risk review items before negotiation deepens." : mandateReady ? "Anchor near target price, concede toward floor only with documented rationale, and walk away above the approved ceiling." : "Establish an approved commercial mandate (target/floor/walk-away) before substantive negotiation.";
  return { ok: true, dealId: deal.id, dealType, risk, currentData: { currentPrice, landedCost, mandateReady, costBasisReady: hasCostBasis, illustrative: !mandateReady || !hasCostBasis }, strategy: { recommendation, negotiationLeverage: ["Freight and Incoterm structure", "Payment instrument (LC vs DLC)", "Allocation and volume", "Delivery window"], assumptions, closureProbability: risk.decision === "ALLOW" ? 72 : 48, recommendedNextAction: recommendation }, policy: "Decision support only. Human approval is required before any counter-offer, commitment, contract, payment, or transaction change." };
}
var UI_LANGS = { en: "English", id: "Bahasa Indonesia", zh: "\u4E2D\u6587", ar: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629", es: "Espa\xF1ol", fr: "Fran\xE7ais", hi: "\u0939\u093F\u0928\u094D\u0926\u0940", pt: "Portugu\xEAs", ja: "\u65E5\u672C\u8A9E", ko: "\uD55C\uAD6D\uC5B4", ru: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439" };
var UI_TRANSLATIONS = {
  id: { "Buyer Workspace": "Ruang Kerja Buyer", "Seller Workspace": "Ruang Kerja Seller", "Command Center": "Pusat Komando", "My Tradeview": "Tradeview Saya", "Daily Trade Command": "Komando Perdagangan Harian", "Predictive Alerts": "Peringatan Prediktif", "Decision Mesh": "Mesh Keputusan", "Global Entities": "Entitas Global", "Suppliers": "Pemasok", "Products": "Produk", "RFQ & Tenders": "RFQ & Tender", "Quote Intelligence": "Intelijen Penawaran", "Execution Center": "Pusat Eksekusi", "Trades": "Perdagangan", "Trade Room": "Ruang Transaksi", "Commercial Guardrails": "Batasan Komersial", "Intelligence": "Intelijen", "Deal Origination": "Origination Deal", "AI Agents": "Agen AI", "Risk & Compliance": "Risiko & Kepatuhan", "Trade Finance": "Pembiayaan Perdagangan", "Logistics": "Logistik", "Documents": "Dokumen", "Network Access": "Akses Jaringan", "Revenue": "Pendapatan", "Profile & Verification": "Profil & Verifikasi", "Admin Intelligence": "Intelijen Admin" },
  zh: { "Buyer Workspace": "\u4E70\u65B9\u5DE5\u4F5C\u53F0", "Seller Workspace": "\u5356\u65B9\u5DE5\u4F5C\u53F0", "Command Center": "\u6307\u6325\u4E2D\u5FC3", "My Tradeview": "\u6211\u7684 Tradeview", "Daily Trade Command": "\u6BCF\u65E5\u8D38\u6613\u6307\u4EE4", "Predictive Alerts": "\u9884\u6D4B\u63D0\u9192", "Decision Mesh": "\u51B3\u7B56\u7F51", "Global Entities": "\u5168\u7403\u5B9E\u4F53", "Suppliers": "\u4F9B\u5E94\u5546", "Products": "\u4EA7\u54C1", "RFQ & Tenders": "RFQ \u4E0E\u62DB\u6807", "Quote Intelligence": "\u62A5\u4EF7\u667A\u80FD", "Execution Center": "\u6267\u884C\u4E2D\u5FC3", "Trades": "\u4EA4\u6613", "Trade Room": "\u4EA4\u6613\u5BA4", "Commercial Guardrails": "\u5546\u4E1A\u62A4\u680F", "Intelligence": "\u667A\u80FD", "Deal Origination": "\u4EA4\u6613\u673A\u4F1A", "AI Agents": "AI \u667A\u80FD\u4F53", "Risk & Compliance": "\u98CE\u9669\u4E0E\u5408\u89C4", "Trade Finance": "\u8D38\u6613\u878D\u8D44", "Logistics": "\u7269\u6D41", "Documents": "\u6587\u4EF6", "Network Access": "\u7F51\u7EDC\u8BBF\u95EE", "Revenue": "\u6536\u5165", "Profile & Verification": "\u8D44\u6599\u4E0E\u9A8C\u8BC1", "Admin Intelligence": "\u7BA1\u7406\u667A\u80FD" },
  ar: { "Buyer Workspace": "\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0645\u0634\u062A\u0631\u064A", "Seller Workspace": "\u0645\u0633\u0627\u062D\u0629 \u0627\u0644\u0628\u0627\u0626\u0639", "Command Center": "\u0645\u0631\u0643\u0632 \u0627\u0644\u0642\u064A\u0627\u062F\u0629", "My Tradeview": "Tradeview \u0627\u0644\u062E\u0627\u0635 \u0628\u064A", "Daily Trade Command": "\u0642\u064A\u0627\u062F\u0629 \u0627\u0644\u062A\u062C\u0627\u0631\u0629 \u0627\u0644\u064A\u0648\u0645\u064A\u0629", "Predictive Alerts": "\u062A\u0646\u0628\u064A\u0647\u0627\u062A \u062A\u0646\u0628\u0624\u064A\u0629", "Decision Mesh": "\u0634\u0628\u0643\u0629 \u0627\u0644\u0642\u0631\u0627\u0631", "Global Entities": "\u0627\u0644\u0643\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629", "Suppliers": "\u0627\u0644\u0645\u0648\u0631\u062F\u0648\u0646", "Products": "\u0627\u0644\u0645\u0646\u062A\u062C\u0627\u062A", "RFQ & Tenders": "RFQ \u0648\u0627\u0644\u0645\u0646\u0627\u0642\u0635\u0627\u062A", "Quote Intelligence": "\u0630\u0643\u0627\u0621 \u0627\u0644\u0639\u0631\u0648\u0636", "Execution Center": "\u0645\u0631\u0643\u0632 \u0627\u0644\u062A\u0646\u0641\u064A\u0630", "Trades": "\u0627\u0644\u0645\u0639\u0627\u0645\u0644\u0627\u062A", "Trade Room": "\u063A\u0631\u0641\u0629 \u0627\u0644\u062A\u062C\u0627\u0631\u0629", "Commercial Guardrails": "\u0627\u0644\u062D\u0648\u0627\u062C\u0632 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629", "Intelligence": "\u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u062A\u062C\u0627\u0631\u064A", "Deal Origination": "\u0646\u0634\u0623\u0629 \u0627\u0644\u0635\u0641\u0642\u0627\u062A", "AI Agents": "\u0648\u0643\u0644\u0627\u0621 \u0627\u0644\u0630\u0643\u0627\u0621 \u0627\u0644\u0627\u0635\u0637\u0646\u0627\u0639\u064A", "Risk & Compliance": "\u0627\u0644\u0645\u062E\u0627\u0637\u0631 \u0648\u0627\u0644\u0627\u0645\u062A\u062B\u0627\u0644", "Trade Finance": "\u062A\u0645\u0648\u064A\u0644 \u0627\u0644\u062A\u062C\u0627\u0631\u0629", "Logistics": "\u0627\u0644\u062E\u062F\u0645\u0627\u062A \u0627\u0644\u0644\u0648\u062C\u0633\u062A\u064A\u0629", "Documents": "\u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A", "Network Access": "\u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0627\u0644\u0634\u0628\u0643\u0629", "Revenue": "\u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A", "Profile & Verification": "\u0627\u0644\u0645\u0644\u0641 \u0648\u0627\u0644\u062A\u062D\u0642\u0642", "Admin Intelligence": "\u0630\u0643\u0627\u0621 \u0627\u0644\u0625\u062F\u0627\u0631\u0629" },
  es: { "Buyer Workspace": "Espacio del comprador", "Seller Workspace": "Espacio del vendedor", "Command Center": "Centro de control", "My Tradeview": "Mi Tradeview", "Daily Trade Command": "Comando comercial diario", "Predictive Alerts": "Alertas predictivas", "Decision Mesh": "Malla de decisiones", "Global Entities": "Entidades globales", "Suppliers": "Proveedores", "Products": "Productos", "RFQ & Tenders": "RFQ y licitaciones", "Quote Intelligence": "Inteligencia de ofertas", "Execution Center": "Centro de ejecuci\xF3n", "Trades": "Operaciones", "Trade Room": "Sala de operaciones", "Commercial Guardrails": "Controles comerciales", "Intelligence": "Inteligencia", "Deal Origination": "Originaci\xF3n de acuerdos", "AI Agents": "Agentes de IA", "Risk & Compliance": "Riesgo y cumplimiento", "Trade Finance": "Financiaci\xF3n comercial", "Logistics": "Log\xEDstica", "Documents": "Documentos", "Network Access": "Acceso a la red", "Revenue": "Ingresos", "Profile & Verification": "Perfil y verificaci\xF3n", "Admin Intelligence": "Inteligencia administrativa" },
  fr: { "Buyer Workspace": "Espace acheteur", "Seller Workspace": "Espace vendeur", "Command Center": "Centre de contr\xF4le", "My Tradeview": "Mon Tradeview", "Daily Trade Command": "Commande commerciale quotidienne", "Predictive Alerts": "Alertes pr\xE9dictives", "Decision Mesh": "R\xE9seau de d\xE9cision", "Global Entities": "Entit\xE9s mondiales", "Suppliers": "Fournisseurs", "Products": "Produits", "RFQ & Tenders": "RFQ et appels d\u2019offres", "Quote Intelligence": "Intelligence des offres", "Execution Center": "Centre d\u2019ex\xE9cution", "Trades": "Transactions", "Trade Room": "Salle de transaction", "Commercial Guardrails": "Garde-fous commerciaux", "Intelligence": "Intelligence", "Deal Origination": "Origination des transactions", "AI Agents": "Agents IA", "Risk & Compliance": "Risque et conformit\xE9", "Trade Finance": "Financement du commerce", "Logistics": "Logistique", "Documents": "Documents", "Network Access": "Acc\xE8s r\xE9seau", "Revenue": "Revenus", "Profile & Verification": "Profil et v\xE9rification", "Admin Intelligence": "Intelligence administrative" },
  pt: { "Buyer Workspace": "Espa\xE7o do comprador", "Seller Workspace": "Espa\xE7o do vendedor", "Command Center": "Centro de comando", "My Tradeview": "Meu Tradeview", "Daily Trade Command": "Comando comercial di\xE1rio", "Predictive Alerts": "Alertas preditivos", "Decision Mesh": "Malha de decis\xE3o", "Global Entities": "Entidades globais", "Suppliers": "Fornecedores", "Products": "Produtos", "RFQ & Tenders": "RFQ e licita\xE7\xF5es", "Quote Intelligence": "Intelig\xEAncia de cota\xE7\xF5es", "Execution Center": "Centro de execu\xE7\xE3o", "Trades": "Transa\xE7\xF5es", "Trade Room": "Sala de transa\xE7\xF5es", "Commercial Guardrails": "Limites comerciais", "Intelligence": "Intelig\xEAncia", "Deal Origination": "Origina\xE7\xE3o de neg\xF3cios", "AI Agents": "Agentes de IA", "Risk & Compliance": "Risco e conformidade", "Trade Finance": "Financiamento comercial", "Logistics": "Log\xEDstica", "Documents": "Documentos", "Network Access": "Acesso \xE0 rede", "Revenue": "Receita", "Profile & Verification": "Perfil e verifica\xE7\xE3o", "Admin Intelligence": "Intelig\xEAncia administrativa" },
  hi: { "Buyer Workspace": "\u092C\u093E\u092F\u0930 \u0935\u0930\u094D\u0915\u0938\u094D\u092A\u0947\u0938", "Seller Workspace": "\u0938\u0947\u0932\u0930 \u0935\u0930\u094D\u0915\u0938\u094D\u092A\u0947\u0938", "Command Center": "\u0915\u092E\u093E\u0902\u0921 \u0938\u0947\u0902\u091F\u0930", "My Tradeview": "\u092E\u0947\u0930\u093E Tradeview", "Daily Trade Command": "\u0926\u0948\u0928\u093F\u0915 \u091F\u094D\u0930\u0947\u0921 \u0915\u092E\u093E\u0902\u0921", "Predictive Alerts": "\u092A\u0942\u0930\u094D\u0935\u093E\u0928\u0941\u092E\u093E\u0928 \u0905\u0932\u0930\u094D\u091F", "Decision Mesh": "\u0928\u093F\u0930\u094D\u0923\u092F \u091C\u093E\u0932", "Global Entities": "\u0935\u0948\u0936\u094D\u0935\u093F\u0915 \u0907\u0915\u093E\u0907\u092F\u093E\u0901", "Suppliers": "\u0906\u092A\u0942\u0930\u094D\u0924\u093F\u0915\u0930\u094D\u0924\u093E", "Products": "\u0909\u0924\u094D\u092A\u093E\u0926", "RFQ & Tenders": "RFQ \u0914\u0930 \u091F\u0947\u0902\u0921\u0930", "Quote Intelligence": "\u0915\u094B\u091F \u0907\u0902\u091F\u0947\u0932\u093F\u091C\u0947\u0902\u0938", "Execution Center": "\u0928\u093F\u0937\u094D\u092A\u093E\u0926\u0928 \u0915\u0947\u0902\u0926\u094D\u0930", "Trades": "\u091F\u094D\u0930\u0947\u0921\u094D\u0938", "Trade Room": "\u091F\u094D\u0930\u0947\u0921 \u0930\u0942\u092E", "Commercial Guardrails": "\u0935\u093E\u0923\u093F\u091C\u094D\u092F\u093F\u0915 \u0938\u0941\u0930\u0915\u094D\u0937\u093E", "Intelligence": "\u0907\u0902\u091F\u0947\u0932\u093F\u091C\u0947\u0902\u0938", "Deal Origination": "\u0921\u0940\u0932 \u0913\u0930\u093F\u091C\u093F\u0928\u0947\u0936\u0928", "AI Agents": "AI \u090F\u091C\u0947\u0902\u091F", "Risk & Compliance": "\u091C\u094B\u0916\u093F\u092E \u0914\u0930 \u0905\u0928\u0941\u092A\u093E\u0932\u0928", "Trade Finance": "\u091F\u094D\u0930\u0947\u0921 \u092B\u093E\u0907\u0928\u0947\u0902\u0938", "Logistics": "\u0932\u0949\u091C\u093F\u0938\u094D\u091F\u093F\u0915\u094D\u0938", "Documents": "\u0926\u0938\u094D\u0924\u093E\u0935\u0947\u091C\u093C", "Network Access": "\u0928\u0947\u091F\u0935\u0930\u094D\u0915 \u090F\u0915\u094D\u0938\u0947\u0938", "Revenue": "\u0930\u093E\u091C\u0938\u094D\u0935", "Profile & Verification": "\u092A\u094D\u0930\u094B\u092B\u093C\u093E\u0907\u0932 \u0914\u0930 \u0938\u0924\u094D\u092F\u093E\u092A\u0928", "Admin Intelligence": "\u090F\u0921\u092E\u093F\u0928 \u0907\u0902\u091F\u0947\u0932\u093F\u091C\u0947\u0902\u0938" }
};
async function ensureSeed(db, opts) {
  const meta = (await db.list("meta", { limit: 1 })).items[0];
  const version = "production-2026-08-28";
  if (meta && meta.mode === "production" && meta.dataVersion === version && !opts?.force) return;
  if (!meta) await db.add("meta", [{ mode: "production", dataVersion: version, ownerUserId: null }]);
  else await db.update("meta", [{ id: meta.id, record: { ...meta, mode: "production", dataVersion: version } }]);
  const [entities, demands, trades] = await Promise.all([
    db.list("entities", { limit: 400 }),
    db.list("demands", { limit: 200 }),
    db.list("trades", { limit: 200 })
  ]);
  const names = new Set(entities.items.map((x) => x.name));
  const fresh = SEED_ENTITIES.filter((x) => !names.has(x.name)).map((x) => ({ ...x, confidence: Number(x.confidence) }));
  if (fresh.length) await db.add("entities", fresh);
  const demIds = new Set(SEED_DEMANDS.map((x) => x.id));
  const trIds = new Set(SEED_TRADES.map((x) => x.id));
  const dToDelete = demands.items.filter((x) => demIds.has(String(x.id))).map((x) => x.id);
  const tToDelete = trades.items.filter((x) => trIds.has(String(x.id))).map((x) => x.id);
  if (dToDelete.length) await db.delete("demands", dToDelete);
  if (tToDelete.length) await db.delete("trades", tToDelete);
  const dExisting = new Set(demands.items.map((x) => x.id));
  const tExisting = new Set(trades.items.map((x) => x.id));
  const dFresh = SEED_DEMANDS.filter((x) => !dExisting.has(x.id));
  const tFresh = SEED_TRADES.filter((x) => !tExisting.has(x.id));
  if (dFresh.length) await db.add("demands", dFresh);
  if (tFresh.length) await db.add("trades", tFresh);
}
export {
  COMMODITIES,
  COMMODITY_PRICE_BASELINE,
  FX_FALLBACK,
  LocalDB,
  MemoryDB,
  SANCTIONS_SOURCES,
  SCREENING_SIGNALS,
  SEED_BUYERS,
  SEED_DEMANDS,
  SEED_ENTITIES,
  SEED_SUPPLIERS,
  SEED_TRADES,
  UI_LANGS,
  UI_TRANSLATIONS,
  buildOpportunities,
  buildTradeRoom,
  cachedFetch,
  capacityNumber,
  commodityPrice,
  copilotAnswer,
  ensureSeed,
  evaluateRisk,
  fetchComtradeFlow,
  fetchFxRates,
  fetchWorldBankCountry,
  fuzzyTokens,
  getFxRates,
  makeDB,
  matchSuppliers,
  negotiationStrategy,
  normalizeQuotes,
  parseDemand,
  resolveCommodity,
  runAgent,
  screenEntity,
  tokenOverlap,
  trustScoreFor
};
