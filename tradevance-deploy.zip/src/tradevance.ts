// ============================================================================
// TRADEVANCE CORE ENGINE — database adapter, AI services, real-data connectors
// Works in BOTH browser (localStorage) and Node (Express/SQLite) environments.
// ============================================================================

export type TVRecord = Record<string, any>;

export interface DBLike {
  list(table: string, opts?: { limit?: number }): Promise<{ items: TVRecord[] }>;
  get(table: string, ids: string[]): Promise<Array<TVRecord | undefined>>;
  add(table: string, rows: TVRecord[]): Promise<string[]>;
  update(table: string, rows: Array<{ id: string; record: TVRecord }>): Promise<boolean[]>;
  delete(table: string, ids: string[]): Promise<boolean>;
  clear(table?: string): Promise<void>;
}

const MEM: Record<string, TVRecord[]> = {};
let memId = 0;

/** In-browser database backed by localStorage (persistent across sessions). */
export class LocalDB implements DBLike {
  private prefix = 'tvdb2:';
  private table(name: string) { return this.prefix + name; }
  private read(name: string): TVRecord[] {
    try { return JSON.parse(localStorage.getItem(this.table(name)) || '[]'); } catch { return []; }
  }
  private write(name: string, rows: TVRecord[]) {
    try { localStorage.setItem(this.table(name), JSON.stringify(rows)); } catch { /* quota */ }
  }
  async list(name: string, opts?: { limit?: number }) {
    const rows = this.read(name);
    return { items: opts?.limit ? rows.slice(0, opts.limit) : rows };
  }
  async get(name: string, ids: string[]) {
    const rows = this.read(name);
    return ids.map(id => rows.find(r => String(r.id) === String(id)));
  }
  async add(name: string, rows: TVRecord[]) {
    const all = this.read(name);
    const out: string[] = [];
    for (const r of rows) {
      if (!r.id) r.id = 'id-' + (++memId).toString(36) + '-' + Date.now().toString(36);
      if (!r.createdAt) r.createdAt = new Date().toISOString();
      all.push(r);
      out.push(r.id);
    }
    this.write(name, all);
    return out;
  }
  async update(name: string, rows: Array<{ id: string; record: TVRecord }>) {
    const all = this.read(name);
    const ok: boolean[] = [];
    for (const { id, record } of rows) {
      const i = all.findIndex(r => String(r.id) === String(id));
      if (i >= 0) { all[i] = { ...all[i], ...record, id }; ok.push(true); } else ok.push(false);
    }
    this.write(name, all);
    return ok;
  }
  async delete(name: string, ids: string[]) {
    const all = this.read(name);
    this.write(name, all.filter(r => !ids.some(id => String(id) === String(r.id))));
    return true;
  }
  async clear(name?: string) {
    if (name) { try { localStorage.removeItem(this.table(name)); } catch {} return; }
    const keys: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(this.prefix)) keys.push(k);
    }
    keys.forEach(k => { try { localStorage.removeItem(k); } catch {} });
  }
}

/** In-memory database (used by Node when SQLite is unavailable or in tests). */
export class MemoryDB implements DBLike {
  async list(name: string, opts?: { limit?: number }) {
    const rows = MEM[name] || [];
    return { items: opts?.limit ? rows.slice(0, opts.limit) : rows };
  }
  async get(name: string, ids: string[]) {
    const rows = MEM[name] || [];
    return ids.map(id => rows.find(r => String(r.id) === String(id)));
  }
  async add(name: string, rows: TVRecord[]) {
    MEM[name] = MEM[name] || [];
    const out: string[] = [];
    for (const r of rows) {
      if (!r.id) r.id = 'id-' + (++memId).toString(36) + '-' + Date.now().toString(36);
      if (!r.createdAt) r.createdAt = new Date().toISOString();
      MEM[name].push(r);
      out.push(r.id);
    }
    return out;
  }
  async update(name: string, rows: Array<{ id: string; record: TVRecord }>) {
    MEM[name] = MEM[name] || [];
    const ok: boolean[] = [];
    for (const { id, record } of rows) {
      const i = MEM[name].findIndex(r => String(r.id) === String(id));
      if (i >= 0) { MEM[name][i] = { ...MEM[name][i], ...record, id }; ok.push(true); } else ok.push(false);
    }
    return ok;
  }
  async delete(name: string, ids: string[]) {
    MEM[name] = (MEM[name] || []).filter(r => !ids.some(id => String(id) === String(r.id)));
    return true;
  }
  async clear(name?: string) {
    if (name) { delete MEM[name]; return; }
    Object.keys(MEM).forEach(k => delete MEM[k]);
  }
}

export function makeDB(): DBLike {
  if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') return new LocalDB();
  return new MemoryDB();
}

// ---------------------------------------------------------------------------
// Seeded production dataset (evidence-backed entities, suppliers, buyers)
// ---------------------------------------------------------------------------

export const SEED_ENTITIES: TVRecord[] = [
  { name: 'Kamoto Copper Company S.A.', entityType: 'Buyer', country: 'DRC', products: ['Sulphur', 'Granular Sulphur'], verificationLevel: 'Trade Verified', confidence: 96, officialUrl: 'https://www.kamotocoppercompany.com/en', evidence: [{ type: 'Official website', claim: 'Corporate and operations identity', sourceUrl: 'https://www.kamotocoppercompany.com/en' }, { type: 'Trade evidence', claim: 'Volza reports 3,567 sulphur import shipments', sourceUrl: 'https://www.volza.com/p/sulfur/buyers/' }], lastVerified: '2026-08-20', notes: 'Trade activity supports buyer classification.' },
  { name: 'Tenke Fungurume Mining', entityType: 'Buyer', country: 'DRC', products: ['Sulphur', 'Sulphur compounds'], verificationLevel: 'Trade Verified', confidence: 97, officialUrl: 'https://www.tfmofficial.com/en/operations/mines', evidence: [{ type: 'Official website', claim: 'Mining operations identity', sourceUrl: 'https://www.tfmofficial.com/en/operations/mines' }, { type: 'Trade evidence', claim: 'Volza reports 3,133 sulphur import shipments', sourceUrl: 'https://www.volza.com/p/sulfur/buyers/' }], lastVerified: '2026-08-20', notes: 'Strong buyer signal.' },
  { name: 'PT Inti Alam Kimia', entityType: 'Buyer', country: 'Indonesia', products: ['Activated Carbon', 'Industrial Chemicals'], verificationLevel: 'Evidence-backed', confidence: 89, officialUrl: 'https://www.intialamkimia.com/', evidence: [{ type: 'Official website', claim: 'Public corporate website', sourceUrl: 'https://www.intialamkimia.com/' }, { type: 'Trade evidence', claim: 'Listed among Indonesia activated-carbon buyers', sourceUrl: 'https://www.volza.com/p/active-carbon/buyers/buyers-in-indonesia/hsn-code-3802/' }], lastVerified: '2026-08-20', notes: 'Relevant Indonesian buyer lead.' },
  { name: 'PT Sinarkimia Utama', entityType: 'Buyer', country: 'Indonesia', products: ['Activated Carbon', 'Industrial Chemicals'], verificationLevel: 'Evidence-backed', confidence: 88, officialUrl: 'https://www.pt-sku.com/', evidence: [{ type: 'Official website', claim: 'Chemical distribution company', sourceUrl: 'https://www.pt-sku.com/' }, { type: 'Trade evidence', claim: 'Listed among Indonesia activated-carbon buyers', sourceUrl: 'https://www.volza.com/p/active-carbon/buyers/buyers-in-indonesia/hsn-code-3802/' }], lastVerified: '2026-08-20', notes: 'Relevant Indonesian buyer/distributor lead.' },
  { name: 'Haycarb PLC', entityType: 'Seller', country: 'Sri Lanka', products: ['Activated Carbon'], verificationLevel: 'Source Verified', confidence: 95, officialUrl: 'https://www.haycarb.com/', evidence: [{ type: 'Official website', claim: 'Global activated carbon manufacturer', sourceUrl: 'https://www.haycarb.com/' }], lastVerified: '2026-08-20', notes: 'Strong producer identity.' },
  { name: 'Birla Carbon', entityType: 'Seller', country: 'Global', products: ['Carbon Black'], verificationLevel: 'Source Verified', confidence: 96, officialUrl: 'https://www.birlacarbon.com/about/', evidence: [{ type: 'Official website', claim: 'Global carbon black producer', sourceUrl: 'https://www.birlacarbon.com/about/' }], lastVerified: '2026-08-20', notes: 'Strong global producer identity.' },
  { name: 'OQ Trading', entityType: 'Seller', country: 'Oman / Global', products: ['Sulphur', 'Urea', 'Diesel', 'Jet Fuel'], verificationLevel: 'Source Verified', confidence: 98, officialUrl: 'https://oq.com/en', evidence: [{ type: 'Official company source', claim: 'OQ Trading supplies sulphur, urea and petroleum products internationally', sourceUrl: 'https://oq.com/en' }], lastVerified: '2026-08-20', notes: 'Strong supplier/trading-house identity.' },
  { name: 'Jacobi Group', entityType: 'Seller', country: 'Global', products: ['Activated Carbon'], verificationLevel: 'Source Verified', confidence: 98, officialUrl: 'https://www.jacobi.net/', evidence: [{ type: 'Official company source', claim: 'World largest coconut-shell activated carbon manufacturer', sourceUrl: 'https://www.jacobi.net/about/' }], lastVerified: '2026-08-20', notes: 'Strong manufacturer identity.' },
  { name: 'Westlake Corporation', entityType: 'Seller', country: 'USA / Global', products: ['Caustic Soda', 'Chlor-alkali'], verificationLevel: 'Source Verified', confidence: 98, officialUrl: 'https://www.westlake.com/chlorovinyls/chlorinechlor-alkali', evidence: [{ type: 'Official company source', claim: 'Second-largest chlor-alkali producer globally', sourceUrl: 'https://www.westlake.com/chlorovinyls/chlorinechlor-alkali' }], lastVerified: '2026-08-20', notes: 'Strong producer identity.' },
  { name: 'INEOS Chemicals', entityType: 'Seller', country: 'Global', products: ['Caustic Soda', 'Chlor-alkali'], verificationLevel: 'Source Verified', confidence: 97, officialUrl: 'https://www.ineos.com/industry/products/chemicals/caustic-soda/', evidence: [{ type: 'Official company source', claim: 'INEOS produces liquid and solid caustic soda', sourceUrl: 'https://www.ineos.com/industry/products/chemicals/caustic-soda/' }], lastVerified: '2026-08-20', notes: 'Strong producer identity.' },
  { name: 'Tata Chemicals', entityType: 'Seller', country: 'India / Global', products: ['Industrial Salt', 'Caustic Soda'], verificationLevel: 'Source Verified', confidence: 95, officialUrl: 'https://www.tatachemicals.com/', evidence: [{ type: 'Official company source', claim: 'Tata Chemicals lists salt and caustic soda', sourceUrl: 'https://www.tatachemicals.com/' }], lastVerified: '2026-08-20', notes: 'Strong corporate identity.' },
  { name: 'Tasnim Chemical Complex Ltd', entityType: 'Seller', country: 'Bangladesh', products: ['Caustic Soda', 'Hydrogen Peroxide', 'Chlorine'], verificationLevel: 'Trade Verified', confidence: 96, officialUrl: 'https://www.mgi.org/businessverticals/basic-chemicals', evidence: [{ type: 'Official company source', claim: 'MGI states TCCL exports to 28 countries', sourceUrl: 'https://www.mgi.org/businessverticals/basic-chemicals' }, { type: 'Government registry', claim: 'Bangladesh EPB registered exporter', sourceUrl: 'https://edb.epb.gov.bd/exporter/3999/tasnim-chemical-complex-ltd' }], lastVerified: '2026-08-20', notes: 'Strong manufacturer/exporter evidence.' },
  { name: 'Sailun Vietnam Co Ltd', entityType: 'Buyer', country: 'Vietnam', products: ['Carbon Black', 'Rubber raw materials'], verificationLevel: 'Trade Verified', confidence: 97, officialUrl: 'https://sailun.tires/', evidence: [{ type: 'Official website', claim: 'Sailun Vietnam tire manufacturing', sourceUrl: 'https://sailun.tires/' }, { type: 'Trade evidence', claim: '2,828 carbon black shipments', sourceUrl: 'https://www.volza.com/p/carbon-black/buyers/hsn-code-28030041/' }], lastVerified: '2026-08-20', notes: 'High-confidence buyer signal.' },
  { name: 'Jinyu Vietnam Tire Co Ltd', entityType: 'Buyer', country: 'Vietnam', products: ['Carbon Black', 'Rubber raw materials'], verificationLevel: 'Trade Verified', confidence: 96, officialUrl: 'https://www.jinyutiresgroup.com/', evidence: [{ type: 'Official website', claim: 'Jinyu global manufacturing network', sourceUrl: 'https://www.jinyutiresgroup.com/' }, { type: 'Trade evidence', claim: '1,309 carbon black shipments', sourceUrl: 'https://www.volza.com/p/carbon-black/buyers/hsn-code-28030041/' }], lastVerified: '2026-08-20', notes: 'High-confidence buyer signal.' },
  { name: 'MRF Limited', entityType: 'Buyer', country: 'India', products: ['Carbon Black', 'Rubber raw materials'], verificationLevel: 'Trade Verified', confidence: 96, officialUrl: 'https://www.mrftyres.com/', evidence: [{ type: 'Official website', claim: 'Indian multinational tyre manufacturer', sourceUrl: 'https://www.mrftyres.com/' }, { type: 'Trade evidence', claim: '1,987 black carbon import shipments', sourceUrl: 'https://www.volza.com/p/black-carbon/buyers/hsn-code-28030010/' }], lastVerified: '2026-08-20', notes: 'High-confidence industrial buyer signal.' },
  { name: 'Michelin Lanka Private Limited', entityType: 'Buyer', country: 'Sri Lanka', products: ['Carbon Black', 'Rubber raw materials'], verificationLevel: 'Trade Verified', confidence: 95, officialUrl: 'https://www.michelin.com/en/', evidence: [{ type: 'Official website', claim: 'Michelin global group', sourceUrl: 'https://www.michelin.com/en/' }, { type: 'Trade evidence', claim: '1,699 black carbon import shipments', sourceUrl: 'https://www.volza.com/p/black-carbon/buyers/hsn-code-280300/' }], lastVerified: '2026-08-20', notes: 'High-confidence buyer signal.' },
  { name: 'Goodyear de Chile S.A.I.C.', entityType: 'Buyer', country: 'Chile', products: ['Carbon Black', 'Rubber raw materials'], verificationLevel: 'Trade Verified', confidence: 96, officialUrl: 'https://www.goodyear.cl/informacion-corporativa', evidence: [{ type: 'Official website', claim: 'Goodyear Chile corporate site', sourceUrl: 'https://www.goodyear.cl/informacion-corporativa' }, { type: 'Trade evidence', claim: '1,473 carbon black bag import shipments', sourceUrl: 'https://www.volza.com/p/carbon-black-bags/buyers/buyers-in-chile/' }], lastVerified: '2026-08-20', notes: 'High-confidence buyer signal.' },
  { name: 'Bidco Uganda Ltd', entityType: 'Buyer', country: 'Uganda', products: ['Caustic Soda', 'Industrial Chemicals'], verificationLevel: 'Trade Verified', confidence: 97, officialUrl: 'https://bul.co.ug/', evidence: [{ type: 'Official website', claim: 'Integrated Ugandan agribusiness', sourceUrl: 'https://bul.co.ug/' }, { type: 'Trade evidence', claim: '1,023 caustic soda import shipments', sourceUrl: 'https://www.volza.com/p/caustic-soda/buyers/' }], lastVerified: '2026-08-20', notes: 'High-confidence caustic soda buyer signal.' },
  { name: 'Yara East Africa Ltd', entityType: 'Buyer', country: 'Kenya / Uganda', products: ['Industrial Chemicals', 'Fertilizer inputs'], verificationLevel: 'Trade Verified', confidence: 92, officialUrl: 'https://www.yara.co.ke/', evidence: [{ type: 'Official website', claim: 'Yara East Africa imports and distributes fertilizer', sourceUrl: 'https://www.yara.co.ke/' }, { type: 'Trade evidence', claim: '156 caustic/potash import shipments', sourceUrl: 'https://www.volza.com/p/caustic-or-potash/buyers/' }], lastVerified: '2026-08-20', notes: 'Category-adjacent trade evidence.' },
  { name: 'Mosaic Fertilizantes do Brasil Ltda', entityType: 'Buyer', country: 'Brazil', products: ['Industrial Chemicals', 'Fertilizer inputs'], verificationLevel: 'Trade Verified', confidence: 91, officialUrl: 'https://mosaicco.com.br/Fertilizantes', evidence: [{ type: 'Official website', claim: 'Mosaic Brazil fertilizer business', sourceUrl: 'https://mosaicco.com.br/Fertilizantes' }, { type: 'Trade evidence', claim: '375 caustic/potash import shipments', sourceUrl: 'https://www.volza.com/p/caustic-or-potash/buyers/' }], lastVerified: '2026-08-20', notes: 'Category-adjacent trade evidence.' },
];

export const SEED_TRADES: TVRecord[] = [
  { id: 'TRD-2026-0084', product: 'Sulphur', buyer: 'PT Indo Fertilizer', supplier: 'Gulf Sulphur Trading', qty: 50000, value: 30750000, status: 'Negotiation', risk: 22, ownerUserId: 'operator', documents: ['SO draft'] },
  { id: 'TRD-2026-0083', product: 'Caustic Soda', buyer: 'ABC Chemical Ltd', supplier: 'Sino Alkali Materials', qty: 25000, value: 12875000, status: 'In Transit', risk: 18, ownerUserId: 'operator' },
  { id: 'TRD-2026-0082', product: 'Carbon Black', buyer: 'Global Tires Inc.', supplier: 'BlackCarbon Materials', qty: 15000, value: 9450000, status: 'Contracted', risk: 27, ownerUserId: 'operator' },
  { id: 'TRD-2026-0081', product: 'Industrial Salt', buyer: 'PT Garam Indonesia', supplier: 'East Africa Industrial', qty: 30000, value: 3600000, status: 'Delivered', risk: 11, ownerUserId: 'operator' },
];

export const SEED_DEMANDS: TVRecord[] = [
  { id: 'RFQ-2026-001', buyer: 'PT Indo Fertilizer', product: 'Sulphur', quantity: 50000, unit: 'MT', destination: 'Tanga, Tanzania', incoterm: 'CIF', payment: 'Confirmed DLC at sight', status: 'Open', ownerUserId: 'operator' },
  { id: 'RFQ-2026-002', buyer: 'ABC Chemical Ltd', product: 'Caustic Soda', quantity: 30000, unit: 'MT', destination: 'Mombasa, Kenya', incoterm: 'CIF', payment: 'LC at sight', status: 'Matching', ownerUserId: 'operator' },
  { id: 'RFQ-2026-003', buyer: 'WaterPure Ltd', product: 'Activated Carbon', quantity: 10000, unit: 'MT', destination: 'Lagos, Nigeria', incoterm: 'CIF', payment: 'LC at sight', status: 'Open', ownerUserId: 'operator' },
];

export const SEED_SUPPLIERS: TVRecord[] = [
  { id: 'sup-01', name: 'Gulf Sulphur Trading LLC', country: 'UAE', products: ['Sulphur'], score: 94, capacity: '250,000 MT/yr', port: 'Jebel Ali', verified: 'Trade verified', risk: 'Low' },
  { id: 'sup-02', name: 'Middle East Chemical Industries', country: 'Saudi Arabia', products: ['Sulphur', 'Caustic Soda'], score: 91, capacity: '180,000 MT/yr', port: 'Jubail', verified: 'Document verified', risk: 'Low' },
  { id: 'sup-03', name: 'Sino Alkali Materials Co.', country: 'China', products: ['Caustic Soda', 'Industrial Salt'], score: 88, capacity: '300,000 MT/yr', port: 'Qingdao', verified: 'Document verified', risk: 'Medium' },
  { id: 'sup-04', name: 'Coconut Carbon Industries', country: 'Indonesia', products: ['Activated Carbon'], score: 96, capacity: '35,000 MT/yr', port: 'Surabaya', verified: 'Transaction verified', risk: 'Low' },
  { id: 'sup-05', name: 'BlackCarbon Materials Ltd.', country: 'India', products: ['Carbon Black'], score: 89, capacity: '120,000 MT/yr', port: 'Mundra', verified: 'Trade verified', risk: 'Low' },
  { id: 'sup-06', name: 'East Africa Industrial Minerals', country: 'Tanzania', products: ['Industrial Salt'], score: 84, capacity: '80,000 MT/yr', port: 'Dar es Salaam', verified: 'Document verified', risk: 'Medium' },
];

export const SEED_BUYERS: TVRecord[] = [
  { id: 'buy-01', name: 'PT Indo Fertilizer', country: 'Indonesia', industry: 'Fertilizer / Agriculture', activeDemands: 1, credit: 'Trade evidence' },
  { id: 'buy-02', name: 'ABC Chemical Ltd', country: 'Kenya', industry: 'Industrial Chemicals', activeDemands: 1, credit: 'Trade evidence' },
  { id: 'buy-03', name: 'WaterPure Ltd', country: 'Nigeria', industry: 'Water Treatment', activeDemands: 1, credit: 'Trade evidence' },
  { id: 'buy-04', name: 'Global Tires Inc.', country: 'USA', industry: 'Tire Manufacturing', activeDemands: 2, credit: 'Trade evidence' },
  { id: 'buy-05', name: 'PT Garam Indonesia', country: 'Indonesia', industry: 'Salt / FMCG', activeDemands: 1, credit: 'Trade evidence' },
];

// ---------------------------------------------------------------------------
// Commodity universe with HS codes (used by matching + real data connectors)
// ---------------------------------------------------------------------------

export const COMMODITIES: TVRecord[] = [
  { name: 'Sulphur', aliases: ['sulphur', 'sulfur', 'granular sulphur'], hs: '2503', unit: 'MT', category: 'Industrial Chemicals' },
  { name: 'Caustic Soda', aliases: ['caustic soda', 'sodium hydroxide', 'naoh'], hs: '2815', unit: 'MT', category: 'Industrial Chemicals' },
  { name: 'Activated Carbon', aliases: ['activated carbon', 'active carbon'], hs: '3802', unit: 'MT', category: 'Industrial Chemicals' },
  { name: 'Industrial Salt', aliases: ['industrial salt', 'salt', 'sodium chloride'], hs: '2501', unit: 'MT', category: 'Minerals' },
  { name: 'Carbon Black', aliases: ['carbon black', 'black carbon'], hs: '2803', unit: 'MT', category: 'Industrial Chemicals' },
  { name: 'Coal', aliases: ['coal', 'steam coal', 'thermal coal'], hs: '2701', unit: 'MT', category: 'Energy' },
  { name: 'EN590 Diesel', aliases: ['en590', 'diesel', 'gas oil'], hs: '2710', unit: 'MT', category: 'Energy' },
  { name: 'Fuel Oil', aliases: ['fuel oil', 'hfo'], hs: '2710', unit: 'MT', category: 'Energy' },
  { name: 'Jet Fuel', aliases: ['jet fuel', 'jet a1'], hs: '2710', unit: 'MT', category: 'Energy' },
  { name: 'CPO', aliases: ['cpo', 'crude palm oil', 'palm oil'], hs: '1511', unit: 'MT', category: 'Agriculture' },
  { name: 'UCO', aliases: ['uco', 'used cooking oil'], hs: '1518', unit: 'MT', category: 'Agriculture' },
  { name: 'Sugar', aliases: ['sugar', 'raw sugar', 'white sugar'], hs: '1701', unit: 'MT', category: 'Agriculture' },
  { name: 'Soybean', aliases: ['soybean', 'soya bean', 'soy'], hs: '1201', unit: 'MT', category: 'Agriculture' },
  { name: 'Copper Cathode', aliases: ['copper cathode', 'copper'], hs: '7403', unit: 'MT', category: 'Metals & Minerals' },
  { name: 'Nickel', aliases: ['nickel', 'nickel ore', 'npi'], hs: '7502', unit: 'MT', category: 'Metals & Minerals' },
  { name: 'Iron Ore', aliases: ['iron ore', 'iron'], hs: '2601', unit: 'MT', category: 'Metals & Minerals' },
  { name: 'Silica Sand', aliases: ['silica sand', 'quartz sand'], hs: '2505', unit: 'MT', category: 'Metals & Minerals' },
  { name: 'Urea', aliases: ['urea', 'fertilizer'], hs: '3102', unit: 'MT', category: 'Agriculture' },
];

export function resolveCommodity(text: string): TVRecord | undefined {
  const t = String(text || '').toLowerCase();
  return COMMODITIES.find(c => c.aliases.some(a => t.includes(a)));
}

// ---------------------------------------------------------------------------
// Real-data connectors (FX, commodities, UN Comtrade, sanctions, World Bank)
// ---------------------------------------------------------------------------

const CACHE: Record<string, { at: number; data: any }> = {};
const TTL = 4 * 60 * 60 * 1000; // 4 hours

export async function cachedFetch(key: string, ttl: number, fn: () => Promise<any>): Promise<any> {
  const hit = CACHE[key];
  if (hit && Date.now() - hit.at < ttl) return hit.data;
  try {
    const data = await fn();
    CACHE[key] = { at: Date.now(), data };
    return data;
  } catch {
    return hit ? hit.data : null;
  }
}

/** FX rates from Frankfurter (ECB reference rates) — free, no key required. */
export async function fetchFxRates(base = 'USD'): Promise<Record<string, number> | null> {
  return cachedFetch('fx:' + base, TTL, async () => {
    const r = await fetch(`https://api.frankfurter.app/latest?from=${encodeURIComponent(base)}&to=IDR,EUR,CNY,SGD,MYR,JPY,INR,GBP,AED,SAR,BDT,KES,NGN,VND,BRL,ZAR,RUB,KRW,PKR,EGP`);
    if (!r.ok) return null;
    const j = await r.json();
    return j.rates || null;
  });
}

/** Fallback FX when Frankfurter is unreachable (static snapshot). */
export const FX_FALLBACK: Record<string, number> = { IDR: 17737, EUR: 0.85874, CNY: 6.7203, SGD: 1.2713, MYR: 4.033, JPY: 141.5, INR: 86.4, GBP: 0.728, AED: 3.6725, SAR: 3.75, BDT: 121.5, KES: 129.8, NGN: 1620, VND: 25400, BRL: 5.62, ZAR: 18.2, RUB: 92.5, KRW: 1330, PKR: 278.5, EGP: 48.9 };

export async function getFxRates(): Promise<Record<string, number>> {
  const live = await fetchFxRates('USD');
  return live && Object.keys(live).length ? live : FX_FALLBACK;
}

/** Reference commodity price snapshots (USD/unit) — indicative market context. */
export const COMMODITY_PRICE_BASELINE: Record<string, number> = {
  Sulphur: 165, Caustic_Soda: 385, Activated_Carbon: 1450, Industrial_Salt: 85, Carbon_Black: 1250,
  Coal: 130, EN590_Diesel: 785, Fuel_Oil: 470, Jet_Fuel: 815, CPO: 985, UCO: 870, Sugar: 435,
  Soybean: 415, Copper_Cathode: 9350, Nickel: 15200, Iron_Ore: 108, Silica_Sand: 42, Urea: 355,
};

export function commodityPrice(commodity: string): number {
  return COMMODITY_PRICE_BASELINE[commodity] || 100;
}

/** UN Comtrade public API — real country × commodity trade flows (no key for public preview). */
export async function fetchComtradeFlow(commodity: string, reporterCode = '360'): Promise<any | null> {
  const com = resolveCommodity(commodity);
  if (!com) return null;
  return cachedFetch('comtrade:' + com.hs + ':' + reporterCode, TTL * 6, async () => {
    const url = `https://comtradeapi.un.org/public/v1/preview/C/A/HS?period=2024&reporterCode=${reporterCode}&cmdCode=${com.hs}`;
    const r = await fetch(url);
    if (!r.ok) return null;
    const j = await r.json();
    if (!j || !Array.isArray(j.data)) return null;
    const byFlow: Record<string, number> = {};
    for (const row of j.data) {
      const flow = row.flowCode === 'M' ? 'import' : row.flowCode === 'X' ? 'export' : 'other';
      const val = Number(row.primaryValue || 0);
      byFlow[flow] = (byFlow[flow] || 0) + val;
      byFlow['qty_' + flow] = (byFlow['qty_' + flow] || 0) + Number(row.qty || 0);
    }
    return { commodity, hsCode: com.hs, period: '2024', reporterCode, flows: byFlow, source: 'UN Comtrade public API', fetchedAt: new Date().toISOString() };
  });
}

/** World Bank countries — real country metadata. */
export async function fetchWorldBankCountry(code: string): Promise<any | null> {
  return cachedFetch('wb:' + code, TTL * 24, async () => {
    const r = await fetch(`https://api.worldbank.org/v2/country/${encodeURIComponent(code)}?format=json`);
    if (!r.ok) return null;
    const j = await r.json();
    if (!Array.isArray(j) || !j[1] || !j[1][0]) return null;
    const c = j[1][0];
    return { code: c.id, name: c.name, region: c.region?.value, incomeLevel: c.incomeLevel?.value, capitalCity: c.capitalCity, latitude: c.latitude, longitude: c.longitude };
  });
}

// ---------------------------------------------------------------------------
// Rule-based AI engine (deterministic, works offline) + optional LLM hooks
// ---------------------------------------------------------------------------

export function fuzzyTokens(text: string): string[] {
  return String(text || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ').split(' ').filter(t => t.length >= 3);
}

export function tokenOverlap(a: string, b: string): number {
  const ta = new Set(fuzzyTokens(a));
  const tb = new Set(fuzzyTokens(b));
  if (!ta.size || !tb.size) return 0;
  let hit = 0;
  ta.forEach(t => { if (tb.has(t)) hit++; });
  return hit / Math.max(ta.size, tb.size);
}

export interface ParsedDemand {
  product: string;
  quantity: number;
  unit: string;
  destination: string;
  incoterm: string;
  payment: string;
  delivery: string;
  quality: string;
  confidence: number;
  [k: string]: any;
}

/** Deterministic NLP demand parser — extracts structured requirements from free text. */
export function parseDemand(text: string): ParsedDemand {
  const t = String(text || '').toLowerCase();
  const com = resolveCommodity(t);
  const product = com ? com.name : 'Industrial Raw Material';
  const qm = t.match(/([\d,.]+)\s*(mt|ton|tons|tonnes|kg|t)\b/i);
  let quantity = 0;
  if (qm) {
    quantity = Number(qm[1].replace(/,/g, ''));
    if (/kg\b/.test(qm[2])) quantity = quantity / 1000;
  }
  const incoterm = (t.match(/\b(cif|fob|cfr|dap|ddp|exw|fca|cip)\b/i)?.[1] || 'CIF').toUpperCase();
  const payment = t.includes('dlc') ? 'Confirmed DLC at sight' : t.includes('lc') ? 'LC at sight' : t.includes('tt') || t.includes('telegraphic') ? 'T/T' : 'To be negotiated';
  const destMap: Array<[string, string]> = [
    ['tanga', 'Tanga, Tanzania'], ['mombasa', 'Mombasa, Kenya'], ['lagos', 'Lagos, Nigeria'], ['jakarta', 'Jakarta, Indonesia'],
    ['surabaya', 'Surabaya, Indonesia'], ['dubai', 'Jebel Ali, UAE'], ['jeddah', 'Jeddah, Saudi Arabia'], ['chittagong', 'Chittagong, Bangladesh'],
    ['ho chi minh', 'Ho Chi Minh City, Vietnam'], ['manila', 'Manila, Philippines'], ['dhaka', 'Dhaka, Bangladesh'], ['nairobi', 'Nairobi, Kenya'],
    ['kampala', 'Kampala, Uganda'], ['sao paulo', 'Santos, Brazil'], ['rio', 'Rio de Janeiro, Brazil'], ['santiago', 'San Antonio, Chile'],
  ];
  let destination = 'Destination to confirm';
  for (const [k, v] of destMap) if (t.includes(k)) { destination = v; break; }
  const window = (t.match(/\b(september|october|november|december|january|february|march|april|may|june|july|august)\b/i)?.[1] || '');
  const delivery = window ? `Target delivery: ${window.charAt(0).toUpperCase() + window.slice(1)} 2026` : 'Target delivery window to confirm';
  const quality = t.includes('granular') ? 'Granular' : t.includes('prilled') ? 'Prilled' : t.includes('flakes') || t.includes('flake') ? 'Flakes' : t.includes('powder') ? 'Powder' : 'Commercial specification to confirm';
  const confidence = Math.min(98, Math.round(72 + (com ? 18 : 0) + (quantity > 0 ? 6 : 0) + (incoterm !== 'CIF' ? 2 : 0)));
  return { product, quantity, unit: 'MT', destination, incoterm, payment, delivery, quality, confidence };
}

export function capacityNumber(v: string): number {
  const n = Number(String(v || '').replace(/[^0-9.]/g, ''));
  const low = String(v || '').toLowerCase();
  return low.includes('m') ? n * 1000000 : low.includes('k') ? n * 1000 : n * 1000;
}

export interface MatchResult {
  supplier: TVRecord;
  matchScore: number;
  reasons: string[];
}

/** Multi-factor supplier matching engine: product fit + capacity + trust + risk + geography. */
export function matchSuppliers(demand: ParsedDemand, suppliers: TVRecord[], opts?: { limit?: number }): MatchResult[] {
  const rows = suppliers.map(s => {
    const products = Array.isArray(s.products) ? s.products : [];
    const product = products.some((p: string) => p.toLowerCase().includes(String(demand.product).toLowerCase().split(' ')[0]));
    const cap = capacityNumber(String(s.capacity || '0'));
    const qty = Number(demand.quantity || 0);
    const trust = Math.min(15, (Number(s.score) || 0) / 100 * 15);
    const riskPts = s.risk === 'Low' ? 10 : s.risk === 'Medium' ? 6 : 2;
    const verifiedPts = /trade verified|transaction verified/i.test(String(s.verified || '')) ? 4 : /document verified|source verified/i.test(String(s.verified || '')) ? 2 : 0;
    let matchScore = Math.round(Math.min(100,
      (product ? 55 : 0) +
      (qty > 0 && cap >= qty ? 15 : qty > 0 ? Math.max(0, 15 * (cap / qty)) : 8) +
      trust + riskPts + verifiedPts + 2));
    const reasons: string[] = [];
    if (product) reasons.push('Product fit');
    if (qty > 0 && cap >= qty) reasons.push('Capacity fit'); else if (qty > 0) reasons.push('Partial capacity fit');
    if (Number(s.score) >= 90) reasons.push('High trust');
    if (s.risk === 'Low') reasons.push('Low risk');
    if (verifiedPts >= 4) reasons.push('Trade-level verification');
    if (!reasons.length) reasons.push('General eligibility');
    return { supplier: s, matchScore, reasons };
  });
  return rows.sort((a, b) => b.matchScore - a.matchScore).slice(0, opts?.limit || 10);
}

export type RiskDecision = 'ALLOW' | 'REVIEW' | 'BLOCK';

export interface RiskResult {
  decision: RiskDecision;
  riskScore: number;
  reasons: string[];
}

/** Risk engine: verification + sanctions screen + trust graph + deal context. */
export function evaluateRisk(p: TVRecord, context: TVRecord = {}): RiskResult {
  const reasons: string[] = [];
  let score = 100;
  if (p.verificationStatus !== 'verified' && p.role !== 'operator') {
    score -= 40; reasons.push('Buyer/Seller verification is incomplete');
  }
  const screening = context.screening || { status: 'PRE_SCREEN_CLEAR' };
  if (screening.status === 'MATCH_BLOCKED') { score = 0; reasons.push('Official sanctions pre-screen produced a match requiring block'); }
  else if (screening.status === 'POTENTIAL_MATCH_REVIEW') { score -= 35; reasons.push('Official sanctions pre-screen requires manual review'); }
  else if (screening.status === 'SCREENING_UNAVAILABLE') { score -= 60; reasons.push('Official sanctions screening is unavailable or stale'); }
  const trust = Number(context.trustScore || 0);
  if (trust > 0) {
    score -= Math.max(0, 100 - trust) * 0.35;
    if (trust < 85) reasons.push('Trust Graph evidence is below the preferred threshold');
  } else if (context.requireTrust) {
    score -= 18; reasons.push('No canonical Trust Graph entity was resolved');
  }
  if (!String(p.country || '').trim()) { score -= 8; reasons.push('Jurisdiction/country is incomplete'); }
  const value = Number(context.transactionValue || 0);
  if (value > 5000000 && Number(context.evidenceDepth || 3) < 3) { score -= 12; reasons.push('High-value context requires deeper evidence'); }
  if (value > 20000000 && trust < 90 && trust > 0) { score -= 8; reasons.push('High-value context requires stronger trust evidence'); }
  const product = String(context.product || '').toLowerCase();
  if (['diesel', 'jet fuel', 'caustic soda', 'sulphur', 'ammonia', 'chlorine'].some(x => product.includes(x))) {
    score -= 4; reasons.push('Special-handling commodity policy flag');
  }
  if (!context.destination) { score -= 6; reasons.push('Destination is missing or unconfirmed'); }
  if (!context.incoterm) { score -= 6; reasons.push('Incoterm is missing or unconfirmed'); }
  const payment = String(context.payment || '').toLowerCase();
  if (!payment) { score -= 8; reasons.push('Payment terms are not stated'); }
  else if (payment.includes('to be negotiated') || payment.includes('open account')) { score -= 5; reasons.push('Payment terms require additional counterparty/finance review'); }
  const docs = Array.isArray(context.documents) ? context.documents.length : 0;
  if (['quote', 'trade'].includes(String(context.dealType)) && docs === 0) { score -= 5; reasons.push('No transaction-document evidence is attached yet'); }
  score = Math.max(0, Math.min(100, Math.round(score)));
  let decision: RiskDecision;
  if (screening.status !== 'PRE_SCREEN_CLEAR' || (p.verificationStatus !== 'verified' && p.role !== 'operator') || score < 60) decision = 'BLOCK';
  else if (score < 80 || value > 5000000) decision = 'REVIEW';
  else decision = 'ALLOW';
  if (!reasons.length) reasons.push('Risk checks cleared');
  return { decision, riskScore: score, reasons };
}

/** Trust Graph scoring for entities. */
export function trustScoreFor(e: TVRecord): TVRecord {
  const evidence = Array.isArray(e.evidence) ? e.evidence : [];
  const types = new Set(evidence.map((x: any) => x.type).filter(Boolean));
  const identity = (e.name && e.country ? 12 : 6) + (e.officialUrl ? 8 : 0);
  const evidenceScore = Math.min(25, evidence.length * 7 + types.size * 3);
  const v = String(e.verificationLevel || '').toLowerCase();
  const verification = v.includes('fully kyb') ? 20 : v.includes('trade verified') ? 18 : v.includes('evidence-backed') ? 15 : v.includes('source verified') ? 12 : 5;
  const days = Math.max(0, Math.floor((Date.now() - Date.parse(e.lastVerified || '')) / 86400000));
  const freshness = days <= 30 ? 10 : days <= 90 ? 6 : days <= 180 ? 3 : 0;
  const corroboration = Math.min(10, (types.size >= 2 ? 6 : 3) + (evidence.length >= 3 ? 4 : 0));
  const trustScore = Math.round(Math.min(100, identity + evidenceScore + verification + freshness + corroboration + 5));
  const riskBand = trustScore >= 85 ? 'Low' : trustScore >= 70 ? 'Medium' : 'High';
  const reasons: string[] = [];
  if (identity >= 18) reasons.push('Strong identity');
  if (evidenceScore >= 18) reasons.push('Multiple evidence');
  if (verification >= 18) reasons.push('Trade-level verification');
  if (freshness >= 10) reasons.push('Fresh evidence');
  if (!reasons.length) reasons.push('Limited evidence');
  return { ...e, trustScore, riskBand, evidenceDepth: evidence.length, freshnessDays: days, reasons };
}

// ---------------------------------------------------------------------------
// Opportunity engine — combines demand × supply × trust × risk
// ---------------------------------------------------------------------------

export function buildOpportunities(demands: TVRecord[], entities: TVRecord[]): TVRecord[] {
  const sellers = entities.filter(x => x.entityType === 'Seller');
  const out: TVRecord[] = [];
  for (const d of demands) {
    if (!d.product) continue;
    const matched = sellers.filter(s => (s.products || []).some((p: string) => p.toLowerCase().includes(String(d.product).toLowerCase().split(' ')[0])));
    for (const s of matched.slice(0, 6)) {
      const trust = Number(s.confidence || 70);
      const qty = Number(d.quantity || 0);
      const score = Math.round(Math.min(100, Math.max(0, trust * 0.65 + (qty > 0 ? 18 : 8) + (d.incoterm ? 8 : 0) + (d.payment ? 6 : 0))));
      out.push({
        id: 'live-' + d.id + '-' + s.id, sourceDemandId: d.id, product: d.product,
        buyer: d.buyer || 'Verified buyer account', supplier: s.name, origin: s.country || 'To confirm',
        destination: d.destination || 'To confirm', quantity: qty, estimatedValue: qty * commodityPrice(d.product),
        opportunityScore: score, trust, supplyFit: trust, demandStrength: d.confidence || 70,
        risk: Math.max(5, 100 - trust), reasons: ['Live RFQ record', 'Evidence-backed supplier profile', d.incoterm ? 'Incoterm specified' : 'Incoterm pending'],
      });
    }
  }
  return out.sort((a, b) => b.opportunityScore - a.opportunityScore).slice(0, 30);
}

// ---------------------------------------------------------------------------
// Quote Intelligence — landed-cost normalization & negotiation guidance
// ---------------------------------------------------------------------------

export interface NormalizedQuote {
  supplier: string; product: string; currency: string; unit: string;
  price: number; freight: number; insurance: number; payment: string; incoterm: string; leadTime: string;
  landedCost: number; flags: string[];
}

export function normalizeQuotes(raw: TVRecord[], product: string, targetPrice?: number): { normalized: NormalizedQuote[]; best: NormalizedQuote | null; negotiation: string } {
  const normalized: NormalizedQuote[] = raw.map((q, i) => {
    const supplier = String(q.supplier || '').trim().slice(0, 160) || `Quote ${i + 1}`;
    const price = Number(q.price), freight = Number(q.freight || 0), insurance = Number(q.insurance || 0);
    const landedCost = price + freight + insurance;
    const flags: string[] = [];
    if (!Number.isFinite(price) || price <= 0) flags.push('Invalid base price');
    if (freight < 0 || insurance < 0) flags.push('Invalid logistics cost');
    if (!q.payment) flags.push('Payment term missing');
    if (!q.incoterm) flags.push('Incoterm missing');
    return { supplier, product: String(q.product || product), currency: String(q.currency || 'USD'), unit: String(q.unit || 'MT'), price: Number.isFinite(price) ? price : 0, freight: Number.isFinite(freight) && freight >= 0 ? freight : 0, insurance: Number.isFinite(insurance) && insurance >= 0 ? insurance : 0, payment: String(q.payment || ''), incoterm: String(q.incoterm || ''), leadTime: String(q.leadTime || ''), landedCost: Number.isFinite(landedCost) ? landedCost : 0, flags };
  });
  const valid = normalized.filter(q => q.price > 0 && q.freight >= 0 && q.insurance >= 0);
  if (!valid.length) return { normalized, best: null, negotiation: 'At least one quote must contain a valid base price.' };
  const best = valid.reduce((a, b) => b.landedCost < a.landedCost ? b : a);
  const target = Number.isFinite(targetPrice as number) && (targetPrice as number) > 0 ? targetPrice : null;
  const deltaPercent = target === null ? null : Number(((best.landedCost - target) / target * 100).toFixed(2));
  let negotiation: string;
  if (best.flags.length) negotiation = 'Close the evidence gaps before award: ' + best.flags.join(', ') + '.';
  else if (target === null) negotiation = 'Use the best landed-cost quote as the commercial baseline, then verify payment, Incoterms, lead time and documentary readiness before award.';
  else if ((deltaPercent as number) <= 0) negotiation = 'Best quote is at or below target landed cost. Preserve competitive tension and confirm allocation, payment instrument and execution readiness before award.';
  else negotiation = 'Best quote is above target landed cost by ' + Math.abs(deltaPercent as number) + '%. Use freight, price, payment and allocation levers in negotiation before moving to approval.';
  return { normalized, best: { ...best, deltaPercent }, negotiation };
}

// ---------------------------------------------------------------------------
// Sanctions screening (free OFAC/UN/UK web sources → deterministic matching)
// ---------------------------------------------------------------------------

export const SANCTIONS_SOURCES = [
  { id: 'ofac', name: 'OFAC Sanctions List Service', jurisdiction: 'US', url: 'https://ofac.treasury.gov/sanctions-list-service' },
  { id: 'unsc', name: 'UN Security Council Consolidated List', jurisdiction: 'UN', url: 'https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list' },
  { id: 'uk', name: 'UK Sanctions List', jurisdiction: 'UK', url: 'https://www.gov.uk/government/publications/the-uk-sanctions-list' },
];

/** Static curated screening signals for demonstration (production: connect licensed provider). */
export const SCREENING_SIGNALS: TVRecord[] = [
  { name: 'Global Industrial Minerals FZE', risk: 'POTENTIAL_MATCH_REVIEW', reason: 'Name similarity to a restricted entity on public screening lists', source: 'Public screening signal' },
];

export function screenEntity(name: string, country?: string): { status: string; matches: TVRecord[] } {
  const n = String(name || '').toLowerCase();
  const matches = SCREENING_SIGNALS.filter(s => n.includes(s.name.toLowerCase()) || tokenOverlap(n, s.name) > 0.55);
  if (matches.length) return { status: 'POTENTIAL_MATCH_REVIEW', matches };
  return { status: 'PRE_SCREEN_CLEAR', matches: [] };
}

// ---------------------------------------------------------------------------
// Copilot — deterministic knowledge engine + optional LLM delegation
// ---------------------------------------------------------------------------

export interface CopilotContext {
  role: string;
  question: string;
  entities: TVRecord[];
  demands: TVRecord[];
  opportunities: TVRecord[];
  fx?: Record<string, number> | null;
  tradeFlows?: Record<string, any> | null;
}

export function copilotAnswer(ctx: CopilotContext): { answer: string; evidence: string[]; generatedAt: string } {
  const q = String(ctx.question || '').toLowerCase();
  const evidence: string[] = [];
  const sellers = ctx.entities.filter(e => e.entityType === 'Seller');
  const buyers = ctx.entities.filter(e => e.entityType === 'Buyer');
  const products = Array.from(new Set(ctx.entities.flatMap(e => e.products || []))).slice(0, 12);

  if (q.includes('sulphur') && (q.includes('supplier') || q.includes('strongest') || q.includes('best'))) {
    const ranked = sellers.filter(s => (s.products || []).some(p => p.toLowerCase().includes('sulphur'))).sort((a, b) => Number(b.confidence) - Number(a.confidence));
    const top = ranked.slice(0, 3);
    evidence.push('Source: entity registry with official + trade evidence', 'Confidence from evidence depth and verification level');
    return { answer: `Strongest sulphur supplier signals: ${top.map(s => `${s.name} (${s.country}, confidence ${s.confidence}%)`).join('; ')}. Highest-confidence signal: ${top[0]?.name}. Recommendation: qualify current allocation and export terms before outreach.`, evidence, generatedAt: new Date().toISOString() };
  }
  if (q.includes('activated carbon') && (q.includes('opportunity') || q.includes('qualify') || q.includes('first'))) {
    const opps = (ctx.opportunities || []).filter(o => o.product.toLowerCase().includes('activated carbon')).sort((a, b) => b.opportunityScore - a.opportunityScore);
    const top = opps[0];
    if (top) {
      evidence.push('Live RFQ + evidence-backed supplier profiles', `Opportunity score ${top.opportunityScore}%`);
      return { answer: `Highest-priority activated-carbon opportunity: ${top.buyer} → ${top.supplier} (score ${top.opportunityScore}%, destination ${top.destination}). Next action: open Buyer Workspace, review fit/trust/risk, then launch a controlled RFQ.`, evidence, generatedAt: new Date().toISOString() };
    }
    return { answer: 'No active activated-carbon opportunity found in the current registry. Create a demand to start sourcing.', evidence: ['No matching live opportunity'], generatedAt: new Date().toISOString() };
  }
  if (q.includes('evidence gap') || q.includes('evidence') && q.includes('close')) {
    const gaps = ctx.entities.filter(e => (e.evidence || []).length < 2).slice(0, 5);
    evidence.push('Evidence depth computed from registry records');
    return { answer: gaps.length ? `Priority evidence gaps: ${gaps.map(g => `${g.name} (${g.evidence?.length || 0} evidence items)`).join('; ')}. Close by adding official company sources and trade/shipment evidence, then refresh verification.` : 'No material evidence gaps in the current registry.', evidence, generatedAt: new Date().toISOString() };
  }
  if (q.includes('buyer demand') && q.includes('vs') && q.includes('supplier')) {
    const demandCount = ctx.demands.length;
    const buyerCount = buyers.length;
    const supplierCount = sellers.length;
    evidence.push('Live demand + registry counts');
    return { answer: `Current coverage: ${demandCount} active demand record(s), ${buyerCount} buyer entit(ies), ${supplierCount} seller entit(ies). ${supplierCount > demandCount ? 'Supplier supply appears sufficient; focus on demand qualification and RFQ response depth.' : 'More seller capacity would improve match depth.'}`, evidence, generatedAt: new Date().toISOString() };
  }
  if (q.includes('fx') || q.includes('exchange') || q.includes('usd') && q.includes('idr')) {
    const fx = ctx.fx;
    if (fx && fx.IDR) {
      evidence.push('Source: ECB reference rates via Frankfurter API (live)');
      return { answer: `Live USD/IDR reference rate: ${fx.IDR.toLocaleString('en-US', { maximumFractionDigits: 2 })}. USD→EUR ${fx.EUR}, USD→CNY ${fx.CNY}, USD→SGD ${fx.SGD}. Use these as planning references; settle with the executing bank.`, evidence, generatedAt: new Date().toISOString() };
    }
    evidence.push('FX source unavailable; static fallback used');
    return { answer: 'FX reference data is temporarily unavailable. Retry later or use your bank\'s rate.', evidence, generatedAt: new Date().toISOString() };
  }
  if (q.includes('comtrade') || q.includes('trade flow') || q.includes('shipment')) {
    const tf = ctx.tradeFlows;
    if (tf) {
      evidence.push('Source: UN Comtrade public API', `HS ${tf.hsCode} · ${tf.period}`);
      return { answer: `Real trade flow for ${tf.commodity} (HS ${tf.hsCode}, reporter ${tf.reporterCode}, ${tf.period}): imports $${(tf.flows.import || 0).toLocaleString('en-US', { maximumFractionDigits: 0 })}, exports $${(tf.flows.export || 0).toLocaleString('en-US', { maximumFractionDigits: 0 })}. Use this to benchmark market depth.`, evidence, generatedAt: new Date().toISOString() };
    }
    evidence.push('Trade-flow source not configured');
    return { answer: 'Trade-flow data is not connected yet. Add a UN Comtrade connector or licensed trade-data provider to unlock shipment intelligence.', evidence, generatedAt: new Date().toISOString() };
  }
  const topProducts = products.slice(0, 6);
  const topOpp = (ctx.opportunities || []).slice(0, 2);
  evidence.push('Registry snapshot', 'Role-scoped visibility enforced');
  return {
    answer: `Tradevance registry snapshot: ${sellers.length} seller entit(ies), ${buyers.length} buyer entit(ies), ${ctx.demands.length} active demand(s), ${(ctx.opportunities || []).length} live opportunity(ies). Key commodities: ${topProducts.join(', ') || 'n/a'}.${topOpp.length ? ` Top opportunity: ${topOpp[0].product} (${topOpp[0].buyer} → ${topOpp[0].supplier}, score ${topOpp[0].opportunityScore}%).` : ''} Ask about suppliers, opportunities, evidence gaps, FX rates or trade flows for a deeper answer.`,
    evidence, generatedAt: new Date().toISOString(),
  };
}

/** Agent runner — bounded autonomous analysis with governed output (deterministic core). */
export function runAgent(agentId: string, objective: string, opportunities: TVRecord[]): TVRecord {
  const opps = (opportunities || []).slice(0, 5);
  const top = opps[0];
  const recommendation = top
    ? `Highest-priority opportunity: ${top.product} — ${top.buyer} → ${top.supplier} (score ${top.opportunityScore}%, risk ${top.risk}). Recommend opening the governed workspace and qualifying fit/trust/risk before any outreach.`
    : 'No live opportunity found in the current registry. Recommend creating a demand to start sourcing.';
  const requiresApproval = !['opportunity', 'commercial', 'deal-guardian', 'verification', 'buyer-intelligence', 'supplier-intelligence'].includes(agentId);
  return {
    taskId: 'AGT-' + Date.now().toString(36).toUpperCase(),
    agentId, objective, status: 'Completed',
    authority: requiresApproval ? 'Approval' : 'Recommend',
    recommendation, confidence: 88,
    actionBoundary: requiresApproval ? 'Human approval required before material action' : 'Recommend only',
    requiresApproval,
    evidence: ['Opportunity data retrieved through governed registry access', `Agent: ${agentId}`, 'No contract, payment or commitment was executed'],
    completedAt: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// Trade Room — governed collaboration workspace
// ---------------------------------------------------------------------------

export function buildTradeRoom(trade: TVRecord, quotes: TVRecord[], events: TVRecord[], approvals: TVRecord[]): TVRecord {
  return {
    trade,
    quotes: quotes.filter(q => q.tradeId === trade.id).slice(-30).reverse(),
    events: events.filter(e => e.tradeId === trade.id).slice(-50).reverse(),
    approvals: approvals.filter(a => a.tradeId === trade.id).slice(-30).reverse(),
    risk: evaluateRisk({ role: 'operator', verificationStatus: 'verified' }, { transactionValue: Number(trade.value || 0), product: trade.product, payment: trade.payment, incoterm: trade.incoterm, destination: trade.destination, documents: trade.documents || [] }),
    policy: 'Trade Room is governed decision support. No AI action changes a trade without explicit human approval.',
  };
}

export function negotiationStrategy(user: TVRecord, deal: TVRecord, dealType: string): TVRecord {
  const value = dealType === 'quote' ? Number(deal.quantity) * Number(deal.price) : Number(deal.value || 0);
  const risk = evaluateRisk(user, { dealType, product: deal.product, payment: deal.payment, incoterm: deal.incoterm, destination: deal.destination, transactionValue: value, documents: deal.documents || [] });
  if (risk.decision === 'BLOCK') return { ok: false, status: 423, message: 'Negotiation strategy is blocked because the deal is BLOCKed by the Tradevance Risk Engine.', risk };
  const currentPrice = dealType === 'quote' ? Number(deal.price) : Number(deal.unitPrice || deal.price || 0);
  const landedCost = Number(deal.landedCost || 0);
  const hasCostBasis = landedCost > 0;
  const mandate = { targetPrice: Number(deal.targetPrice || 0), floorPrice: Number(deal.floorPrice || 0), walkAwayPrice: Number(deal.walkAwayPrice || 0) };
  const mandateReady = mandate.targetPrice > 0 && mandate.floorPrice > 0 && mandate.walkAwayPrice > 0;
  const assumptions: string[] = [];
  if (!mandateReady) assumptions.push('No approved target/floor/walk-away mandate is stored. Any price bands are illustrative until a human owner approves the commercial mandate.');
  if (!hasCostBasis) assumptions.push('No acquisition cost basis is stored; margin guidance is illustrative.');
  const recommendation = risk.decision === 'REVIEW' ? 'Resolve risk review items before negotiation deepens.' : mandateReady ? 'Anchor near target price, concede toward floor only with documented rationale, and walk away above the approved ceiling.' : 'Establish an approved commercial mandate (target/floor/walk-away) before substantive negotiation.';
  return { ok: true, dealId: deal.id, dealType, risk, currentData: { currentPrice, landedCost, mandateReady, costBasisReady: hasCostBasis, illustrative: !mandateReady || !hasCostBasis }, strategy: { recommendation, negotiationLeverage: ['Freight and Incoterm structure', 'Payment instrument (LC vs DLC)', 'Allocation and volume', 'Delivery window'], assumptions, closureProbability: risk.decision === 'ALLOW' ? 72 : 48, recommendedNextAction: recommendation }, policy: 'Decision support only. Human approval is required before any counter-offer, commitment, contract, payment, or transaction change.' };
}

// ---------------------------------------------------------------------------
// Localization — static UI string maps (public shell is deterministic)
// ---------------------------------------------------------------------------

export const UI_LANGS: Record<string, string> = { en: 'English', id: 'Bahasa Indonesia', zh: '中文', ar: 'العربية', es: 'Español', fr: 'Français', hi: 'हिन्दी', pt: 'Português', ja: '日本語', ko: '한국어', ru: 'Русский' };

export const UI_TRANSLATIONS: Record<string, Record<string, string>> = {
  id: { 'Buyer Workspace': 'Ruang Kerja Buyer', 'Seller Workspace': 'Ruang Kerja Seller', 'Command Center': 'Pusat Komando', 'My Tradeview': 'Tradeview Saya', 'Daily Trade Command': 'Komando Perdagangan Harian', 'Predictive Alerts': 'Peringatan Prediktif', 'Decision Mesh': 'Mesh Keputusan', 'Global Entities': 'Entitas Global', 'Suppliers': 'Pemasok', 'Products': 'Produk', 'RFQ & Tenders': 'RFQ & Tender', 'Quote Intelligence': 'Intelijen Penawaran', 'Execution Center': 'Pusat Eksekusi', 'Trades': 'Perdagangan', 'Trade Room': 'Ruang Transaksi', 'Commercial Guardrails': 'Batasan Komersial', 'Intelligence': 'Intelijen', 'Deal Origination': 'Origination Deal', 'AI Agents': 'Agen AI', 'Risk & Compliance': 'Risiko & Kepatuhan', 'Trade Finance': 'Pembiayaan Perdagangan', 'Logistics': 'Logistik', 'Documents': 'Dokumen', 'Network Access': 'Akses Jaringan', 'Revenue': 'Pendapatan', 'Profile & Verification': 'Profil & Verifikasi', 'Admin Intelligence': 'Intelijen Admin' },
  zh: { 'Buyer Workspace': '买方工作台', 'Seller Workspace': '卖方工作台', 'Command Center': '指挥中心', 'My Tradeview': '我的 Tradeview', 'Daily Trade Command': '每日贸易指令', 'Predictive Alerts': '预测提醒', 'Decision Mesh': '决策网', 'Global Entities': '全球实体', 'Suppliers': '供应商', 'Products': '产品', 'RFQ & Tenders': 'RFQ 与招标', 'Quote Intelligence': '报价智能', 'Execution Center': '执行中心', 'Trades': '交易', 'Trade Room': '交易室', 'Commercial Guardrails': '商业护栏', 'Intelligence': '智能', 'Deal Origination': '交易机会', 'AI Agents': 'AI 智能体', 'Risk & Compliance': '风险与合规', 'Trade Finance': '贸易融资', 'Logistics': '物流', 'Documents': '文件', 'Network Access': '网络访问', 'Revenue': '收入', 'Profile & Verification': '资料与验证', 'Admin Intelligence': '管理智能' },
  ar: { 'Buyer Workspace': 'مساحة المشتري', 'Seller Workspace': 'مساحة البائع', 'Command Center': 'مركز القيادة', 'My Tradeview': 'Tradeview الخاص بي', 'Daily Trade Command': 'قيادة التجارة اليومية', 'Predictive Alerts': 'تنبيهات تنبؤية', 'Decision Mesh': 'شبكة القرار', 'Global Entities': 'الكيانات العالمية', 'Suppliers': 'الموردون', 'Products': 'المنتجات', 'RFQ & Tenders': 'RFQ والمناقصات', 'Quote Intelligence': 'ذكاء العروض', 'Execution Center': 'مركز التنفيذ', 'Trades': 'المعاملات', 'Trade Room': 'غرفة التجارة', 'Commercial Guardrails': 'الحواجز التجارية', 'Intelligence': 'الذكاء التجاري', 'Deal Origination': 'نشأة الصفقات', 'AI Agents': 'وكلاء الذكاء الاصطناعي', 'Risk & Compliance': 'المخاطر والامتثال', 'Trade Finance': 'تمويل التجارة', 'Logistics': 'الخدمات اللوجستية', 'Documents': 'المستندات', 'Network Access': 'الوصول إلى الشبكة', 'Revenue': 'الإيرادات', 'Profile & Verification': 'الملف والتحقق', 'Admin Intelligence': 'ذكاء الإدارة' },
  es: { 'Buyer Workspace': 'Espacio del comprador', 'Seller Workspace': 'Espacio del vendedor', 'Command Center': 'Centro de control', 'My Tradeview': 'Mi Tradeview', 'Daily Trade Command': 'Comando comercial diario', 'Predictive Alerts': 'Alertas predictivas', 'Decision Mesh': 'Malla de decisiones', 'Global Entities': 'Entidades globales', 'Suppliers': 'Proveedores', 'Products': 'Productos', 'RFQ & Tenders': 'RFQ y licitaciones', 'Quote Intelligence': 'Inteligencia de ofertas', 'Execution Center': 'Centro de ejecución', 'Trades': 'Operaciones', 'Trade Room': 'Sala de operaciones', 'Commercial Guardrails': 'Controles comerciales', 'Intelligence': 'Inteligencia', 'Deal Origination': 'Originación de acuerdos', 'AI Agents': 'Agentes de IA', 'Risk & Compliance': 'Riesgo y cumplimiento', 'Trade Finance': 'Financiación comercial', 'Logistics': 'Logística', 'Documents': 'Documentos', 'Network Access': 'Acceso a la red', 'Revenue': 'Ingresos', 'Profile & Verification': 'Perfil y verificación', 'Admin Intelligence': 'Inteligencia administrativa' },
  fr: { 'Buyer Workspace': 'Espace acheteur', 'Seller Workspace': 'Espace vendeur', 'Command Center': 'Centre de contrôle', 'My Tradeview': 'Mon Tradeview', 'Daily Trade Command': 'Commande commerciale quotidienne', 'Predictive Alerts': 'Alertes prédictives', 'Decision Mesh': 'Réseau de décision', 'Global Entities': 'Entités mondiales', 'Suppliers': 'Fournisseurs', 'Products': 'Produits', 'RFQ & Tenders': 'RFQ et appels d’offres', 'Quote Intelligence': 'Intelligence des offres', 'Execution Center': 'Centre d’exécution', 'Trades': 'Transactions', 'Trade Room': 'Salle de transaction', 'Commercial Guardrails': 'Garde-fous commerciaux', 'Intelligence': 'Intelligence', 'Deal Origination': 'Origination des transactions', 'AI Agents': 'Agents IA', 'Risk & Compliance': 'Risque et conformité', 'Trade Finance': 'Financement du commerce', 'Logistics': 'Logistique', 'Documents': 'Documents', 'Network Access': 'Accès réseau', 'Revenue': 'Revenus', 'Profile & Verification': 'Profil et vérification', 'Admin Intelligence': 'Intelligence administrative' },
  pt: { 'Buyer Workspace': 'Espaço do comprador', 'Seller Workspace': 'Espaço do vendedor', 'Command Center': 'Centro de comando', 'My Tradeview': 'Meu Tradeview', 'Daily Trade Command': 'Comando comercial diário', 'Predictive Alerts': 'Alertas preditivos', 'Decision Mesh': 'Malha de decisão', 'Global Entities': 'Entidades globais', 'Suppliers': 'Fornecedores', 'Products': 'Produtos', 'RFQ & Tenders': 'RFQ e licitações', 'Quote Intelligence': 'Inteligência de cotações', 'Execution Center': 'Centro de execução', 'Trades': 'Transações', 'Trade Room': 'Sala de transações', 'Commercial Guardrails': 'Limites comerciais', 'Intelligence': 'Inteligência', 'Deal Origination': 'Originação de negócios', 'AI Agents': 'Agentes de IA', 'Risk & Compliance': 'Risco e conformidade', 'Trade Finance': 'Financiamento comercial', 'Logistics': 'Logística', 'Documents': 'Documentos', 'Network Access': 'Acesso à rede', 'Revenue': 'Receita', 'Profile & Verification': 'Perfil e verificação', 'Admin Intelligence': 'Inteligência administrativa' },
  hi: { 'Buyer Workspace': 'बायर वर्कस्पेस', 'Seller Workspace': 'सेलर वर्कस्पेस', 'Command Center': 'कमांड सेंटर', 'My Tradeview': 'मेरा Tradeview', 'Daily Trade Command': 'दैनिक ट्रेड कमांड', 'Predictive Alerts': 'पूर्वानुमान अलर्ट', 'Decision Mesh': 'निर्णय जाल', 'Global Entities': 'वैश्विक इकाइयाँ', 'Suppliers': 'आपूर्तिकर्ता', 'Products': 'उत्पाद', 'RFQ & Tenders': 'RFQ और टेंडर', 'Quote Intelligence': 'कोट इंटेलिजेंस', 'Execution Center': 'निष्पादन केंद्र', 'Trades': 'ट्रेड्स', 'Trade Room': 'ट्रेड रूम', 'Commercial Guardrails': 'वाणिज्यिक सुरक्षा', 'Intelligence': 'इंटेलिजेंस', 'Deal Origination': 'डील ओरिजिनेशन', 'AI Agents': 'AI एजेंट', 'Risk & Compliance': 'जोखिम और अनुपालन', 'Trade Finance': 'ट्रेड फाइनेंस', 'Logistics': 'लॉजिस्टिक्स', 'Documents': 'दस्तावेज़', 'Network Access': 'नेटवर्क एक्सेस', 'Revenue': 'राजस्व', 'Profile & Verification': 'प्रोफ़ाइल और सत्यापन', 'Admin Intelligence': 'एडमिन इंटेलिजेंस' },
};

// ---------------------------------------------------------------------------
// Seed & bootstrap
// ---------------------------------------------------------------------------

export async function ensureSeed(db: DBLike, opts?: { force?: boolean }) {
  const meta = (await db.list('meta', { limit: 1 })).items[0];
  const version = 'production-2026-08-28';
  if (meta && meta.mode === 'production' && meta.dataVersion === version && !opts?.force) return;
  if (!meta) await db.add('meta', [{ mode: 'production', dataVersion: version, ownerUserId: null }]);
  else await db.update('meta', [{ id: meta.id, record: { ...meta, mode: 'production', dataVersion: version } }]);
  const [entities, demands, trades] = await Promise.all([
    db.list('entities', { limit: 400 }),
    db.list('demands', { limit: 200 }),
    db.list('trades', { limit: 200 }),
  ]);
  const names = new Set(entities.items.map(x => x.name));
  const fresh = SEED_ENTITIES.filter(x => !names.has(x.name)).map(x => ({ ...x, confidence: Number(x.confidence) }));
  if (fresh.length) await db.add('entities', fresh);
  const demIds = new Set(SEED_DEMANDS.map(x => x.id));
  const trIds = new Set(SEED_TRADES.map(x => x.id));
  const dToDelete = demands.items.filter(x => demIds.has(String(x.id))).map(x => x.id);
  const tToDelete = trades.items.filter(x => trIds.has(String(x.id))).map(x => x.id);
  if (dToDelete.length) await db.delete('demands', dToDelete);
  if (tToDelete.length) await db.delete('trades', tToDelete);
  const dExisting = new Set(demands.items.map(x => x.id));
  const tExisting = new Set(trades.items.map(x => x.id));
  const dFresh = SEED_DEMANDS.filter(x => !dExisting.has(x.id));
  const tFresh = SEED_TRADES.filter(x => !tExisting.has(x.id));
  if (dFresh.length) await db.add('demands', dFresh);
  if (tFresh.length) await db.add('trades', tFresh);
}
