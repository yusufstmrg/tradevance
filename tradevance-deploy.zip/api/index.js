// ============================================================================
// TRADEVANCE — Vercel Serverless Entry Point
// Wraps the Express app (app.js) as a single serverless function.
// Vercel routes all /api/(.*) traffic here via vercel.json rewrites.
// The Express app serves the static frontend (web/dist) when present,
// and handles all 56 API routes from the AI engine.
// ============================================================================
import app from '../app.js';

export default app;
