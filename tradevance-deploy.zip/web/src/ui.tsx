import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

export interface ToastItem { id: number; text: string; kind?: 'ok' | 'err' | 'info'; }
interface ToastCtx { push: (text: string, kind?: 'ok' | 'err' | 'info') => void; }
const Ctx = createContext<ToastCtx>({ push: () => {} });
export const useToast = () => useContext(Ctx);

let seq = 1;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const push = useCallback((text: string, kind: 'ok' | 'err' | 'info' = 'info') => {
    const id = seq++;
    setItems((xs) => [...xs, { id, text, kind }]);
    setTimeout(() => setItems((xs) => xs.filter((x) => x.id !== id)), 4200);
  }, []);
  return (
    <Ctx.Provider value={{ push }}>
      {children}
      <div className="toast-wrap">
        {items.map((t) => (
          <div key={t.id} className={`toast ${t.kind === 'err' ? 'err' : t.kind === 'ok' ? 'ok' : ''}`}>{t.text}</div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function fmtUSD(n: number | string | undefined | null, digits = 0): string {
  const v = Number(n || 0);
  return '$' + v.toLocaleString('en-US', { maximumFractionDigits: digits, minimumFractionDigits: 0 });
}

export function pct(n: number | string | undefined | null): string {
  const v = Number(n || 0);
  return v.toFixed(0) + '%';
}

export function timeAgo(iso?: string): string {
  if (!iso) return '—';
  const d = new Date(iso).getTime();
  if (Number.isNaN(d)) return '—';
  const s = Math.max(0, Math.floor((Date.now() - d) / 1000));
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  return Math.floor(s / 86400) + 'd ago';
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="empty">
      <div className="big spin">◐</div>
      {label ? <div>{label}</div> : <div>Loading…</div>}
    </div>
  );
}

export function Empty({ icon = '🗂️', text }: { icon?: string; text: string }) {
  return (
    <div className="empty">
      <div className="big">{icon}</div>
      <div>{text}</div>
    </div>
  );
}

export function Stat({ label, value, foot, small }: { label: string; value: ReactNode; foot?: string; small?: boolean }) {
  return (
    <div className="stat">
      <div className="stat-label">{label}</div>
      <div className="stat-value" style={small ? { fontSize: 20 } : undefined}>{value}</div>
      {foot ? <div className="stat-foot">{foot}</div> : null}
    </div>
  );
}

export function Badge({ kind = 'ok', children }: { kind?: 'ok' | 'warn' | 'bad' | 'acc'; children: ReactNode }) {
  return <span className={`badge badge-${kind}`}>{children}</span>;
}

export function ScoreBar({ value, max = 100 }: { value: number; max?: number }) {
  const v = Math.max(0, Math.min(max, Number(value || 0)));
  const p = (v / max) * 100;
  const color = p >= 85 ? 'var(--ok)' : p >= 65 ? 'var(--warn)' : 'var(--bad)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div className="progress" style={{ flex: 1 }}><div style={{ width: p + '%', background: color }} /></div>
      <span className="mono" style={{ color, fontWeight: 600 }}>{v}%</span>
    </div>
  );
}
