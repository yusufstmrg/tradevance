// ============================================================================
// TRADEVANCE API CLIENT — replaces @appdeploy/client
// Strategy: try the Express API server first (same /api routes). If the server
// is unreachable (static hosting), fall back to the fully self-contained
// browser engine (localStorage DB + deterministic AI + real-data connectors).
// ============================================================================

import {
  LocalDB, makeDB, ensureSeed, parseDemand, matchSuppliers, buildOpportunities,
  evaluateRisk, normalizeQuotes, copilotAnswer, runAgent, screenEntity,
  trustScoreFor, getFxRates, fetchComtradeFlow, negotiationStrategy,
  SEED_SUPPLIERS, SEED_BUYERS, SEED_ENTITIES, SEED_TRADES, SEED_DEMANDS,
  resolveCommodity, commodityPrice, UI_LANGS, UI_TRANSLATIONS,
  type DBLike, type TVRecord, type ParsedDemand, type MatchResult,
} from './tradevance';

// ---------------------------------------------------------------------------
// Server detection & fetch helper
// ---------------------------------------------------------------------------

let serverAvailable: boolean | null = null;

async function probeServer(): Promise<boolean> {
  if (serverAvailable !== null) return serverAvailable;
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 2500);
    const r = await fetch('/api/health', { signal: ctrl.signal });
    clearTimeout(t);
    serverAvailable = r.ok;
  } catch {
    serverAvailable = false;
  }
  return serverAvailable;
}

let memDb: DBLike | null = null;
function db(): DBLike {
  if (!memDb) memDb = typeof localStorage !== 'undefined' ? new LocalDB() : makeDB();
  return memDb;
}

let seeded = false;
async function seedOnce() {
  if (seeded) return;
  seeded = true;
  try { await ensureSeed(db()); } catch { /* noop */ }
}

async function http(method: string, path: string, body?: any): Promise<any> {
  const r = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const err: any = new Error(j?.message || j?.error || ('HTTP ' + r.status));
    err.status = r.status;
    throw err;
  }
  return j;
}

// ---------------------------------------------------------------------------
// Auth — browser-local identity (self-contained) or server session
// ---------------------------------------------------------------------------

export interface TVUser {
  userId: string;
  email: string;
  name: string;
  role: 'pending' | 'buyer' | 'seller' | 'operator';
  company?: string;
  verificationStatus?: string;
  [k: string]: any;
}

const USER_KEY = 'tv-user';
const PROFILE_KEY = 'tv-profile';
const VISITOR_KEY = 'tv-visitor';

export function localUser(): TVUser | null {
  try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); } catch { return null; }
}
export function localProfile(): TVUser | null {
  try { return JSON.parse(localStorage.getItem(PROFILE_KEY) || 'null'); } catch { return null; }
}
export function setLocalProfile(p: TVUser | null) {
  try { p ? localStorage.setItem(PROFILE_KEY, JSON.stringify(p)) : localStorage.removeItem(PROFILE_KEY); } catch {}
}
function setLocalUser(u: TVUser | null) {
  try { u ? localStorage.setItem(USER_KEY, JSON.stringify(u)) : localStorage.removeItem(USER_KEY); } catch {}
}

function visitorId(): string {
  let v = '';
  try { v = localStorage.getItem(VISITOR_KEY) || ''; } catch {}
  if (!v) { v = 'vis-' + Math.random().toString(36).slice(2, 10); try { localStorage.setItem(VISITOR_KEY, v); } catch {} }
  return v;
}

const DEMO_PROFILES: TVUser[] = [
  { userId: 'op-1', email: 'operator@tradevance.com', name: 'Platform Operator', role: 'operator', company: 'Tradevance Operations', verificationStatus: 'verified', onboarded: true, plan: 'operator' },
  { userId: 'buy-1', email: 'buyer@tradevance.com', name: 'Yusuf Buyer', role: 'buyer', company: 'PT Indo Fertilizer', verificationStatus: 'verified', onboarded: true, plan: 'buyer_pro', country: 'Indonesia' },
  { userId: 'sel-1', email: 'seller@tradevance.com', name: 'Yusuf Seller', role: 'seller', company: 'Coconut Carbon Industries', verificationStatus: 'verified', onboarded: true, plan: 'seller_verified', country: 'Indonesia', products: ['Activated Carbon', 'Sulphur'], capacity: '35,000 MT/yr', port: 'Surabaya' },
];

export const auth = {
  async getUser(): Promise<TVUser | null> {
    await seedOnce();
    if (await probeServer()) {
      try { const j = await http('GET', '/api/me'); return j.user; } catch { /* fall through */ }
    }
    return localUser();
  },
  async signIn(preferredRole?: 'buyer' | 'seller'): Promise<{ user: TVUser }> {
    await seedOnce();
    if (await probeServer()) {
      try {
        const j = await http('POST', '/api/auth/demo-signin', { preferredRole, visitorId: visitorId() });
        setLocalUser(j.user);
        setLocalProfile(j.user);
        return j;
      } catch { /* fall through */ }
    }
    // Self-contained mode: pick/route a demo identity.
    const existing = localUser();
    const pending = existing && existing.role === 'pending';
    const pick = pending
      ? existing
      : preferredRole === 'buyer' ? DEMO_PROFILES[1]
      : preferredRole === 'seller' ? DEMO_PROFILES[2]
      : (existing || DEMO_PROFILES[0]);
    setLocalUser(pick);
    setLocalProfile(pick);
    return { user: pick };
  },
  async signOut(): Promise<void> {
    if (await probeServer()) { try { await http('POST', '/api/auth/signout'); } catch {} }
    setLocalUser(null);
    setLocalProfile(null);
  },
};

// ---------------------------------------------------------------------------
// Local engine — mirrors the server API surface in the browser
// ---------------------------------------------------------------------------

let fxCache: Record<string, number> | null = null;
async function fx() {
  if (!fxCache) { try { fxCache = await getFxRates(); } catch { fxCache = {}; } }
  return fxCache;
}

function canonicalize(e: any) {
  return { ...e, verificationLevel: e.verificationLevel || e.verification || 'Discovered', confidence: Number(e.confidence || 70) };
}
function entityToSupplier(e: any) {
  return { id: e.id, name: e.name, country: e.country, products: e.products || [], score: Number(e.confidence || 0), status: 'Operational registry', capacity: 'Current allocation to confirm', port: 'Trade lane to confirm', verified: e.verificationLevel || 'Evidence-backed', risk: Number(e.confidence || 0) >= 90 ? 'Low' : Number(e.confidence || 0) >= 80 ? 'Medium' : 'High' };
}
function entityToBuyer(e: any, demands: any[]) {
  return { id: e.id, name: e.name, country: e.country, industry: 'Industrial buyer / procurement', activeDemands: demands.filter(d => String(d.buyerEntityId || '') === String(e.id)).length, credit: e.verificationLevel || 'Evidence-backed' };
}

function currentProfile(): TVUser {
  return localProfile() || localUser() || DEMO_PROFILES[0];
}

async function localBootstrap() {
  await seedOnce();
  const d = db();
  const p = currentProfile();
  const [dRows, tRows, eRows] = await Promise.all([
    d.list('demands', { limit: 100 }),
    d.list('trades', { limit: 50 }),
    d.list('entities', { limit: 200 }),
  ]);
  const demands = dRows.items;
  const trades = tRows.items;
  const entities = eRows.items.map(canonicalize);
  const role = p.role;
  const sellerEntities = entities.filter(x => x.entityType === 'Seller').map(entityToSupplier);
  const buyerEntities = entities.filter(x => x.entityType === 'Buyer').map(x => entityToBuyer(x, demands));
  const visibleDemands = role === 'buyer' ? demands.filter(x => x.ownerUserId === p.userId) : role === 'seller' ? demands.map(x => ({ ...x, buyer: 'Protected Buyer' })) : demands;
  const visibleTrades = role === 'operator' ? trades : trades.filter(x => x.ownerUserId === p.userId);
  const visibleEntities = role === 'buyer' ? entities.filter(x => x.entityType === 'Seller') : role === 'seller' ? entities.filter(x => x.entityType === 'Buyer') : entities;
  const selfBuyer = { id: 'self-buyer', name: p.company || p.name || 'Your Buyer Organization', country: p.country || 'To confirm', industry: 'Buyer organization', activeDemands: demands.filter(x => x.ownerUserId === p.userId).length, credit: 'Pending verification' };
  const selfSeller = { id: 'self-seller', name: p.company || p.name || 'Your Supplier Organization', country: p.country || 'To confirm', products: p.products || [], score: p.trustScore || 0, status: 'Onboarding', capacity: p.capacity || 'To confirm', port: p.port || 'To confirm', verified: 'Profile verification required', risk: 'Review' };
  return {
    mode: 'production', profile: p,
    suppliers: role === 'buyer' || role === 'operator' ? [...sellerEntities, selfSeller] : [selfSeller],
    buyers: role === 'seller' || role === 'operator' ? [...buyerEntities, selfBuyer] : [selfBuyer],
    demands: visibleDemands, trades: visibleTrades, entities: visibleEntities,
  };
}

function transactionGate(p: TVUser, ctx: any = {}) {
  const gate = evaluateRisk(p, ctx);
  if (gate.decision === 'BLOCK') throw Object.assign(new Error('Transaction access is blocked by Tradevance Risk Engine: ' + gate.reasons.join(' · ')), { status: 423 });
  if (gate.decision === 'REVIEW') throw Object.assign(new Error('Transaction access is held for manual Trade Risk review: ' + gate.reasons.join(' · ')), { status: 423 });
  return gate;
}

function requireVerified(p: TVUser) {
  if (p.role !== 'operator' && p.verificationStatus !== 'verified') {
    throw Object.assign(new Error('Transaction access is locked until Buyer/Seller verification is completed.'), { status: 403 });
  }
}

// ---------------------------------------------------------------------------
// API surface — same routes as the reconstructed Express server
// ---------------------------------------------------------------------------

export const api = {
  async get(path: string) {
    if (await probeServer()) {
      try { return { data: await http('GET', path) }; } catch (e: any) {
        if (e?.status >= 400 && e?.status < 500) throw e;
      }
    }
    return { data: await localGet(path) };
  },
  async post(path: string, body?: any) {
    if (await probeServer()) {
      try { return { data: await http('POST', path, body) }; } catch (e: any) {
        if (e?.status >= 400 && e?.status < 500) throw e;
      }
    }
    return { data: await localPost(path, body) };
  },
};

async function localGet(path: string): Promise<any> {
  await seedOnce();
  const d = db();
  const p = currentProfile();
  const isOp = p.role === 'operator';

  if (path === '/api/bootstrap') return localBootstrap();
  if (path === '/api/me' || path === '/api/profile') return localProfile() || localUser() || DEMO_PROFILES[0];

  if (path === '/api/entities') {
    const rows = (await d.list('entities', { limit: 200 })).items.map(canonicalize);
    const items = p.role === 'buyer' ? rows.filter(x => x.entityType === 'Seller') : p.role === 'seller' ? rows.filter(x => x.entityType === 'Buyer') : rows;
    return { entities: items };
  }
  if (path.startsWith('/api/entity/')) {
    const id = path.split('/').pop() || '';
    const [e] = await d.get('entities', [id]);
    if (!e) throw Object.assign(new Error('Entity not found'), { status: 404 });
    const entity = canonicalize(e);
    if (p.role === 'buyer' && entity.entityType !== 'Seller') throw Object.assign(new Error('Entity is outside your network visibility'), { status: 403 });
    if (p.role === 'seller' && entity.entityType !== 'Buyer') throw Object.assign(new Error('Entity is outside your network visibility'), { status: 403 });
    return entity;
  }
  if (path === '/api/intelligence') {
    const demands = (await d.list('demands', { limit: 200 })).items;
    const entities = (await d.list('entities', { limit: 200 })).items.map(canonicalize);
    const opportunities = buildOpportunities(demands, entities);
    const demandRadar = demands.slice(0, 20).map((x: any, i: number) => ({ id: 'd-' + x.id, name: x.buyer || 'Verified buyer account', product: x.product || 'Unspecified', country: x.destination || 'To confirm', signal: 'Live procurement record in Tradevance', strength: Math.min(100, Math.max(20, Number(x.confidence || 70))), lastSignal: x.createdAt || 'Current' }));
    const supplyRadar = entities.filter(x => x.entityType === 'Seller').slice(0, 20).map((s: any) => ({ id: 's-' + s.id, name: s.name, product: (s.products || []).join(' · '), country: s.country, signal: 'Evidence-backed supplier profile in operational registry', strength: s.confidence, lastSignal: 'Current' }));
    if (p.role === 'buyer') return { demandRadar: [], supplyRadar, opportunities: opportunities.map(({ buyer, ...x }: any) => x) };
    if (p.role === 'seller') return { demandRadar, supplyRadar: [], opportunities: opportunities.map(({ supplier, ...x }: any) => x) };
    return { demandRadar, supplyRadar, opportunities };
  }
  if (path === '/api/decision-mesh') return localDecisionMesh(p);
  if (path === '/api/predictive-alerts') return localPredictiveAlerts(p);
  if (path === '/api/opportunity-autopilot') return localOpportunityAutopilot(p);
  if (path === '/api/adaptive-workspace') return localAdaptiveWorkspace(p);
  if (path === '/api/agents') {
    const agents = [
      { id: 'opportunity', name: 'Opportunity Agent', mission: 'Rank high-probability deals from demand, supply, trust, commercial fit and risk.', status: 'Running', authority: 'Recommend', confidence: 94, queue: 2 },
      { id: 'buyer-intelligence', name: 'Buyer Intelligence Agent', mission: 'Detect demand signals without exposing protected contacts.', status: 'Running', authority: 'Recommend', confidence: 92, queue: 3 },
      { id: 'supplier-intelligence', name: 'Supplier Intelligence Agent', mission: 'Evaluate capacity, fit and trade evidence.', status: 'Running', authority: 'Recommend', confidence: 93, queue: 2 },
      { id: 'verification', name: 'Verification Agent', mission: 'Find evidence gaps and prioritize re-verification.', status: 'Monitoring', authority: 'Recommend', confidence: 90, queue: 4 },
      { id: 'commercial', name: 'Commercial Agent', mission: 'Benchmark landed cost and negotiation ranges.', status: 'Running', authority: 'Recommend', confidence: 88, queue: 2 },
      { id: 'negotiation', name: 'Negotiation Agent', mission: 'Draft counter-positions within approved mandates.', status: 'Approval Gate', authority: 'Approval', confidence: 86, queue: 1 },
      { id: 'compliance', name: 'Compliance Agent', mission: 'Screen transaction requirements and escalate exceptions.', status: 'Monitoring', authority: 'Recommend', confidence: 91, queue: 3 },
      { id: 'logistics', name: 'Logistics Agent', mission: 'Analyze routes and shipment exceptions.', status: 'Monitoring', authority: 'Recommend', confidence: 87, queue: 2 },
      { id: 'finance', name: 'Finance Agent', mission: 'Assess LC and payment readiness.', status: 'Ready', authority: 'Approval', confidence: 84, queue: 1 },
      { id: 'deal-guardian', name: 'Deal Guardian', mission: 'Detect deal exceptions and escalate material deviations.', status: 'Monitoring', authority: 'Escalate', confidence: 95, queue: 0 },
    ];
    const tasks = (await d.list('agent_tasks', { limit: 100 })).items;
    return { agents, tasks };
  }
  if (path === '/api/execution') {
    const [t, q] = await Promise.all([d.list('trades', { limit: 50 }), d.list('quotes', { limit: 50 })]);
    if (!isOp) return { trades: t.items.filter(x => x.ownerUserId === p.userId), quotes: q.items.filter(x => x.ownerUserId === p.userId) };
    return { trades: t.items, quotes: q.items };
  }
  if (path === '/api/my-demands') {
    const rows = (await d.list('demands', { limit: 100 })).items;
    return rows.filter(x => x.ownerUserId === p.userId);
  }
  if (path === '/api/access') {
    const plan = p.plan || (p.role === 'seller' ? 'seller_free' : p.role === 'buyer' ? 'buyer_free' : 'operator');
    const pricing = p.role === 'seller' ? [['Seller Free', 0, 'seller_free'], ['Seller Verified', 99, 'seller_verified'], ['Seller Pro', 299, 'seller_pro']] : p.role === 'buyer' ? [['Buyer Free', 0, 'buyer_free'], ['Buyer Pro', 79, 'buyer_pro']] : [['Operator', 0, 'operator']];
    const rows = (await d.list('introductions', { limit: 100 })).items;
    return { role: p.role, plan, pricing, introductions: isOp ? rows : rows.filter(x => x.requestedBy === p.userId), protection: { contactDetails: 'Protected', tailPeriodMonths: 24, auditTrail: 'Enabled' } };
  }
  if (path === '/api/audit') {
    const rows = (await d.list('audit', { limit: 100 })).items;
    return { items: isOp ? rows : rows.filter(x => x.userId === p.userId) };
  }
  if (path === '/api/data-fabric') {
    if (!isOp) throw Object.assign(new Error('Data Fabric is restricted to authorized operators'), { status: 403 });
    const e = (await d.list('entities', { limit: 200 })).items.map(canonicalize);
    const trust = e.map(trustScoreFor);
    return {
      registryCount: e.length,
      buyers: e.filter(x => x.entityType === 'Buyer').length,
      sellers: e.filter(x => x.entityType === 'Seller').length,
      avgConfidence: Math.round(e.reduce((a: any, x: any) => a + x.confidence, 0) / Math.max(1, e.length)),
      evidenceBacked: e.filter(x => (x.evidence || []).length >= 2).length,
      tradeVerified: e.filter(x => /Trade Verified/i.test(x.verificationLevel)).length,
      trustGraph: { nodesCount: trust.length, avgTrust: Math.round(trust.reduce((a: any, x: any) => a + x.trustScore, 0) / Math.max(1, trust.length)), scoreBuckets: { low: trust.filter(x => x.riskBand === 'Low').length, medium: trust.filter(x => x.riskBand === 'Medium').length, high: trust.filter(x => x.riskBand === 'High').length } },
      sourceCoverage: [
        { source: 'Official company / government', coverage: Math.round(e.filter(x => /Source Verified|Evidence-backed|Trade Verified/i.test(x.verificationLevel)).length / Math.max(1, e.length) * 100), status: 'Active' },
        { source: 'Trade evidence', coverage: Math.round(e.filter(x => /Trade Verified/i.test(x.verificationLevel)).length / Math.max(1, e.length) * 100), status: 'Seeded + licensed boundary' },
        { source: 'UN Comtrade', coverage: 72, status: 'Integration boundary' },
        { source: 'KYB / sanctions', coverage: 0, status: 'Licensed integration required' },
      ],
      gaps: [
        { label: 'Live shipment feed', priority: 'High', action: 'Connect licensed trade-data provider' },
        { label: 'Sanctions / UBO', priority: 'Critical', action: 'Connect licensed screening provider' },
        { label: 'Comtrade ingestion', priority: 'High', action: 'Add API key + scheduled delta ingestion' },
        { label: 'ITC Trade Map', priority: 'High', action: 'Add licensed workspace integration' },
      ],
    };
  }
  if (path.startsWith('/api/trade-room/')) {
    const id = path.split('/').pop() || '';
    const [trade] = await d.get('trades', [id]);
    if (!trade) throw Object.assign(new Error('Trade not found'), { status: 404 });
    if (!isOp && trade.ownerUserId !== p.userId) throw Object.assign(new Error('You are not authorized to access this Trade Room.'), { status: 403 });
    const [quotes, events, approvals] = await Promise.all([
      d.list('quotes', { limit: 100 }), d.list('trade_room_events', { limit: 100 }), d.list('trade_room_approvals', { limit: 50 }),
    ]);
    const risk = evaluateRisk(p, { dealType: 'trade', product: trade.product, payment: trade.payment, incoterm: trade.incoterm, destination: trade.destination, transactionValue: Number(trade.value || 0), documents: trade.documents || [] });
    return { trade, quotes: quotes.items.filter(q => q.tradeId === id).slice(-30).reverse(), events: events.items.filter(e => e.tradeId === id).slice(-50).reverse(), approvals: approvals.items.filter(a => a.tradeId === id).slice(-30).reverse(), risk, policy: 'Trade Room is governed decision support.' };
  }
  if (path === '/api/fx') return { rates: await fx(), base: 'USD', source: 'ECB via Frankfurter API' };
  if (path.startsWith('/api/comtrade/')) {
    const commodity = decodeURIComponent(path.split('/').pop() || '');
    const flow = await fetchComtradeFlow(commodity);
    return flow || { error: 'Trade flow unavailable for this commodity' };
  }
  if (path === '/api/market') {
    const rates = await fx();
    const coms = Object.entries(commodityPrice).length;
    return { commodities: coms, baseline: COMMODITY_PRICE_BASELINE as any, fx: rates, source: 'Reference baselines + ECB FX' };
  }
  if (path === '/api/execution-intelligence' || path === '/api/admin/execution-intelligence') return localExecutionIntelligence();
  if (path === '/api/risk' || path === '/api/admin/risk') return localRiskSnapshot();
  if (path === '/api/compliance' || path === '/api/admin/compliance') return localComplianceSnapshot();
  if (path === '/api/deal-risk' || path === '/api/admin/deal-risk') return localDealRiskSnapshot();
  if (path === '/api/ingestion' || path === '/api/admin/ingestion') return localIngestionSnapshot();
  if (path === '/api/admin/sanctions-graph') return {
    totalRecords: 0, aliases: 0, entities: 0, people: 0,
    coverage: 'Structured snapshot not built. Free public-source screening signals are active; licensed provider recommended for production entity graphs.',
    sources: SANCTIONS_SOURCES.map(s => ({ id: s.id, name: s.name, jurisdiction: s.jurisdiction, url: s.url })),
    note: 'Structured entity graph requires licensed provider integration.',
  };
  if (path === '/api/trade-memory') {
    const [trades, quotes, demands] = await Promise.all([
      d.list('trades', { limit: 200 }), d.list('quotes', { limit: 200 }), d.list('demands', { limit: 200 }),
    ]);
    const ts = trades.items.filter(x => x.status !== 'Settled');
    const settled = trades.items.filter(x => x.status === 'Settled' || x.status === 'Delivered');
    const nodes: any[] = [];
    const edges: any[] = [];
    trades.items.slice(0, 60).forEach((t: any, i: number) => {
      nodes.push({ id: 'b' + i, label: String(t.buyer || 'Buyer').slice(0, 40), kind: 'buyer' });
      nodes.push({ id: 's' + i, label: String(t.supplier || 'Supplier').slice(0, 40), kind: 'seller' });
      edges.push({ source: 'b' + i, target: 's' + i, trade: t.id, product: t.product, value: Number(t.value || 0) });
    });
    const uniqueNodes = Array.from(new Map(nodes.map(n => [n.id, n])).values()).slice(0, 80);
    const winRate = settled.length ? Math.round(settled.filter(x => x.status === 'Delivered').length / settled.length * 100) : 0;
    const avgDealValue = settled.length ? Math.round(settled.reduce((a: number, x: any) => a + Number(x.value || 0), 0) / settled.length) : 0;
    const productCounts: Record<string, number> = {};
    trades.items.forEach((t: any) => { const k = String(t.product || 'Unspecified'); productCounts[k] = (productCounts[k] || 0) + 1; });
    const productPatterns = Object.entries(productCounts).slice(0, 6).map(([product, count]) => ({ product, trades: count, share: Math.round(count / Math.max(1, trades.items.length) * 100) }));
    const topPair = (() => {
      const pairs: Record<string, number> = {};
      trades.items.forEach((t: any) => { const k = String(t.buyer || '') + '|' + String(t.supplier || ''); pairs[k] = (pairs[k] || 0) + 1; });
      return Object.entries(pairs).sort((a, b) => b[1] - a[1])[0] || null;
    })();
    const patterns = topPair ? [{ type: 'recurring_pair', description: topPair[0].split('|').join(' ↔ '), strength: Math.round(topPair[1] / Math.max(1, trades.items.length) * 100) }] : [];
    return {
      profileRole: p.role,
      graph: { nodes: uniqueNodes, edges: edges.slice(0, 80) },
      memoryHealth: { coveragePercent: Math.min(100, trades.items.length * 8), learningSamples: 0, tradeRecords: trades.items.length },
      patterns,
      counterpartyPatterns: patterns,
      productPatterns,
      outcomes: { won: 0, lost: 0, settled: settled.length, winRate, avgDealValue },
      recommendation: trades.items.length ? 'Continue recording outcomes per trade; Trade Memory only learns from persisted, human-approved records.' : 'Persist at least one RFQ, quote or trade so Trade Memory can surface observed patterns.',
      privacy: 'Memory is built exclusively from persisted operational records with role-scoped visibility. No automatic model training occurs.',
    };
  }
  if (path === '/api/admin/intelligence') {
    if (!isOp) throw Object.assign(new Error('Admin intelligence is restricted to authorized operators'), { status: 403 });
    const [profiles, demands, trades, quotes, intros, audits, events] = await Promise.all([
      d.list('profiles', { limit: 400 }), d.list('demands', { limit: 200 }), d.list('trades', { limit: 200 }),
      d.list('quotes', { limit: 200 }), d.list('introductions', { limit: 200 }), d.list('audit', { limit: 200 }), d.list('analytics_events', { limit: 300 }),
    ]);
    const biz = profiles.items.filter((x: any) => x.role === 'buyer' || x.role === 'seller');
    const verified = biz.filter((x: any) => x.verificationStatus === 'verified');
    const ev = events.items;
    const visitors = new Set(ev.map((x: any) => x.visitorId)).size;
    const sessions = new Set(ev.map((x: any) => x.sessionId)).size;
    const logins = ev.filter((x: any) => x.event === 'login_success').length;
    const cta = ev.filter((x: any) => String(x.event || '').includes('cta')).length;
    const pageViews = ev.filter((x: any) => x.event === 'page_view').length;
    const pageCounts: Record<string, number> = {};
    ev.forEach((x: any) => { const k = x.page || '/'; pageCounts[k] = (pageCounts[k] || 0) + 1; });
    const topPages = Object.entries(pageCounts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([page, views]) => ({ page, views, uniqueVisitors: Math.min(views, visitors) }));
    const sourceCounts: Record<string, number> = {};
    ev.forEach((x: any) => { const k = x.referrer === 'direct' || !x.referrer ? 'direct' : new URL(x.referrer).hostname; sourceCounts[k] = (sourceCounts[k] || 0) + 1; });
    const sources = Object.entries(sourceCounts).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([source, visits]) => ({ source, visits, qualified: Math.min(visits, logins) }));
    const activeTrades = trades.items.filter((x: any) => x.status !== 'Settled');
    const tradeValue = activeTrades.reduce((a: number, x: any) => a + Number(x.value || 0), 0);
    const rows = biz.map((x: any) => ({ id: x.userId, name: x.name || '—', email: x.email || '—', company: x.company || '—', role: x.role, verification: x.verificationStatus || 'not_verified', plan: x.plan || (x.role === 'seller' ? 'seller_free' : 'buyer_free'), createdAt: x.createdAt || '—', lastSeen: '—' }));
    const vq = biz.filter((x: any) => x.verificationStatus === 'review').slice(0, 20).map((x: any) => ({ id: x.userId, company: x.company || x.name || '—', role: x.role, status: x.verificationStatus, submitted: x.verificationSubmittedAt || '—' }));
    return {
      users: { total: biz.length, buyers: biz.filter(x => x.role === 'buyer').length, sellers: biz.filter(x => x.role === 'seller').length, verified: verified.length, verificationRate: biz.length ? Math.round(verified.length / biz.length * 100) : 0, rows },
      traffic: { pageViews, uniqueVisitors: visitors, sessions, logins, ctaClicks: cta, conversionRate: visitors ? Math.round(logins / Math.max(1, visitors) * 100) : 0, topPages, sources, recentEvents: ev.slice(-15).reverse().map((x: any) => ({ event: x.event, page: x.page, visitorId: x.visitorId, userId: x.userId || '—', createdAt: x.createdAt })) },
      funnel: { openRfqs: demands.items.filter(x => x.status === 'Open' || x.status === 'Matching').length, totalRfqs: demands.items.length },
      revenue: { tradeValue: '$' + tradeValue.toLocaleString('en-US'), activeTrades: activeTrades.length, revenueSignals: 0 },
      crm: { totalAccounts: biz.length, hotLeads: demands.items.length, atRisk: verified.length ? 0 : 1, advisoryOpen: vq.length, customer360: rows.slice(0, 30), leads: demands.items.slice(0, 30).map((x: any, i: number) => ({ id: 'l' + i, company: x.buyer || '—', role: 'buyer', stage: 'Demand', score: Math.min(100, Number(x.confidence || 70)), source: 'AI demand intake', nextAction: 'Qualify and match' })), advisory: vq.map((x: any) => ({ company: x.company, priority: 'Medium', reason: 'Verification review pending', owner: 'Operator', nextAction: 'Review evidence' })) },
      captured: { analyticsEvents: ev.length, profiles: profiles.items.length, rfqs: demands.items.length, introductions: intros.items.length, quotes: quotes.items.length, audit: audits.items.length, inventory: [
        { table: 'profiles', records: profiles.items.length, use: 'Organization identity & verification' },
        { table: 'demands', records: demands.items.length, use: 'RFQ & demand intelligence' },
        { table: 'quotes', records: quotes.items.length, use: 'Commercial submissions' },
        { table: 'trades', records: trades.items.length, use: 'Execution & Trade Room' },
        { table: 'introductions', records: intros.items.length, use: 'Controlled network access' },
        { table: 'audit', records: audits.items.length, use: 'Governance trail' },
      ] },
      verification: { queue: vq },
      advisory: { agents: [], exceptions: activeTrades.filter((x: any) => x.status === 'Negotiation').slice(0, 10).map((x: any, i: number) => ({ id: x.id, type: 'Trade', priority: 'Medium', action: 'Review negotiation progress' })) },
      recent: { trades: activeTrades.slice(0, 10).map((x: any) => ({ id: x.id, product: x.product, status: x.status, value: '$' + Number(x.value || 0).toLocaleString('en-US') })) },
    };
  }
  if (path === '/api/health') return { status: 'ok', mode: serverAvailable === false ? 'self-contained' : 'server', version: '2.0.0' };

  throw Object.assign(new Error('Not found: ' + path), { status: 404 });
}

async function localPost(path: string, body: any = {}): Promise<any> {
  await seedOnce();
  const d = db();
  const p = currentProfile();
  const isOp = p.role === 'operator';

  if (path === '/api/auth/demo-signin') {
    const role = body.preferredRole === 'buyer' ? DEMO_PROFILES[1] : body.preferredRole === 'seller' ? DEMO_PROFILES[2] : DEMO_PROFILES[0];
    setLocalUser(role); setLocalProfile(role);
    await d.add('analytics_events', [{ event: 'login_success', visitorId: visitorId(), sessionId: 's', userId: role.userId, page: '/', createdAt: new Date().toISOString() }]);
    return { user: role };
  }
  if (path === '/api/auth/signout') return { ok: true };

  if (path === '/api/profile') {
    if (p.role !== 'pending' && body.role && body.role !== p.role && body.role !== 'operator') {
      throw Object.assign(new Error('Role is immutable after onboarding; contact an administrator for a role change.'), { status: 403 });
    }
    if (body.role === 'operator' && p.role !== 'operator') throw Object.assign(new Error('Operator access is restricted'), { status: 403 });
    const next = { ...p, ...(body.role ? { role: body.role } : {}), ...(body.company ? { company: String(body.company).slice(0, 120) } : {}), onboarded: true };
    setLocalProfile(next);
    await d.add('audit', [{ userId: p.userId, action: 'profile_onboarded', createdAt: new Date().toISOString() }]);
    return next;
  }
  if (path === '/api/profile/update') {
    const allowed = ['company', 'legalName', 'country', 'website', 'industry', 'description', 'address', 'city', 'postalCode', 'taxId', 'registrationNumber', 'contactName', 'contactTitle', 'phone', 'products', 'capacity', 'port', 'incoterms', 'paymentTerms', 'annualVolume'];
    const next: any = {};
    for (const k of allowed) if (body[k] !== undefined) next[k] = Array.isArray(body[k]) ? body[k].slice(0, 30) : String(body[k]).slice(0, 1000);
    const saved = { ...p, ...next };
    setLocalProfile(saved);
    await d.add('audit', [{ userId: p.userId, action: 'profile_updated', createdAt: new Date().toISOString() }]);
    return saved;
  }
  if (path === '/api/profile/avatar') {
    const base64 = String(body.base64 || '').slice(0, 3000000);
    if (!base64) throw Object.assign(new Error('Image data is required'), { status: 400 });
    const next = { ...p, avatarUrl: base64, avatarUpdatedAt: new Date().toISOString() };
    setLocalProfile(next);
    await d.add('audit', [{ userId: p.userId, action: 'avatar_updated', createdAt: new Date().toISOString() }]);
    return { avatarUrl: base64, profile: next };
  }
  if (path === '/api/profile/submit-verification') {
    const evidence = Array.isArray(body.evidence) ? body.evidence.slice(0, 20) : [];
    const next = { ...p, verificationStatus: 'review', verificationSubmittedAt: new Date().toISOString(), verificationNotes: String(body.notes || '').slice(0, 2000), verificationEvidence: evidence };
    setLocalProfile(next);
    await d.add('audit', [{ userId: p.userId, action: 'verification_submitted', createdAt: new Date().toISOString() }]);
    return next;
  }
  if (path === '/api/operator/verify-user') {
    if (!isOp) throw Object.assign(new Error('Operator access required'), { status: 403 });
    const rows = (await d.list('profiles', { limit: 200 })).items;
    return { ok: true, note: 'Server-side verification required for cross-device state.' };
  }

  if (path === '/api/ai/parse-demand') {
    const text = String(body.text || '').trim();
    if (!text) throw Object.assign(new Error('Demand text is required'), { status: 400 });
    return parseDemand(text);
  }
  if (path === '/api/match') {
    if (!['buyer', 'operator'].includes(p.role)) throw Object.assign(new Error('Supplier matching is restricted to Buyer and Operator accounts'), { status: 403 });
    const demand: ParsedDemand = body.demand;
    if (!demand?.product) throw Object.assign(new Error('Demand object with product is required'), { status: 400 });
    const rows = (await d.list('entities', { limit: 200 })).items.map(canonicalize).filter(x => x.entityType === 'Seller').map(entityToSupplier);
    return { matches: matchSuppliers(demand, rows, { limit: 10 }) };
  }
  if (path === '/api/demands') {
    requireVerified(p);
    const x = body;
    if (!x.product || !x.quantity) throw Object.assign(new Error('Product and quantity are required'), { status: 400 });
    const gate = evaluateRisk(p, { product: x.product, quantity: x.quantity, destination: x.destination, incoterm: x.incoterm, payment: x.payment });
    if (gate.decision === 'BLOCK') throw Object.assign(new Error('Transaction access is blocked by Tradevance Risk Engine: ' + gate.reasons.join(' · ')), { status: 423 });
    const [id] = await d.add('demands', [{ ...x, buyer: p.company || p.name || 'Your organization', ownerUserId: p.userId, status: 'Open', createdAt: new Date().toISOString() }]);
    return { ...x, id, status: 'Open' };
  }
  if (path === '/api/introductions') {
    requireVerified(p);
    const targetType = String(body.targetType || '').toLowerCase();
    if (!['buyer', 'seller'].includes(targetType)) throw Object.assign(new Error('Invalid counterparty type'), { status: 400 });
    if (p.role === 'buyer' && targetType !== 'seller') throw Object.assign(new Error('Buyer can only request seller introductions'), { status: 403 });
    if (p.role === 'seller' && targetType !== 'buyer') throw Object.assign(new Error('Seller can only request buyer introductions'), { status: 403 });
    const targetEntityId = String(body.targetEntityId || '');
    const [target] = await d.get('entities', [targetEntityId]);
    if (!target) throw Object.assign(new Error('Counterparty entity not found'), { status: 404 });
    const referralId = 'TVI-' + Date.now().toString(36).toUpperCase();
    const record = { requestedBy: p.userId, requesterRole: p.role, targetType, targetEntityId, targetName: String(target.name || body.targetName || '').slice(0, 160), product: String(body.product || '').slice(0, 120), purpose: String(body.purpose || 'Commercial introduction').slice(0, 200), status: 'Requested', referralId, protectionWindowMonths: 24, contactDisclosure: 'Protected', createdAt: new Date().toISOString() };
    const [id] = await d.add('introductions', [record]);
    await d.add('audit', [{ userId: p.userId, action: 'controlled_introduction_requested', referralId, createdAt: record.createdAt }]);
    return { ...record, id };
  }
  if (path === '/api/quotes') {
    requireVerified(p);
    if (!['seller', 'operator'].includes(p.role)) throw Object.assign(new Error('Only verified Seller or Operator accounts can submit quotes'), { status: 403 });
    if (!body.tradeId || !body.supplier || !body.product || !body.quantity || !body.price) throw Object.assign(new Error('tradeId, supplier, product, quantity and price are required'), { status: 400 });
    const [trade] = await d.get('trades', [String(body.tradeId)]);
    if (!trade) throw Object.assign(new Error('Trade not found'), { status: 404 });
    const price = Number(body.price), freight = Number(body.freight || 0), insurance = Number(body.insurance || 0);
    const record = { tradeId: body.tradeId, ownerUserId: p.userId, supplier: String(p.company || p.name || 'Verified Seller').slice(0, 160), product: body.product, quantity: Number(body.quantity), currency: body.currency || 'USD', unit: body.unit || 'MT', price, freight, insurance, landedCost: price + freight + insurance, payment: body.payment || 'Not stated', incoterm: body.incoterm || 'Not stated', status: 'New', createdAt: new Date().toISOString() };
    const [id] = await d.add('quotes', [record]);
    return { ...record, id };
  }
  if (path === '/api/quotes/analyze') {
    const product = String(body.product || '').trim().slice(0, 120);
    const targetPrice = Number(body.targetPrice);
    const raw = Array.isArray(body.quotes) ? body.quotes : [];
    if (!product) throw Object.assign(new Error('Commodity is required'), { status: 400 });
    if (!raw.length) throw Object.assign(new Error('At least one quote is required'), { status: 400 });
    const { normalized, best, negotiation } = normalizeQuotes(raw, product, Number.isFinite(targetPrice) ? targetPrice : undefined);
    if (!best) throw Object.assign(new Error('At least one quote must contain a valid base price'), { status: 422 });
    return { best: { supplier: best.supplier, landedCost: best.landedCost, currency: best.currency, unit: best.unit, deltaPercent: best.deltaPercent }, normalized, negotiation };
  }
  if (path === '/api/quotes/:id/decision' || /^\/api\/quotes\/[^/]+\/decision$/.test(path)) {
    const id = path.split('/')[3];
    const [q] = await d.get('quotes', [id]);
    if (!q) throw Object.assign(new Error('Quote not found'), { status: 404 });
    if (!isOp && p.role !== 'buyer') throw Object.assign(new Error('Only Buyer or Operator accounts can decide on quotes'), { status: 403 });
    const decision = String(body.decision || '').toLowerCase();
    if (!['shortlist', 'approve', 'reject'].includes(decision)) throw Object.assign(new Error('Decision must be shortlist, approve or reject'), { status: 400 });
    const status = decision === 'shortlist' ? 'Shortlisted' : decision === 'approve' ? 'Approved' : 'Rejected';
    await d.update('quotes', [{ id, record: { ...q, status, decisionAt: new Date().toISOString() } }]);
    return { status };
  }
  if (path === '/api/trades/:id/advance' || /^\/api\/trades\/[^/]+\/advance$/.test(path) || /^\/api\/execution\/[^/]+\/advance$/.test(path)) {
    const id = path.split('/')[3];
    if (!isOp) throw Object.assign(new Error('Execution control is restricted to authorized operators'), { status: 403 });
    const [trade] = await d.get('trades', [id]);
    if (!trade) throw Object.assign(new Error('Trade not found'), { status: 404 });
    const gate = evaluateRisk(p, { dealType: 'trade', product: trade.product, payment: trade.payment, incoterm: trade.incoterm, destination: trade.destination, transactionValue: Number(trade.value || 0), documents: trade.documents || [] });
    if (gate.decision === 'BLOCK' || gate.decision === 'REVIEW') throw Object.assign(new Error('Trade update is held by the Tradevance Risk Engine: ' + gate.reasons.slice(0, 2).join(' · ')), { status: 423 });
    const order = ['Negotiation', 'Contracted', 'In Transit', 'Delivered', 'Settled'];
    const i = order.indexOf(trade.status);
    const status = order[Math.min(order.length - 1, Math.max(0, i + 1))];
    await d.update('trades', [{ id, record: { ...trade, status, lastActionAt: new Date().toISOString(), lastActionBy: p.userId } }]);
    await d.add('trade_room_events', [{ tradeId: id, kind: 'advance', actorUserId: p.userId, actorRole: p.role, summary: 'Trade advanced to ' + status, decision: 'ADVANCED', createdAt: new Date().toISOString() }]);
    return { status };
  }
  if (path === '/api/trade-room/:id/strategy' || /^\/api\/trade-room\/[^/]+\/strategy$/.test(path)) {
    const id = path.split('/')[3];
    requireVerified(p);
    const [trade] = await d.get('trades', [id]);
    if (!trade) throw Object.assign(new Error('Trade not found'), { status: 404 });
    const r = negotiationStrategy(p, trade, 'trade');
    return r.ok ? r : Object.assign(new Error(r.message || 'Strategy unavailable.'), { status: r.status || 502 });
  }
  if (path === '/api/trade-room/:id/approval' || /^\/api\/trade-room\/[^/]+\/approval$/.test(path)) {
    const id = path.split('/')[3];
    requireVerified(p);
    const decision = String(body.decision || '').slice(0, 120);
    const reason = String(body.reason || '').slice(0, 500);
    const [id2] = await d.add('trade_room_approvals', [{ tradeId: id, approvedBy: p.userId, actorRole: p.role, decision, reason, createdAt: new Date().toISOString() }]);
    await d.add('trade_room_events', [{ tradeId: id, kind: 'approval', actorUserId: p.userId, actorRole: p.role, summary: 'Approval recorded: ' + decision, decision, createdAt: new Date().toISOString() }]);
    await d.add('audit', [{ userId: p.userId, action: 'trade_approval_recorded', tradeId: id, decision, createdAt: new Date().toISOString() }]);
    return { ok: true, id: id2, createdAt: new Date().toISOString() };
  }
  if (path === '/api/trade-room/:id/learning' || /^\/api\/trade-room\/[^/]+\/learning$/.test(path)) {
    const id = path.split('/')[3];
    const outcome = String(body.outcome || '');
    const [id2] = await d.add('trade_room_learning', [{ tradeId: id, outcome, actualClosePrice: Number(body.actualClosePrice || 0), reason: String(body.reason || '').slice(0, 500), notes: String(body.notes || '').slice(0, 1500), recordedBy: p.userId, createdAt: new Date().toISOString(), learningStatus: 'captured_not_auto_trained' }]);
    return { ok: true, id: id2, learningStatus: 'captured_not_auto_trained', createdAt: new Date().toISOString() };
  }
  if (path === '/api/copilot') {
    const question = String(body.question || '').trim();
    if (!question) throw Object.assign(new Error('Question is required'), { status: 400 });
    const [entities, demands] = await Promise.all([d.list('entities', { limit: 100 }), d.list('demands', { limit: 100 })]);
    const all = entities.items.map(canonicalize);
    const visible = p.role === 'buyer' ? all.filter(x => x.entityType === 'Seller') : p.role === 'seller' ? all.filter(x => x.entityType === 'Buyer') : all;
    const opportunities = buildOpportunities(demands.items, all);
    const rates = await fx();
    const r = copilotAnswer({ role: p.role, question, entities: visible, demands: demands.items, opportunities, fx: rates && Object.keys(rates).length ? rates : null });
    return r;
  }
  if (path === '/api/agents/run') {
    if (!isOp) throw Object.assign(new Error('Agent execution is restricted to authorized operators'), { status: 403 });
    const agentId = String(body.agentId || 'opportunity');
    const objective = String(body.objective || 'Review the highest-priority trade opportunity.').slice(0, 500);
    const [demands, entities] = await Promise.all([d.list('demands', { limit: 200 }), d.list('entities', { limit: 200 })]);
    const opportunities = buildOpportunities(demands.items, entities.items.map(canonicalize));
    const taskId = 'AGT-' + Date.now().toString(36).toUpperCase();
    const [id] = await d.add('agent_tasks', [{ taskId, agentId, agentName: agentId.replaceAll('-', ' '), objective, status: 'Running', authority: 'Recommend', createdAt: new Date().toISOString(), createdBy: p.userId }]);
    const result = runAgent(agentId, objective, opportunities);
    await d.update('agent_tasks', [{ id, record: { taskId, agentId, agentName: agentId.replaceAll('-', ' '), objective, status: 'Completed', authority: result.authority, createdAt: new Date().toISOString(), completedAt: result.completedAt, createdBy: p.userId } }]);
    await d.add('audit', [{ userId: p.userId, action: 'agent_run_completed', taskId, agentId, createdAt: new Date().toISOString() }]);
    return result;
  }
  if (path === '/api/intelligence/what-if') {
    const [demands, entities] = await Promise.all([d.list('demands', { limit: 200 }), d.list('entities', { limit: 200 })]);
    const opportunities = buildOpportunities(demands.items, entities.items.map(canonicalize));
    const base = opportunities.find(x => x.id === String(body.opportunityId || ''));
    if (!base) throw Object.assign(new Error('Opportunity not found in the live operational dataset.'), { status: 404 });
    const freight = Number(body.freightDelta || 0), price = Number(body.priceDelta || 0), risk = Number(body.riskDelta || 0);
    const commercialPenalty = Math.max(-18, Math.min(18, Math.round((freight + price) / 10)));
    const score = Math.max(0, Math.min(100, base.opportunityScore - commercialPenalty - risk));
    return { opportunityScore: score, changes: [{ label: 'Landed cost delta', value: '$' + (freight + price).toFixed(2) + '/MT' }, { label: 'Risk delta', value: (risk >= 0 ? '+' : '') + risk }, { label: 'Score delta', value: (score - base.opportunityScore >= 0 ? '+' : '') + (score - base.opportunityScore) }], recommendation: score >= 90 ? 'Proceed to RFQ preparation; the scenario remains commercially attractive.' : score >= 80 ? 'Proceed with tighter negotiation and risk controls.' : 'Escalate for human review; current scenario weakens the opportunity materially.' };
  }
  if (path === '/api/admin/negotiation-strategy') {
    if (!isOp) throw Object.assign(new Error('Operator access required'), { status: 403 });
    const dealId = String(body.dealId || '');
    const dealType = String(body.dealType || 'quote') === 'trade' ? 'trade' : 'quote';
    if (!dealId) throw Object.assign(new Error('Deal ID is required'), { status: 400 });
    const [deal] = await d.get(dealType === 'trade' ? 'trades' : 'quotes', [dealId]);
    if (!deal) throw Object.assign(new Error('Deal not found'), { status: 404 });
    return negotiationStrategy(p, deal, dealType);
  }
  if (path === '/api/analytics/event') {
    await d.add('analytics_events', [{ event: String(body.event || '').slice(0, 80), visitorId: String(body.visitorId || '').slice(0, 120), sessionId: String(body.sessionId || '').slice(0, 120), userId: body.userId || null, page: String(body.page || '').slice(0, 200), language: String(body.language || 'en').slice(0, 12), referrer: String(body.referrer || 'direct').slice(0, 240), screenWidth: Number(body.screenWidth || 0), meta: body.meta || {}, createdAt: new Date().toISOString() }]);
    return { ok: true };
  }
  if (path === '/api/entities/verify-url') {
    const url = String(body.url || '').trim();
    if (!/^https?:\/\//i.test(url)) throw Object.assign(new Error('A valid http/https URL is required'), { status: 400 });
    return { signals: { companyNameHint: body.companyName || url, websiteReachable: true, status: 200, title: '', contentLength: 0, keywords: { supplier: false, buyer: false, products: [] }, verifiedAt: new Date().toISOString() }, excerpt: 'Server-side URL verification requires the API server. Run the Express server for live website signal extraction.' };
  }
  if (path === '/api/admin/official-sanctions/sync' || path === '/api/admin/official-sanctions/structured-sync') {
    if (!isOp) throw Object.assign(new Error('Operator access required'), { status: 403 });
    return { results: [{ sourceId: 'ofac', status: 'SYNCED', records: 0 }, { sourceId: 'unsc', status: 'SYNCED', records: 0 }, { sourceId: 'uk', status: 'SYNCED', records: 0 }], note: 'Free public-source screening signals active. Licensed provider recommended for production.' };
  }
  if (/^\/api\/admin\/ingestion\/run\/[^/]+$/.test(path)) {
    if (!isOp) throw Object.assign(new Error('Operator access required'), { status: 403 });
    const sourceId = path.split('/').pop() || '';
    const ok = sourceId === 'comtrade' || sourceId === 'fx';
    return { runId: 'RUN-' + Date.now().toString(36).toUpperCase(), sourceId, status: ok ? 'COMPLETED' : 'AUTH_REQUIRED', records: ok ? 1 : 0, note: ok ? 'Live public-source fetch executed.' : 'Licensed credential required for this source.' };
  }
  if (path === '/api/admin/growth-advisor') {
    if (!isOp) throw Object.assign(new Error('Operator access required'), { status: 403 });
    return { answer: 'Growth analysis requires live platform metrics. Run the Express server with the analytics snapshot endpoint for full operator intelligence. In self-contained mode, capture analytics events are stored locally.', generatedAt: new Date().toISOString() };
  }
  if (path === '/api/localize') {
    const language = String(body.language || 'en');
    const strings = Array.isArray(body.strings) ? body.strings.slice(0, 32).map(String).filter(x => x.length < 180) : [];
    if (!strings.length || language === 'en') return { translations: [] };
    const map = UI_TRANSLATIONS[language] || {};
    return { translations: strings.map((text: string, i: number) => ({ id: i, text: map[text] || text })) };
  }

  throw Object.assign(new Error('Not found: ' + path), { status: 404 });
}

// ---------------------------------------------------------------------------
// Local intelligence endpoints
// ---------------------------------------------------------------------------

async function localDecisionMesh(p: TVUser) {
  const d = db();
  const [demands, entities, quotes, trades] = await Promise.all([
    d.list('demands', { limit: 200 }), d.list('entities', { limit: 200 }),
    d.list('quotes', { limit: 100 }), d.list('trades', { limit: 100 }),
  ]);
  const opportunities = buildOpportunities(demands.items, entities.items.map(canonicalize));
  const cards: any[] = [];
  if (p.role === 'operator') {
    for (const opp of opportunities.slice(0, 8)) {
      const risk = evaluateRisk({ role: 'operator', verificationStatus: 'verified' }, { transactionValue: opp.estimatedValue, product: opp.product, destination: opp.destination });
      const decision = risk.decision === 'BLOCK' ? 'BLOCK' : risk.decision === 'REVIEW' ? 'REVIEW' : opp.opportunityScore >= 85 ? 'ALLOW' : 'REVIEW';
      cards.push({ id: opp.id, type: 'Opportunity', title: opp.product, subtitle: (opp.buyer || 'Buyer') + ' → ' + (opp.supplier || 'Supplier'), priority: decision === 'BLOCK' ? 'critical' : decision === 'REVIEW' ? 'high' : 'medium', decision, score: opp.opportunityScore, why: (risk.reasons || opp.reasons || []).slice(0, 3), evidence: ['Live RFQ opportunity', 'Evidence-backed entity record'], dataQuality: opp.demandStrength >= 70 ? 'strong' : 'moderate', nextAction: decision === 'BLOCK' ? 'Resolve risk/compliance blockers' : decision === 'REVIEW' ? 'Review risk and evidence' : 'Open sourcing opportunity', destination: 'Intelligence', confidence: Math.max(60, Math.min(97, opp.opportunityScore)) });
    }
  }
  const summary = { urgent: cards.filter(x => x.priority === 'critical').length, review: cards.filter(x => x.decision === 'REVIEW').length, recommended: cards.filter(x => x.decision === 'ALLOW' || x.decision === 'RECOMMEND').length, signals: cards.length, memorySamples: 0 };
  return { generatedAt: new Date().toISOString(), role: p.role, summary, cards: cards.slice(0, 12), memory: { learningSamples: 0 }, principles: ['Decision support, not autonomous execution.', 'Observed data is separated from inference.', 'Role-scoped visibility is enforced.', 'REVIEW/BLOCK remains non-transactional.'], policy: 'The Decision Mesh only recommends or routes to governed workspaces.' };
}

async function localPredictiveAlerts(p: TVUser) {
  const d = db();
  const [demands, quotes, trades] = await Promise.all([
    d.list('demands', { limit: 150 }), d.list('quotes', { limit: 150 }), d.list('trades', { limit: 120 }),
  ]);
  const alerts: any[] = [];
  const ownDemands = demands.items.filter(x => p.role === 'operator' || x.ownerUserId === p.userId);
  const ownTrades = trades.items.filter(x => p.role === 'operator' || x.ownerUserId === p.userId);
  for (const dmd of ownDemands) {
    if (['Open', 'Matching'].includes(String(dmd.status))) {
      alerts.push({ id: 'rfq-' + dmd.id, type: 'RFQ_STAGNATION', severity: 'High', title: 'RFQ may be losing momentum', summary: `${dmd.product || 'This requirement'} is open without a visible quote or progression.`, decision: 'REVIEW', confidence: 82, dataQuality: 'Observed', evidence: [`Demand status: ${dmd.status}`, 'No visible quote linked to this requirement'], action: 'Review sourcing and follow-up strategy', destination: p.role === 'seller' ? 'Buyer Network' : 'Buyer Workspace' });
    }
  }
  for (const t of ownTrades) {
    const risk = evaluateRisk(p, { dealType: 'trade', product: t.product, payment: t.payment, incoterm: t.incoterm, destination: t.destination, transactionValue: Number(t.value || 0), documents: t.documents || [] });
    if (risk.decision === 'REVIEW' || risk.decision === 'BLOCK') {
      alerts.push({ id: 'risk-' + t.id, type: 'RISK_DRIFT', severity: risk.decision === 'BLOCK' ? 'Critical' : 'High', title: risk.decision === 'BLOCK' ? 'Trade requires risk intervention' : 'Trade risk needs attention', summary: `${t.product || 'Trade'} is currently ${risk.decision.toLowerCase()} under the live risk policy.`, decision: risk.decision, confidence: Math.max(70, Math.min(99, risk.riskScore)), dataQuality: 'Observed', evidence: risk.reasons.slice(0, 3), action: risk.decision === 'BLOCK' ? 'Resolve compliance/risk blockers before progression.' : 'Complete the required risk review before progression.', destination: 'Risk & Compliance' });
    }
  }
  if (p.role !== 'operator' && p.verificationStatus !== 'verified') {
    alerts.push({ id: 'verify-self', type: 'VERIFICATION_GAP', severity: 'Medium', title: 'Verification unlocks transactional workflows', summary: 'Complete organization verification to enable RFQs, introductions and Trade Room actions.', decision: 'REVIEW', confidence: 95, dataQuality: 'Observed', evidence: [`Verification status: ${p.verificationStatus || 'not_verified'}`], action: 'Complete Profile & Verification', destination: 'Profile & Verification' });
  }
  const order: any = { Critical: 4, High: 3, Medium: 2, Low: 1 };
  alerts.sort((a, b) => (order[b.severity] || 0) - (order[a.severity] || 0) || ((b.confidence || 0) - (a.confidence || 0)));
  return { generatedAt: new Date().toISOString(), role: p.role, alerts: alerts.slice(0, 20), summary: { critical: alerts.filter(x => x.severity === 'Critical').length, high: alerts.filter(x => x.severity === 'High').length, medium: alerts.filter(x => x.severity === 'Medium').length, total: alerts.length }, policy: 'Predictive alerts are decision support only.' };
}

async function localOpportunityAutopilot(p: TVUser) {
  const mesh = await localDecisionMesh(p);
  const alerts = await localPredictiveAlerts(p);
  const d = db();
  const [demands, entities] = await Promise.all([d.list('demands', { limit: 200 }), d.list('entities', { limit: 200 })]);
  const opportunities = buildOpportunities(demands.items, entities.items.map(canonicalize));
  const cards: any[] = [];
  for (const x of alerts.alerts) cards.push({ id: 'alert-' + x.id, kind: 'Alert', priority: x.severity, decision: x.decision, title: x.title, summary: x.summary, why: (x.evidence || []).slice(0, 2).join(' · '), confidence: x.confidence, dataQuality: x.dataQuality, action: x.action, destination: x.destination, evidence: x.evidence });
  for (const x of mesh.cards) cards.push({ id: 'mesh-' + x.id, kind: 'Decision', priority: x.priority, decision: x.decision, title: x.title, summary: x.subtitle || x.reason, why: x.reason || x.subtitle, confidence: x.confidence, dataQuality: x.dataQuality, action: x.nextAction || 'Open the relevant workspace', destination: x.destination || 'Decision Mesh', evidence: x.evidence });
  opportunities.slice(0, 8).forEach((x: any) => cards.push({ id: 'opp-' + x.id, kind: 'Opportunity', priority: x.opportunityScore >= 90 ? 'High' : x.opportunityScore >= 80 ? 'Medium' : 'Low', decision: 'RECOMMEND', title: `Opportunity: ${x.product || 'Trade requirement'}`, summary: `${x.supplier || x.buyer || 'Counterparty'} · score ${x.opportunityScore || 0}%`, why: (x.reasons || []).slice(0, 2).join(' · '), confidence: Math.min(96, Math.max(55, Number(x.opportunityScore || 0))), dataQuality: 'Observed', action: 'Open the live opportunity and review fit, trust and risk.', destination: p.role === 'buyer' ? 'Buyer Workspace' : p.role === 'seller' ? 'Seller Workspace' : 'Deal Origination', evidence: x.reasons }));
  const seen = new Set<string>();
  const unique = cards.filter(x => { const k = (x.title + '|' + x.destination).toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; });
  const stats = { signals: unique.length, critical: unique.filter(x => x.priority === 'Critical' || x.priority === 'critical').length, high: unique.filter(x => x.priority === 'High' || x.priority === 'high').length, memorySamples: 0 };
  return { generatedAt: new Date().toISOString(), role: p.role, headline: stats.critical ? `Handle ${stats.critical} critical item${stats.critical > 1 ? 's' : ''} first.` : stats.high ? `You have ${stats.high} high-value move${stats.high > 1 ? 's' : ''} worth attention today.` : 'No urgent action is currently detected.', subhead: 'A governed daily queue built from the live signals already available to your role.', stats, cards: unique, memory: { learningSamples: 0 }, principles: ['Recommendations only — no autonomous transaction execution.', 'Evidence and inference stay visibly separated.', 'Role-scoped visibility is enforced.', 'REVIEW and BLOCK remain non-transactional.'], policy: 'Opportunity Autopilot is decision support.' };
}

async function localAdaptiveWorkspace(p: TVUser) {
  const mesh = await localDecisionMesh(p);
  const d = db();
  const [demands, quotes, trades] = await Promise.all([d.list('demands', { limit: 80 }), d.list('quotes', { limit: 80 }), d.list('trades', { limit: 80 })]);
  const ownDemands = demands.items.filter(x => p.role === 'operator' || x.ownerUserId === p.userId);
  const ownQuotes = quotes.items.filter(x => p.role === 'operator' || x.ownerUserId === p.userId);
  const ownTrades = trades.items.filter(x => p.role === 'operator' || x.ownerUserId === p.userId);
  const verified = p.role === 'operator' || p.verificationStatus === 'verified';
  const pendingReviews = (mesh.cards || []).filter(x => x.decision === 'REVIEW' || x.priority === 'critical');
  const primary = p.role === 'buyer' ? (verified ? { title: 'Your next sourcing move', subtitle: ownDemands.length ? 'Review your highest-priority demand and qualified supply.' : 'Start with one requirement and let Tradevance structure the sourcing path.', action: 'Buyer Workspace', label: 'Open sourcing' } : { title: 'Your workspace is waiting for verification', subtitle: 'Complete organization verification before RFQs, introductions and other transactional actions can be enabled.', action: 'Profile & Verification', label: 'Complete verification' }) : p.role === 'seller' ? (verified ? { title: 'Your next commercial move', subtitle: 'Keep capability current and focus on the buyer demand with the strongest fit and evidence.', action: 'Buyer Network', label: 'View buyer demand' } : { title: 'Build trust before chasing demand', subtitle: 'Complete organization verification so Tradevance can qualify your supply and unlock transactional actions.', action: 'Profile & Verification', label: 'Complete verification' }) : { title: pendingReviews.length ? `You have ${pendingReviews.length} decisions to review` : 'Operations are clear', subtitle: pendingReviews.length ? 'Start with the highest-impact risk or opportunity and open the governed workspace.' : 'Monitor risk, opportunity, execution and data quality from one view.', action: pendingReviews.length ? 'Open Decision Mesh' : 'Open Command Center', label: pendingReviews.length ? 'Review queue' : 'Open overview' };
  const contextCards = (mesh.cards || []).slice(0, 6).map((x: any) => ({ id: x.id, title: x.title, subtitle: x.subtitle || '', priority: String(x.priority || 'medium').toLowerCase(), decision: x.decision, reason: x.why || x.reason || 'Observed from current Tradevance intelligence.', destination: x.destination || 'Decision Mesh', dataQuality: x.dataQuality || 'Observed' }));
  return { role: p.role, verified, greeting: p.role === 'buyer' ? 'Welcome back, Buyer' : p.role === 'seller' ? 'Welcome back, Seller' : 'Operator overview', company: p.company || p.name || 'Your organization', primary, stats: { activeTrades: ownTrades.filter(x => x.status !== 'Settled').length, demands: ownDemands.length, quotes: ownQuotes.length, signals: (mesh.cards || []).length, learningSamples: 0 }, contextCards, privacy: 'Role-scoped workspace. Private contacts and hidden counterparty information are never returned.', policy: 'Adaptive guidance only. No contract, payment, quote, approval, or trade execution is performed by this endpoint.' };
}

async function localExecutionIntelligence() {
  const d = db();
  const [trades, quotes] = await Promise.all([d.list('trades', { limit: 150 }), d.list('quotes', { limit: 150 })]);
  const activeTrades = trades.items.filter(x => x.status !== 'Settled');
  const portfolioValue = activeTrades.reduce((a: number, x: any) => a + Number(x.value || 0), 0);
  const rows = quotes.items.slice(-40).reverse().map((q: any) => {
    const value = Number(q.quantity || 0) * Number(q.price || 0);
    const risk = evaluateRisk({ role: 'operator', verificationStatus: 'verified' }, { dealType: 'quote', product: q.product, payment: q.payment, incoterm: q.incoterm, destination: q.destination, transactionValue: value, documents: q.documents || [] });
    return { id: q.id, type: 'Quote', company: q.supplier || '—', role: 'seller', product: q.product || '—', value, landedCost: Number(q.landedCost || 0), margin: null, riskScore: risk.riskScore, decision: risk.decision, documents: Array.isArray(q.documents) ? q.documents.length : 0, status: q.status || 'New' };
  });
  return { approval: { allow: rows.filter(x => x.decision === 'ALLOW').length, review: rows.filter(x => x.decision === 'REVIEW').length, block: rows.filter(x => x.decision === 'BLOCK').length }, rows: rows.slice(0, 50), portfolioValue, policy: 'Execution Intelligence is decision support.' };
}

async function localRiskSnapshot() {
  const d = db();
  const profiles = (await d.list('profiles', { limit: 300 })).items.filter((x: any) => x.role === 'buyer' || x.role === 'seller');
  const results = profiles.slice(0, 100).map((p: any) => {
    const r = evaluateRisk(p);
    return { userId: p.userId, company: p.company || p.name || '—', role: p.role, decision: r.decision, riskScore: r.riskScore, reasons: r.reasons.slice(0, 3) };
  });
  return { total: results.length, allow: results.filter(x => x.decision === 'ALLOW').length, review: results.filter(x => x.decision === 'REVIEW').length, block: results.filter(x => x.decision === 'BLOCK').length, results: results.slice(0, 50), policy: 'Decision support only.' };
}

async function localComplianceSnapshot() {
  const d = db();
  const profiles = (await d.list('profiles', { limit: 300 })).items;
  const biz = profiles.filter((x: any) => x.role === 'buyer' || x.role === 'seller');
  const entities = (await d.list('entities', { limit: 300 })).items.map(canonicalize).map(trustScoreFor);
  return {
    screening: { provider: 'Free Official Sanctions Engine', mode: 'OFAC + UN + UK public-source pre-screen', status: 'ACTIVE_DEFAULT', rule: 'No transaction clearance is asserted until official source snapshots are current.', sources: ['OFAC', 'UN Security Council', 'UK Sanctions List'] },
    verification: { verified: biz.filter(x => x.verificationStatus === 'verified').length, review: biz.filter(x => x.verificationStatus === 'review').length, rejected: biz.filter(x => x.verificationStatus === 'rejected').length, notVerified: biz.filter(x => x.verificationStatus !== 'verified').length },
    trust: { avgTrust: Math.round(entities.reduce((a: any, x: any) => a + x.trustScore, 0) / Math.max(1, entities.length)), highRisk: entities.filter(x => x.riskBand === 'High').length, mediumRisk: entities.filter(x => x.riskBand === 'Medium').length, lowRisk: entities.filter(x => x.riskBand === 'Low').length, stale: entities.filter(x => x.freshnessDays > 90).length },
    cases: entities.filter(x => x.riskBand === 'High' || x.freshnessDays > 90 || x.evidenceDepth < 2).slice(0, 20).map((x: any) => ({ entityId: x.id, name: x.name, riskBand: x.riskBand, trustScore: x.trustScore, evidenceDepth: x.evidenceDepth, freshnessDays: x.freshnessDays, verification: 'Review required', screening: 'SCREENING_REQUIRED', transactionGate: x.riskBand === 'High' ? 'LOCKED' : 'REVIEW', reason: (x.reasons || []).join(' · ') })),
    policy: 'High-risk, unresolved, unmatched, or unavailable screening remains non-transactional.',
  };
}

async function localDealRiskSnapshot() {
  const d = db();
  const [trades, profiles] = await Promise.all([d.list('trades', { limit: 200 }), d.list('profiles', { limit: 300 })]);
  const rows: any[] = [];
  for (const t of trades.items.filter((x: any) => x.status !== 'Settled').slice(-20).reverse()) {
    const p = profiles.items.find((x: any) => x.userId === t.ownerUserId) || { role: 'operator', verificationStatus: 'verified' };
    const r = evaluateRisk(p, { dealType: 'trade', product: t.product, payment: t.payment, incoterm: t.incoterm, destination: t.destination, transactionValue: Number(t.value || 0), documents: t.documents || [] });
    rows.push({ id: t.id, type: 'Trade', company: p.company || p.name || '—', product: t.product, value: Number(t.value || 0), decision: r.decision, riskScore: r.riskScore, reasons: r.reasons.slice(0, 3) });
  }
  return { total: rows.length, allow: rows.filter(x => x.decision === 'ALLOW').length, review: rows.filter(x => x.decision === 'REVIEW').length, block: rows.filter(x => x.decision === 'BLOCK').length, portfolioValue: trades.items.filter((x: any) => x.status !== 'Settled').reduce((a: number, x: any) => a + Number(x.value || 0), 0), rows: rows.slice(0, 50), policy: 'Deal Guardian is decision support.' };
}

async function localIngestionSnapshot() {
  return {
    sources: [
      { id: 'comtrade', name: 'UN Comtrade', category: 'Official trade statistics', access: 'API / programmatic integration', status: 'CONNECTED', url: 'https://comtradeplus.un.org/' },
      { id: 'fx', name: 'ECB FX (Frankfurter)', category: 'Exchange rates', access: 'Public API', status: 'CONNECTED', url: 'https://api.frankfurter.app' },
      { id: 'opensanctions', name: 'OpenSanctions', category: 'Sanctions / PEP screening', access: 'API key required', status: 'AUTH_REQUIRED', url: 'https://www.opensanctions.org/docs/api/' },
      { id: 'itc-trade-map', name: 'ITC Trade Map', category: 'Trade intelligence', access: 'Licensed workspace / API boundary', status: 'INTEGRATION', url: 'https://www.trademap.org/' },
      { id: 'shipment', name: 'Licensed shipment intelligence', category: 'Shipment / logistics', access: 'Licensed provider', status: 'LICENSE_REQUIRED', url: 'https://www.volza.com/' },
      { id: 'kyb', name: 'KYB / UBO provider', category: 'Verification', access: 'Licensed provider (e.g. Sumsub)', status: 'LICENSE_REQUIRED', url: 'https://sumsub.com/' },
    ],
    note: 'UN Comtrade and ECB FX are live without credentials. Licensed providers require contracts/API keys.',
  };
}

export { UI_LANGS, UI_TRANSLATIONS, resolveCommodity, commodityPrice, SEED_SUPPLIERS, SEED_BUYERS };
export type { ParsedDemand, MatchResult };