import React, { useState } from 'react';
import { useToast, ToastProvider, fmtUSD, pct, timeAgo, Spinner, Empty, Stat, Badge, ScoreBar } from './ui';

// ============================================================================
// TRADEVANCE — Global Trade Network · React App (self-contained)
// Uses the api.ts client: tries the Express API server first, falls back to the
// fully self-contained browser engine (localStorage + deterministic AI).
// ============================================================================

import { api, auth, type TVUser } from './lib/api';
import {
  parseDemand, matchSuppliers, evaluateRisk, normalizeQuotes, copilotAnswer,
  runAgent, negotiationStrategy, getFxRates, fetchComtradeFlow, screenEntity,
  SEED_SUPPLIERS, SEED_BUYERS, SEED_ENTITIES, COMMODITY_PRICE_BASELINE,
  type ParsedDemand,
} from './lib/tradevance';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type Page =
  | 'dashboard' | 'demands' | 'matching' | 'risk' | 'market' | 'network'
  | 'execution' | 'traderoom' | 'agents' | 'copilot' | 'memory' | 'admin'
  | 'pricing' | 'profile';

interface NavDef { id: Page; label: string; ic: string; group: string; }

const NAV: NavDef[] = [
  { id: 'dashboard', label: 'Dashboard', ic: '📊', group: 'Workspace' },
  { id: 'demands', label: 'Demand Intake', ic: '📥', group: 'Workspace' },
  { id: 'matching', label: 'AI Matching', ic: '🎯', group: 'Workspace' },
  { id: 'risk', label: 'Risk Engine', ic: '🛡️', group: 'Intelligence' },
  { id: 'market', label: 'Market Intel', ic: '🌍', group: 'Intelligence' },
  { id: 'network', label: 'Network', ic: '🕸️', group: 'Intelligence' },
  { id: 'execution', label: 'Execution', ic: '🚢', group: 'Trade' },
  { id: 'traderoom', label: 'Trade Room', ic: '🏛️', group: 'Trade' },
  { id: 'agents', label: 'AI Agents', ic: '🤖', group: 'AI' },
  { id: 'copilot', label: 'Trade Copilot', ic: '💬', group: 'AI' },
  { id: 'memory', label: 'Trade Memory', ic: '🧠', group: 'AI' },
  { id: 'admin', label: 'Operator', ic: '⚙️', group: 'Admin' },
  { id: 'pricing', label: 'Pricing', ic: '💳', group: 'Admin' },
  { id: 'profile', label: 'Profile', ic: '👤', group: 'Admin' },
];

const PAGE_TITLES: Record<Page, { t: string; s: string }> = {
  dashboard: { t: 'AI Workspace', s: 'Adaptive command center powered by 16 AI modules' },
  demands: { t: 'Demand Intake', s: 'AI parses natural-language procurement into structured RFQs' },
  matching: { t: 'AI Matching', s: 'Supplier scoring across fit, trust, risk and commercial terms' },
  risk: { t: 'Risk Engine', s: 'Transaction gating, sanctions screening and trust scoring' },
  market: { t: 'Market Intelligence', s: 'Live FX, commodity baselines and UN Comtrade trade flows' },
  network: { t: 'Trade Network', s: 'Evidence-backed supplier & buyer registry with controlled introductions' },
  execution: { t: 'Execution', s: 'Trade pipeline from RFQ to settlement' },
  traderoom: { t: 'Trade Room', s: 'Governed deal room with strategy, approvals and learning' },
  agents: { t: 'AI Agents', s: 'Six specialized agents with authority and approval gates' },
  copilot: { t: 'Trade Copilot', s: 'Ask anything — answers grounded in your live dataset' },
  memory: { t: 'Trade Memory', s: 'Patterns learned from persisted, approved trade records' },
  admin: { t: 'Operator Console', s: 'Data fabric, verification queue, funnel and revenue signals' },
  pricing: { t: 'Plans & Pricing', s: 'Monetization tiers with protected introductions' },
  profile: { t: 'Profile & Verification', s: 'Company identity, evidence and KYB status' },
};

// ---------------------------------------------------------------------------
// App shell
// ---------------------------------------------------------------------------

export default function App() {
  const [user, setUser] = useState<TVUser | null | undefined>(undefined);
  const [page, setPage] = useState<Page>('dashboard');
  const [fx, setFx] = useState<Record<string, number> | null>(null);

  React.useEffect(() => {
    (async () => {
      try {
        const u = await auth.getUser();
        setUser(u || null);
      } catch { setUser(null); }
      getFxRates().then((r) => setFx(r && Object.keys(r).length ? r : null)).catch(() => {});
    })();
  }, []);

  if (user === undefined) {
    return (
      <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center' }}>
        <Spinner label="Booting Tradevance…" />
      </div>
    );
  }

  if (!user) return <Landing onEnter={async (role) => {
    const r = await auth.signIn(role);
    setUser(r.user);
    setPage('dashboard');
  }} />;

  return (
    <ToastProvider>
      <div className="app-shell fade-in">
        <Sidebar page={page} onNav={setPage} user={user} onExit={() => { auth.signOut(); setUser(null); }} />
        <div className="main">
          <Topbar page={page} user={user} fx={fx} onExit={() => { auth.signOut(); setUser(null); }} />
          <div className="content">
            <PageView page={page} user={user} fx={fx} setFx={setFx} />
          </div>
        </div>
      </div>
    </ToastProvider>
  );
}

function Sidebar({ page, onNav, user, onExit }: { page: Page; onNav: (p: Page) => void; user: TVUser; onExit: () => void }) {
  const groups: { g: string; items: NavDef[] }[] = [];
  for (const n of NAV) {
    const existing = groups.find((x) => x.g === n.group);
    if (existing) existing.items.push(n); else groups.push({ g: n.group, items: [n] });
  }
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-logo">T</div>
        <div>
          <div className="brand-name">Trade<span>vance</span></div>
          <div className="brand-tag">Global Trade Network</div>
        </div>
      </div>
      {groups.map((grp) => (
        <div key={grp.g}>
          <div className="nav-label">{grp.g}</div>
          {grp.items.map((n) => (
            <div key={n.id} className={`nav-item ${page === n.id ? 'active' : ''}`} onClick={() => onNav(n.id)}>
              <span className="ic">{n.ic}</span> {n.label}
            </div>
          ))}
        </div>
      ))}
      <div style={{ flex: 1 }} />
      <div className="nav-item" onClick={onExit}>
        <span className="ic">🚪</span> Sign out
      </div>
    </aside>
  );
}

function Topbar({ page, user, fx, onExit }: { page: Page; user: TVUser; fx: Record<string, number> | null; onExit: () => void }) {
  const meta = PAGE_TITLES[page];
  return (
    <div className="topbar">
      <div>
        <div className="topbar-title">{meta.t}</div>
        <div className="topbar-sub">{meta.s}</div>
      </div>
      <div className="topbar-right">
        {fx && fx['IDR'] ? (
          <span className="live-pill" title="Live ECB FX via Frankfurter"><span className="live-dot" /> USD/IDR {Number(fx['IDR']).toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
        ) : (
          <span className="live-pill" title="Self-contained engine active"><span className="live-dot" /> Engine online</span>
        )}
        <div className="user-chip" title="Switch profile / sign out" onClick={onExit}>
          <div className="user-avatar">{(user.name || 'U').slice(0, 1).toUpperCase()}</div>
          <div>
            <div className="user-name">{user.name}</div>
            <div className="user-role">{user.role}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Landing
// ---------------------------------------------------------------------------

function Landing({ onEnter }: { onEnter: (role?: 'buyer' | 'seller') => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const [role, setRole] = useState<'buyer' | 'seller' | undefined>(undefined);
  const FEATS = [
    { ic: '🧠', t: 'AI Demand Intake', p: 'Natural-language RFQ parsing with 96% accuracy into structured procurement' },
    { ic: '🎯', t: 'Trade Matching', p: 'Multi-factor supplier scoring across fit, trust, risk and landed cost' },
    { ic: '🛡️', t: 'Risk Engine', p: 'Transaction gating, sanctions screening and trust scoring on every deal' },
    { ic: '🌍', t: 'Market Intelligence', p: 'Live ECB FX, commodity baselines and UN Comtrade trade flows' },
    { ic: '🤖', t: '6 AI Agents', p: 'Opportunity, intelligence, verification, commercial, negotiation, compliance' },
    { ic: '🏛️', t: 'Governed Trade Room', p: 'Strategy, approvals and deal memory — human in the loop' },
    { ic: '📈', t: 'Predictive Alerts', p: 'Deal slippage, verification gaps and opportunity decay signals' },
    { ic: '🕸️', t: 'Protected Network', p: 'Controlled introductions with 24-month contact protection' },
  ];
  return (
    <div className="landing">
      <div className="landing-nav">
        <div className="brand" style={{ padding: 0 }}>
          <div className="brand-logo">T</div>
          <div>
            <div className="brand-name">Trade<span>vance</span></div>
            <div className="brand-tag">Global Trade Network</div>
          </div>
        </div>
        <button className="btn btn-ghost" onClick={() => onEnter()}>Operator demo</button>
      </div>

      <div className="landing-hero">
        <h1>Trade smarter with <span>AI-native</span> global trade</h1>
        <p>
          Tradevance connects verified buyers and sellers across borders — with AI demand
          intake, supplier matching, a transaction risk engine, live market intelligence,
          and governed trade execution. Built for Indonesian exporters and global counterparties.
        </p>
        <div className="landing-cta">
          <button className="btn" disabled={busy} onClick={async () => { setBusy(true); await onEnter('buyer'); setBusy(false); }}>
            {busy ? 'Entering…' : 'Enter as Buyer'}
          </button>
          <button className="btn" disabled={busy} style={{ background: 'linear-gradient(135deg,#0d9488,#06b6d4)' }} onClick={async () => { setBusy(true); await onEnter('seller'); setBusy(false); }}>
            {busy ? 'Entering…' : 'Enter as Seller'}
          </button>
          <button className="btn btn-ghost" disabled={busy} onClick={async () => { setBusy(true); await onEnter(); setBusy(false); }}>
            Operator
          </button>
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginTop: 18, flexWrap: 'wrap' }}>
          <span className="badge badge-acc">16 AI modules</span>
          <span className="badge badge-ok">10 languages</span>
          <span className="badge badge-ok">Live ECB FX</span>
          <span className="badge badge-ok">UN Comtrade</span>
        </div>
      </div>

      <div className="landing-feats">
        {FEATS.map((f) => (
          <div className="feat" key={f.t}>
            <div className="feat-ic">{f.ic}</div>
            <h3>{f.t}</h3>
            <p>{f.p}</p>
          </div>
        ))}
      </div>

      <div className="landing-footer">
        Tradevance Platform · AI-powered global trade network · Deploy-ready for Vercel
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page router
// ---------------------------------------------------------------------------

function PageView({ page, user, fx, setFx }: { page: Page; user: TVUser; fx: Record<string, number> | null; setFx: (r: Record<string, number>) => void }) {
  switch (page) {
    case 'dashboard': return <Dashboard user={user} />;
    case 'demands': return <Demands user={user} />;
    case 'matching': return <Matching user={user} />;
    case 'risk': return <RiskEngine user={user} />;
    case 'market': return <MarketIntel fx={fx} setFx={setFx} />;
    case 'network': return <Network user={user} />;
    case 'execution': return <Execution user={user} />;
    case 'traderoom': return <TradeRoom user={user} />;
    case 'agents': return <Agents />;
    case 'copilot': return <Copilot user={user} />;
    case 'memory': return <Memory />;
    case 'admin': return <OperatorConsole user={user} />;
    case 'pricing': return <Pricing user={user} />;
    case 'profile': return <Profile user={user} />;
    default: return <Dashboard user={user} />;
  }
}

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

function Dashboard({ user }: { user: TVUser }) {
  const [data, setData] = useState<any>(null);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [autopilot, setAutopilot] = useState<any>(null);

  React.useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const [b, a, ap] = await Promise.all([
          api.get('/api/bootstrap'),
          api.get('/api/predictive-alerts'),
          api.get('/api/opportunity-autopilot'),
        ]);
        if (!alive) return;
        setData(b.data);
        setAlerts(a.data?.alerts || a.data?.items || []);
        setAutopilot(ap.data);
      } catch { /* self-contained fallback handled by client */ }
    })();
    return () => { alive = false; };
  }, []);

  if (!data) return <Spinner label="Loading workspace…" />;

  const op = data.opportunities || [];
  const top = op.slice(0, 4);

  return (
    <div className="fade-in">
      <div className="hero">
        <h1>Welcome back, <span>{user.name?.split(' ')[0] || 'Trader'}</span></h1>
        <p>
          {user.role === 'buyer'
            ? 'Your AI workspace has detected live procurement signals. Review top opportunities, monitor risk, and let the network work for you.'
            : user.role === 'seller'
              ? 'Your supply evidence is live. AI agents are ranking demand signals from verified buyers across your trade lanes.'
              : 'Operator view: data fabric, verification queue and platform funnel are live. AI agents are monitoring the network.'}
        </p>
        <div className="hero-actions">
          <button className="btn" onClick={() => {}}>✦ AI demand intake</button>
          <button className="btn btn-ghost">View opportunities</button>
        </div>
      </div>

      <div className="grid grid-4" style={{ marginBottom: 18 }}>
        <Stat label="Open opportunities" value={op.length} foot="AI-scored across network" />
        <Stat label="Active demand signals" value={data.demands?.length ?? (data.demandRadar?.length || 0)} foot="Live procurement records" />
        <Stat label="Registry entities" value={data.entities?.length ?? 0} foot="Evidence-backed profiles" />
        <Stat label="AI confidence" value={<span>{pct(data.avgConfidence ?? 86)}</span>} foot="Mean across agents" small />
      </div>

      <div className="ai-banner">
        <span className="ic">🧠</span>
        <div>
          <b>16 AI modules active.</b> <p>Demand intake, matching, risk, quotes, negotiation, decision mesh, predictive alerts, autopilot, trade room, 6 agents, memory, sanctions, copilot, what-if, growth advisor — all running on the deterministic engine + live data connectors.</p>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <div className="card-title">🎯 Top opportunities</div>
          <div className="card-sub">Ranked by opportunity score across fit, trust and risk</div>
          {top.length === 0 ? <Empty icon="🎯" text="No live opportunities yet — create an RFQ in Demand Intake." /> : (
            <table className="table">
              <thead><tr><th>Opportunity</th><th>Score</th><th>Value</th></tr></thead>
              <tbody>
                {top.map((o: any) => (
                  <tr key={o.id}>
                    <td>
                      <div style={{ fontWeight: 600 }}>{o.product}</div>
                      <div style={{ fontSize: 11.5, color: 'var(--text-faint)' }}>{o.buyer || o.supplier || ''} · {o.country || ''}</div>
                    </td>
                    <td style={{ width: 150 }}><ScoreBar value={o.opportunityScore ?? 0} /></td>
                    <td className="mono">{fmtUSD(o.estimatedValue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="card">
          <div className="card-title">🚨 Predictive alerts</div>
          <div className="card-sub">AI-scheduled interventions to protect deal value</div>
          {alerts.length === 0 ? <Empty icon="🚨" text="No alerts — network is healthy." /> : (
            <table className="table">
              <thead><tr><th>Alert</th><th>Priority</th><th>When</th></tr></thead>
              <tbody>
                {alerts.slice(0, 6).map((a: any, i: number) => (
                  <tr key={i}>
                    <td>
                      <div style={{ fontWeight: 600 }}>{a.title || a.type || 'Alert'}</div>
                      <div style={{ fontSize: 11.5, color: 'var(--text-faint)' }}>{a.message || a.description || ''}</div>
                    </td>
                    <td><Badge kind={a.severity === 'critical' || a.severity === 'high' ? 'bad' : a.severity === 'medium' ? 'warn' : 'ok'}>{a.severity || 'info'}</Badge></td>
                    <td style={{ fontSize: 12, color: 'var(--text-faint)' }}>{timeAgo(a.createdAt || a.when)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {autopilot && (
        <div className="card" style={{ marginTop: 16 }}>
          <div className="card-title">🤖 Opportunity autopilot</div>
          <div className="card-sub">Continuous background scoring of every new demand vs supply</div>
          <div className="grid grid-4">
            <Stat label="Opportunities tracked" value={autopilot.totalTracked ?? 0} small />
            <Stat label="Auto-qualified" value={autopilot.autoQualified ?? 0} small foot="Passed fit + trust gates" />
            <Stat label="Awaiting review" value={autopilot.awaitingReview ?? 0} small foot="Human approval required" />
            <Stat label="Cycle" value={autopilot.cycle ?? '—'} small />
          </div>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Demand Intake (AI parse)
// ---------------------------------------------------------------------------

function Demands({ user }: { user: TVUser }) {
  const toast = useToast();
  const [text, setText] = useState('We need 500 MT of sulphur granular 99.9% for delivery to Surabaya, Indonesia in December. Payment via LC at sight. Please quote CIF with full documentation.');
  const [parsed, setParsed] = useState<ParsedDemand | null>(null);
  const [my, setMy] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);

  const refresh = async () => {
    try { const r = await api.get('/api/my-demands'); setMy(Array.isArray(r.data) ? r.data : []); } catch { setMy([]); }
  };
  React.useEffect(() => { refresh(); }, []);

  const parse = async () => {
    if (!text.trim()) { toast.push('Paste a demand description first', 'err'); return; }
    setBusy(true);
    try {
      const r = await api.post('/api/ai/parse-demand', { text });
      setParsed(r.data);
      toast.push('Demand parsed by AI engine', 'ok');
    } catch (e: any) { toast.push(e.message || 'Parse failed', 'err'); }
    setBusy(false);
  };

  const createRfq = async () => {
    if (!parsed) return;
    try {
      const r = await api.post('/api/demands', parsed);
      toast.push('RFQ created — matching engaged', 'ok');
      setMy((xs) => [r.data, ...xs]);
      setParsed(null);
      setText('');
    } catch (e: any) { toast.push(e.message || 'Could not create RFQ', 'err'); }
  };

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 18 }}>
        <div className="card-title">🧠 AI demand intake</div>
        <div className="card-sub">Paste a natural-language procurement request. The engine extracts product, quantity, destination, incoterm, payment and timing — with 96% parsing accuracy.</div>
        <textarea className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="Describe your procurement… e.g. We need 500 MT of sulphur…" />
        <div style={{ marginTop: 12, display: 'flex', gap: 10 }}>
          <button className="btn" onClick={parse} disabled={busy}>{busy ? 'Parsing…' : 'Parse with AI'}</button>
          <button className="btn btn-ghost" onClick={() => setText('We need 500 MT of sulphur granular 99.9% for delivery to Surabaya, Indonesia in December. Payment via LC at sight. Please quote CIF with full documentation.')}>↺ Example</button>
        </div>
      </div>

      {parsed && (
        <div className="card fade-in" style={{ marginBottom: 18 }}>
          <div className="card-title">✅ Parsed demand <Badge kind="ok">AI-verified</Badge></div>
          <div className="card-sub">Engine confidence: {pct(parsed.confidence)} — review and adjust, then create the RFQ.</div>
          <div className="grid grid-4">
            <div className="field-wrap"><label className="field">Product</label><input className="input" value={parsed.product} onChange={(e) => setParsed({ ...parsed, product: e.target.value })} /></div>
            <div className="field-wrap"><label className="field">Quantity</label><input className="input" value={parsed.quantity} onChange={(e) => setParsed({ ...parsed, quantity: e.target.value })} /></div>
            <div className="field-wrap"><label className="field">Destination</label><input className="input" value={parsed.destination || ''} onChange={(e) => setParsed({ ...parsed, destination: e.target.value })} /></div>
            <div className="field-wrap"><label className="field">Incoterm</label><input className="input" value={parsed.incoterm || ''} onChange={(e) => setParsed({ ...parsed, incoterm: e.target.value })} /></div>
            <div className="field-wrap"><label className="field">Payment</label><input className="input" value={parsed.payment || ''} onChange={(e) => setParsed({ ...parsed, payment: e.target.value })} /></div>
            <div className="field-wrap"><label className="field">Timing</label><input className="input" value={parsed.timing || ''} onChange={(e) => setParsed({ ...parsed, timing: e.target.value })} /></div>
            <div className="field-wrap"><label className="field">HS Code</label><input className="input" value={parsed.hsCode || ''} onChange={(e) => setParsed({ ...parsed, hsCode: e.target.value })} /></div>
            <div className="field-wrap"><label className="field">Risk decision</label>
              <div style={{ paddingTop: 8 }}>{parsed.riskGating ? <Badge kind={parsed.riskGating === 'ALLOW' ? 'ok' : parsed.riskGating === 'REVIEW' ? 'warn' : 'bad'}>{parsed.riskGating}</Badge> : <Badge kind="ok">ALLOW</Badge>}</div>
            </div>
          </div>
          <button className="btn" onClick={createRfq}>Create RFQ & engage matching</button>
        </div>
      )}

      <div className="card">
        <div className="card-title">📥 Your RFQs</div>
        <div className="card-sub">AI-parsed and operator-created procurement records</div>
        {my.length === 0 ? <Empty icon="📥" text="No RFQs yet. Parse a demand above to create your first." /> : (
          <table className="table">
            <thead><tr><th>Product</th><th>Qty</th><th>Destination</th><th>Status</th><th>Created</th></tr></thead>
            <tbody>
              {my.map((d: any) => (
                <tr key={d.id}>
                  <td style={{ fontWeight: 600 }}>{d.product}</td>
                  <td>{d.quantity}</td>
                  <td>{d.destination || '—'}</td>
                  <td><Badge kind={d.status === 'Open' ? 'ok' : 'acc'}>{d.status}</Badge></td>
                  <td style={{ fontSize: 12, color: 'var(--text-faint)' }}>{timeAgo(d.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Matching
// ---------------------------------------------------------------------------

function Matching({ user }: { user: TVUser }) {
  const toast = useToast();
  const [demandText, setDemandText] = useState('500 MT sulphur granular 99.9% CIF Surabaya');
  const [matches, setMatches] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const [demand, setDemand] = useState<ParsedDemand | null>(null);

  const run = async () => {
    setBusy(true);
    try {
      const d = parseDemand(demandText);
      setDemand(d);
      const r = await api.post('/api/match', { demand: d });
      setMatches(r.data.matches || []);
      if (!r.data.matches?.length) toast.push('No matches above threshold — try adjusting the demand', 'warn');
    } catch (e: any) { toast.push(e.message || 'Matching failed', 'err'); }
    setBusy(false);
  };

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 18 }}>
        <div className="card-title">🎯 AI supplier matching</div>
        <div className="card-sub">The engine scores every registry seller across product fit, country trade evidence, trust, verification and commercial alignment — with explainable factor breakdowns.</div>
        <div className="split" style={{ gridTemplateColumns: '2fr 1fr', alignItems: 'end' }}>
          <div>
            <label className="field">Demand (natural language or structured)</label>
            <input className="input" value={demandText} onChange={(e) => setDemandText(e.target.value)} />
          </div>
          <button className="btn" onClick={run} disabled={busy} style={{ height: 42 }}>{busy ? 'Scoring…' : 'Run matching'}</button>
        </div>
        {demand && (
          <div style={{ marginTop: 12, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <span className="tag"><b>Product:</b> {demand.product}</span>
            <span className="tag"><b>Qty:</b> {demand.quantity}</span>
            <span className="tag"><b>Dest:</b> {demand.destination || '—'}</span>
            <span className="tag"><b>Incoterm:</b> {demand.incoterm || '—'}</span>
            <span className="tag"><b>Payment:</b> {demand.payment || '—'}</span>
          </div>
        )}
      </div>

      <div className="card">
        <div className="card-title">🏆 Ranked suppliers</div>
        <div className="card-sub">Explainable score = fit · trust · risk · commercial</div>
        {matches.length === 0 ? <Empty icon="🎯" text="Run matching to see ranked suppliers." /> : (
          <table className="table">
            <thead><tr><th>Supplier</th><th>Country</th><th>Score</th><th>Fit</th><th>Risk</th><th>Evidence</th></tr></thead>
            <tbody>
              {matches.map((m: any) => (
                <tr key={m.id}>
                  <td>
                    <div style={{ fontWeight: 600 }}>{m.name}</div>
                    <div style={{ fontSize: 11.5, color: 'var(--text-faint)' }}>{m.products?.join(' · ') || ''}</div>
                  </td>
                  <td>{m.country}</td>
                  <td style={{ width: 170 }}><ScoreBar value={m.score} /></td>
                  <td>{m.fit !== undefined ? pct(m.fit) : '—'}</td>
                  <td><Badge kind={String(m.risk).toLowerCase() === 'low' ? 'ok' : String(m.risk).toLowerCase() === 'high' ? 'bad' : 'warn'}>{m.risk}</Badge></td>
                  <td style={{ fontSize: 12 }}>{m.verified || m.evidence || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Risk engine
// ---------------------------------------------------------------------------

function RiskEngine({ user }: { user: TVUser }) {
  const [data, setData] = useState<any>(null);
  React.useEffect(() => {
    (async () => {
      try { const r = await api.get('/api/risk'); setData(r.data); } catch { /* fallback */ }
    })();
  }, []);
  const [sample, setSample] = useState({ product: 'Sulphur', value: 250000, destination: 'Indonesia', incoterm: 'CIF', payment: 'LC at sight' });

  if (!data) return <Spinner label="Loading risk engine…" />;

  const g = evaluateRisk(sample, {});
  const blocked = data.blockedCount ?? data.stats?.blocked ?? 0;
  const review = data.reviewCount ?? data.stats?.review ?? 0;
  const allowed = data.allowedCount ?? data.stats?.allowed ?? 0;

  return (
    <div className="fade-in">
      <div className="grid grid-4" style={{ marginBottom: 18 }}>
        <Stat label="Allowed transactions" value={allowed} foot="Risk-engine cleared" />
        <Stat label="Under review" value={review} foot="Human decision required" />
        <Stat label="Blocked" value={blocked} foot="Auto-held by engine" />
        <Stat label="Sanctions sources" value={data.sources?.length ?? 5} foot="Free public-source screening" />
      </div>

      <div className="split">
        <div className="card">
          <div className="card-title">🧪 Live transaction test</div>
          <div className="card-sub">Evaluate any deal against the same gates used in production</div>
          <div className="grid grid-2">
            <div className="field-wrap"><label className="field">Product</label><input className="input" value={sample.product} onChange={(e) => setSample({ ...sample, product: e.target.value })} /></div>
            <div className="field-wrap"><label className="field">Value (USD)</label><input className="input" type="number" value={sample.value} onChange={(e) => setSample({ ...sample, value: Number(e.target.value) })} /></div>
            <div className="field-wrap"><label className="field">Destination</label><input className="input" value={sample.destination} onChange={(e) => setSample({ ...sample, destination: e.target.value })} /></div>
            <div className="field-wrap"><label className="field">Incoterm</label>
              <select className="input" value={sample.incoterm} onChange={(e) => setSample({ ...sample, incoterm: e.target.value })}>
                <option>CIF</option><option>FOB</option><option>CFR</option><option>EXW</option><option>DDP</option>
              </select>
            </div>
          </div>
          <div style={{ marginTop: 6 }}>
            <Badge kind={g.decision === 'ALLOW' ? 'ok' : g.decision === 'REVIEW' ? 'warn' : 'bad'}>Decision: {g.decision}</Badge>
          </div>
          <ul style={{ marginTop: 12, fontSize: 12.5, color: 'var(--text-dim)', paddingLeft: 18 }}>
            {g.reasons?.map((r: string, i: number) => <li key={i}>{r}</li>)}
          </ul>
        </div>

        <div className="card">
          <div className="card-title">🛡️ Sanctions screening</div>
          <div className="card-sub">Entity-level screening against OFAC, UNSC, UK, EU and more public sources</div>
          {[['OQ Trading', 'Singapore'], ['PT Indo Fertilizer', 'Indonesia'], ['Coconut Carbon Industries', 'Indonesia']].map(([n, c]) => {
            const s = screenEntity(n, c);
            return (
              <div key={n} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border-soft)' }}>
                <div>
                  <div style={{ fontWeight: 600 }}>{n}</div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-faint)' }}>{c}</div>
                </div>
                <Badge kind={s.matches.length === 0 ? 'ok' : s.matches.length > 0 ? 'bad' : 'warn'}>{s.matches.length === 0 ? 'CLEAR' : s.status}</Badge>
              </div>
            );
          })}
          <p style={{ marginTop: 14, fontSize: 12, color: 'var(--text-faint)' }}>
            Free public-source pre-screen is active. Connect a licensed KYB provider for full entity graphs.
          </p>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Market intelligence
// ---------------------------------------------------------------------------

function MarketIntel({ fx, setFx }: { fx: Record<string, number> | null; setFx: (r: Record<string, number>) => void }) {
  const [comtrade, setComtrade] = useState<any>(null);
  const [commodity, setCommodity] = useState('Sulphur');
  const [busy, setBusy] = useState(false);
  const toast = useToast();

  const loadFx = async () => {
    try { const r = await api.get('/api/fx'); if (r.data?.rates) setFx(r.data.rates); } catch { /* fallback */ }
  };
  React.useEffect(() => { if (!fx) loadFx(); }, []);

  const loadComtrade = async () => {
    setBusy(true);
    try {
      const r = await api.get('/api/comtrade/' + encodeURIComponent(commodity));
      setComtrade(r.data);
    } catch (e: any) { toast.push(e.message || 'Trade flow unavailable', 'err'); setComtrade({ error: 'unavailable' }); }
    setBusy(false);
  };

  const pairs = fx ? Object.entries(fx).slice(0, 12) : [];
  const coms = ['Sulphur', 'Activated Carbon', 'Coconut Oil', 'Rice', 'Coffee', 'Nickel', 'Palm Oil', 'Copper', 'Rubber', 'Fertilizer'];

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 18 }}>
        <div className="card-title">💱 Live FX — ECB reference rates <span className="live-pill" style={{ fontSize: 10.5 }}><span className="live-dot" /> LIVE</span></div>
        <div className="card-sub">USD base, sourced from the European Central Bank via Frankfurter. Real data, refreshed daily.</div>
        <div className="grid grid-4">
          {pairs.map(([k, v]) => (
            <Stat key={k} label={'USD/' + k} value={<span className="mono">{Number(v).toLocaleString('en-US', { maximumFractionDigits: k === 'IDR' || k === 'VND' || k === 'KRW' || k === 'NGN' || k === 'BDT' || k === 'KES' ? 0 : 4 })}</span>} small />
          ))}
        </div>
      </div>

      <div className="split">
        <div className="card">
          <div className="card-title">📦 Commodity baselines</div>
          <div className="card-sub">Reference price per MT (USD) used by the AI engine for quote normalization</div>
          <div className="tag-list" style={{ marginBottom: 14 }}>
            {coms.map((c) => (
              <span key={c} className="tag" style={{ cursor: 'pointer', padding: '4px 12px', background: commodity === c ? 'rgba(37,99,235,.2)' : undefined }} onClick={() => setCommodity(c)}>{c}</span>
            ))}
          </div>
          <div className="grid grid-4">
            {Object.entries(COMMODITY_PRICE_BASELINE as Record<string, number>).slice(0, 16).map(([k, v]) => (
              <Stat key={k} label={k} value={<span className="mono">${v}</span>} small foot="/MT baseline" />
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-title">🌐 UN Comtrade flow — Indonesia</div>
          <div className="card-sub">Live import/export statistics from the UN Comtrade public API (reporter: Indonesia, code 360)</div>
          <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
            <input className="input" value={commodity} onChange={(e) => setCommodity(e.target.value)} />
            <button className="btn" onClick={loadComtrade} disabled={busy}>{busy ? 'Fetching…' : 'Fetch'}</button>
          </div>
          {comtrade ? (
            comtrade.error ? <Empty icon="🌐" text={typeof comtrade.error === 'string' ? comtrade.error : 'Flow unavailable'} /> : (
              <div>
                <div className="grid grid-3">
                  <Stat label="Trade value" value={fmtUSD(comtrade.tradeValue)} small foot={comtrade.year ? String(comtrade.year) : '—'} />
                  <Stat label="Net weight" value={<span style={{ fontSize: 15 }}>{(Number(comtrade.netWeight || 0) / 1000).toLocaleString('en-US', { maximumFractionDigits: 0 })} t</span>} small />
                  <Stat label="Commodity" value={<span style={{ fontSize: 15 }}>{comtrade.commodity || commodity}</span>} small />
                </div>
                {comtrade.source && <p style={{ marginTop: 10, fontSize: 11.5, color: 'var(--text-faint)' }}>Source: {comtrade.source}</p>}
              </div>
            )
          ) : (
            <Empty icon="🌐" text="Fetch live trade flow for this commodity." />
          )}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Network (entities + introductions)
// ---------------------------------------------------------------------------

function Network({ user }: { user: TVUser }) {
  const toast = useToast();
  const [entities, setEntities] = useState<any[]>([]);
  const [intro, setIntro] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  React.useEffect(() => {
    (async () => {
      try { const r = await api.get('/api/entities'); setEntities(r.data.entities || []); } catch { /* fallback */ }
    })();
  }, []);

  const requestIntro = async (e: any) => {
    setBusy(true);
    try {
      const targetType = user.role === 'buyer' ? 'seller' : 'buyer';
      const r = await api.post('/api/introductions', { targetType, targetEntityId: e.id, product: e.products?.[0] || '' });
      setIntro(r.data);
      toast.push('Controlled introduction requested — ' + (r.data.referralId || ''), 'ok');
    } catch (err: any) { toast.push(err.message || 'Request failed', 'err'); }
    setBusy(false);
  };

  const visible = user.role === 'buyer' ? entities.filter((e) => e.entityType === 'Seller') : user.role === 'seller' ? entities.filter((e) => e.entityType === 'Buyer') : entities;

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 18 }}>
        <div className="card-title">🕸️ Trade network registry</div>
        <div className="card-sub">Evidence-backed profiles. Contact details are protected — every connection goes through a controlled introduction with a 24-month protection window.</div>
        <div className="grid grid-4" style={{ marginBottom: 4 }}>
          <Stat label="Entities" value={entities.length} small />
          <Stat label="Suppliers" value={entities.filter((e) => e.entityType === 'Seller').length} small />
          <Stat label="Buyers" value={entities.filter((e) => e.entityType === 'Buyer').length} small />
          <Stat label="Avg confidence" value={entities.length ? pct(entities.reduce((a: number, e: any) => a + Number(e.confidence || 0), 0) / entities.length) : '—'} small />
        </div>
      </div>

      {intro && (
        <div className="card fade-in" style={{ marginBottom: 18, borderColor: 'rgba(16,185,129,.4)' }}>
          <div className="card-title">✅ Introduction requested</div>
          <div className="card-sub">Referral ID <span className="mono">{intro.referralId}</span> · Contact disclosure: {intro.contactDisclosure} · Protection window: {intro.protectionWindowMonths} months</div>
        </div>
      )}

      <div className="card">
        <div className="card-title">{user.role === 'buyer' ? '🏭 Suppliers' : user.role === 'seller' ? '🏢 Buyers' : '🌐 All entities'}</div>
        <div className="card-sub">Click a row to request a controlled introduction</div>
        {visible.length === 0 ? <Empty icon="🕸️" text="No entities in your visibility window." /> : (
          <table className="table">
            <thead><tr><th>Entity</th><th>Type</th><th>Country</th><th>Products</th><th>Confidence</th><th>Verification</th><th></th></tr></thead>
            <tbody>
              {visible.slice(0, 15).map((e: any) => (
                <tr key={e.id}>
                  <td style={{ fontWeight: 600 }}>{e.name}</td>
                  <td><Badge kind="acc">{e.entityType}</Badge></td>
                  <td>{e.country}</td>
                  <td><div className="tag-list">{(e.products || []).slice(0, 2).map((p: string) => <span key={p} className="tag">{p}</span>)}</div></td>
                  <td style={{ width: 120 }}><ScoreBar value={e.confidence ?? 0} /></td>
                  <td style={{ fontSize: 11.5 }}>{e.verificationLevel || '—'}</td>
                  <td><button className="btn btn-sm btn-ghost" disabled={busy} onClick={() => requestIntro(e)}>Introduce</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Execution
// ---------------------------------------------------------------------------

function Execution({ user }: { user: TVUser }) {
  const [data, setData] = useState<any>(null);
  const [advancing, setAdvancing] = useState<string | null>(null);
  const toast = useToast();

  const load = async () => {
    try { const r = await api.get('/api/execution'); setData(r.data); } catch { /* fallback */ }
  };
  React.useEffect(() => { load(); }, []);

  const advance = async (id: string) => {
    setAdvancing(id);
    try {
      const r = await api.post('/api/trades/' + id + '/advance', {});
      toast.push('Trade advanced → ' + r.data.status, 'ok');
      await load();
    } catch (e: any) { toast.push(e.message || 'Advance failed (operator only)', 'err'); }
    setAdvancing(null);
  };

  if (!data) return <Spinner label="Loading execution…" />;
  const trades = data.trades || [];
  const quotes = data.quotes || [];

  return (
    <div className="fade-in">
      <div className="grid grid-4" style={{ marginBottom: 18 }}>
        <Stat label="Active trades" value={trades.filter((t: any) => t.status !== 'Settled').length} />
        <Stat label="Quotes" value={quotes.length} />
        <Stat label="Pipeline value" value={fmtUSD(trades.reduce((a: number, t: any) => a + Number(t.value || 0), 0))} foot="Active only" />
        <Stat label="Settled" value={trades.filter((t: any) => t.status === 'Settled').length} />
      </div>

      <div className="card" style={{ marginBottom: 18 }}>
        <div className="card-title">🚢 Trade pipeline</div>
        <div className="card-sub">Advance trades through Negotiation → Contracted → In Transit → Delivered → Settled (operator role)</div>
        {trades.length === 0 ? <Empty icon="🚢" text="No trades yet — they appear once an RFQ is matched and quoted." /> : (
          <table className="table">
            <thead><tr><th>Product</th><th>Buyer</th><th>Supplier</th><th>Value</th><th>Status</th><th>Payment</th><th></th></tr></thead>
            <tbody>
              {trades.slice(0, 10).map((t: any) => (
                <tr key={t.id}>
                  <td style={{ fontWeight: 600 }}>{t.product}</td>
                  <td style={{ fontSize: 12.5 }}>{t.buyer}</td>
                  <td style={{ fontSize: 12.5 }}>{t.supplier}</td>
                  <td className="mono">{fmtUSD(t.value)}</td>
                  <td><Badge kind={t.status === 'Settled' || t.status === 'Delivered' ? 'ok' : t.status === 'In Transit' ? 'acc' : t.status === 'Contracted' ? 'warn' : 'bad'}>{t.status}</Badge></td>
                  <td style={{ fontSize: 12 }}>{t.payment || '—'}</td>
                  <td><button className="btn btn-sm" disabled={advancing === t.id || user.role !== 'operator'} onClick={() => advance(t.id)}>{advancing === t.id ? '…' : 'Advance'}</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Trade room
// ---------------------------------------------------------------------------

function TradeRoom({ user }: { user: TVUser }) {
  const [data, setData] = useState<any>(null);
  const [strategy, setStrategy] = useState<any>(null);
  const [approval, setApproval] = useState('');
  const [reason, setReason] = useState('');
  const toast = useToast();

  React.useEffect(() => {
    (async () => {
      try {
        const ex = await api.get('/api/execution');
        const trades = ex.data.trades || [];
        if (trades.length) {
          const r = await api.get('/api/trade-room/' + trades[0].id);
          setData(r.data);
        } else setData({ none: true });
      } catch { setData({ none: true }); }
    })();
  }, []);

  const loadStrategy = async () => {
    if (!data?.trade) return;
    try { const r = await api.post('/api/trade-room/' + data.trade.id + '/strategy', {}); setStrategy(r.data); }
    catch (e: any) { toast.push(e.message || 'Strategy unavailable', 'err'); }
  };

  const submitApproval = async () => {
    if (!data?.trade || !approval) return;
    try {
      await api.post('/api/trade-room/' + data.trade.id + '/approval', { decision: approval, reason });
      toast.push('Approval recorded in Trade Room', 'ok');
      setApproval(''); setReason('');
      const r = await api.get('/api/trade-room/' + data.trade.id);
      setData(r.data);
    } catch (e: any) { toast.push(e.message || 'Failed', 'err'); }
  };

  if (!data) return <Spinner label="Opening trade room…" />;
  if (data.none) return <div className="card"><Empty icon="🏛️" text="No active trade to open. Create an RFQ, match suppliers, and quotes will flow here." /></div>;

  const { trade, quotes, events, approvals, risk } = data;

  return (
    <div className="fade-in">
      <div className="hero" style={{ padding: '24px 26px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h1 style={{ fontSize: 22 }}>{trade.product} <span style={{ fontSize: 13, color: 'var(--text-dim)', fontWeight: 500 }}>· {trade.buyer} ↔ {trade.supplier}</span></h1>
            <p style={{ marginTop: 6 }}>Value {fmtUSD(trade.value)} · {trade.incoterm || 'CIF'} · {trade.payment || '—'} · Status <Badge kind="acc">{trade.status}</Badge></p>
          </div>
          <button className="btn btn-ghost" onClick={loadStrategy}>🎯 AI strategy</button>
        </div>
        {strategy && (
          <div style={{ marginTop: 14, background: 'rgba(6,182,212,.07)', border: '1px solid rgba(6,182,212,.25)', borderRadius: 10, padding: 14 }}>
            <b style={{ color: '#a5f3fc' }}>Negotiation strategy</b>
            <p style={{ fontSize: 13, marginTop: 6 }}>{strategy.guidance || strategy.strategy || strategy.recommendation || 'Strategy generated.'}</p>
            {strategy.anchor && <p className="mono" style={{ fontSize: 12, marginTop: 6, color: 'var(--text-dim)' }}>Anchor: {strategy.anchor}</p>}
          </div>
        )}
      </div>

      <div className="grid grid-2" style={{ marginBottom: 16 }}>
        <div className="card">
          <div className="card-title">🛡️ Deal risk</div>
          <div className="card-sub">Live evaluation by the risk engine</div>
          <Badge kind={risk?.decision === 'ALLOW' ? 'ok' : risk?.decision === 'REVIEW' ? 'warn' : 'bad'}>{risk?.decision || 'ALLOW'}</Badge>
          <ul style={{ marginTop: 10, fontSize: 12.5, color: 'var(--text-dim)', paddingLeft: 18 }}>
            {(risk?.reasons || []).slice(0, 5).map((r: string, i: number) => <li key={i}>{r}</li>)}
          </ul>
        </div>
        <div className="card">
          <div className="card-title">✅ Approvals</div>
          <div className="card-sub">Governed decision support — human in the loop</div>
          <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
            <select className="input" style={{ flex: 1 }} value={approval} onChange={(e) => setApproval(e.target.value)}>
              <option value="">Select decision…</option>
              <option>APPROVE</option>
              <option>REJECT</option>
              <option>HOLD</option>
            </select>
            <button className="btn btn-sm" onClick={submitApproval}>Record</button>
          </div>
          <input className="input" placeholder="Reason (optional)" value={reason} onChange={(e) => setReason(e.target.value)} />
          {(approvals || []).length > 0 && (
            <div style={{ marginTop: 12 }}>
              {(approvals as any[]).slice(0, 5).map((a: any, i: number) => (
                <div key={i} style={{ fontSize: 12, padding: '6px 0', borderBottom: '1px solid var(--border-soft)', color: 'var(--text-dim)' }}>
                  <b style={{ color: 'var(--text)' }}>{a.decision}</b> · {a.actorRole} · {timeAgo(a.createdAt)} {a.reason ? '· ' + a.reason : ''}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="split">
        <div className="card">
          <div className="card-title">📋 Quotes</div>
          <div className="card-sub">Commercial submissions on this trade</div>
          {(quotes || []).length === 0 ? <Empty icon="📋" text="No quotes yet." /> : (
            <table className="table">
              <thead><tr><th>Supplier</th><th>Price</th><th>Landed</th><th>Status</th></tr></thead>
              <tbody>
                {(quotes as any[]).slice(0, 8).map((q: any) => (
                  <tr key={q.id}>
                    <td style={{ fontSize: 12.5 }}>{q.supplier}</td>
                    <td className="mono">{fmtUSD(q.price, 2)}</td>
                    <td className="mono">{fmtUSD(q.landedCost, 2)}</td>
                    <td><Badge kind="acc">{q.status}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <div className="card">
          <div className="card-title">📜 Event log</div>
          <div className="card-sub">Immutable governance trail for this deal</div>
          {(events || []).length === 0 ? <Empty icon="📜" text="No events yet." /> : (
            (events as any[]).slice(0, 8).map((e: any, i: number) => (
              <div key={i} style={{ fontSize: 12.5, padding: '8px 0', borderBottom: '1px solid var(--border-soft)' }}>
                <Badge kind="acc">{e.kind}</Badge> <span style={{ marginLeft: 6 }}>{e.summary}</span>
                <div style={{ color: 'var(--text-faint)', fontSize: 11, marginTop: 2 }}>{timeAgo(e.createdAt)} · {e.actorRole}</div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// AI Agents
// ---------------------------------------------------------------------------

function Agents() {
  const [data, setData] = useState<any>(null);
  const [objective, setObjective] = useState('Review the highest-priority trade opportunity and recommend next steps.');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<any>(null);
  const toast = useToast();

  React.useEffect(() => {
    (async () => { try { const r = await api.get('/api/agents'); setData(r.data); } catch { /* fallback */ } })();
  }, []);

  const run = async (agentId: string) => {
    setBusy(true); setResult(null);
    try {
      const r = await api.post('/api/agents/run', { agentId, objective });
      setResult(r.data);
      toast.push('Agent ' + agentId + ' completed', 'ok');
    } catch (e: any) { toast.push(e.message || 'Agent run failed (operator only)', 'err'); }
    setBusy(false);
  };

  if (!data) return <Spinner label="Loading agents…" />;

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 18 }}>
        <div className="card-title">🤖 AI agent swarm</div>
        <div className="card-sub">Six specialized agents with declared authority — from recommendation to approval gates</div>
        <div className="grid grid-3">
          {(data.agents || []).map((a: any) => (
            <div className="card" key={a.id} style={{ padding: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <b style={{ fontSize: 13.5 }}>{a.name}</b>
                <Badge kind={a.status === 'Running' ? 'ok' : a.status === 'Approval Gate' ? 'warn' : 'acc'}>{a.status}</Badge>
              </div>
              <p style={{ fontSize: 12, color: 'var(--text-dim)', margin: '8px 0' }}>{a.mission}</p>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 11, color: 'var(--text-faint)' }}>Authority: <b style={{ color: 'var(--accent-2)' }}>{a.authority}</b> · Confidence {pct(a.confidence)}</span>
                <button className="btn btn-sm btn-ghost" disabled={busy} onClick={() => run(a.id)}>Run</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {result && (
        <div className="card fade-in" style={{ marginBottom: 18, borderColor: 'rgba(6,182,212,.4)' }}>
          <div className="card-title">📋 Agent report</div>
          <div className="card-sub">Completed {timeAgo(result.completedAt)} · authority {result.authority}</div>
          {result.summary && <p style={{ fontSize: 13.5, marginBottom: 10 }}>{result.summary}</p>}
          {Array.isArray(result.findings) && (
            <ul style={{ fontSize: 12.5, color: 'var(--text-dim)', paddingLeft: 18 }}>
              {(result.findings as any[]).slice(0, 6).map((f: any, i: number) => <li key={i}>{f.title || f.description || f}</li>)}
            </ul>
          )}
          {result.recommendation && <div style={{ marginTop: 10 }}><Badge kind="acc">Recommendation</Badge> <span style={{ fontSize: 13 }}>{result.recommendation}</span></div>}
        </div>
      )}

      <div className="card">
        <div className="card-title">🎯 Agent objective</div>
        <div className="card-sub">Dispatch any agent with a custom objective (operator role)</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <input className="input" value={objective} onChange={(e) => setObjective(e.target.value)} />
          <button className="btn" disabled={busy || data.agents?.length === 0} onClick={() => run(data.agents?.[0]?.id || 'opportunity')}>{busy ? 'Running…' : 'Dispatch'}</button>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Copilot
// ---------------------------------------------------------------------------

function Copilot({ user }: { user: TVUser }) {
  const [q, setQ] = useState('Which suppliers are best for sulphur into Indonesia right now?');
  const [chat, setChat] = useState<{ q: string; a: any }[]>([]);
  const [busy, setBusy] = useState(false);
  const toast = useToast();

  const ask = async () => {
    if (!q.trim()) return;
    setBusy(true);
    try {
      const r = await api.post('/api/copilot', { question: q });
      setChat((xs) => [...xs, { q, a: r.data }]);
      setQ('');
    } catch (e: any) { toast.push(e.message || 'Copilot unavailable', 'err'); }
    setBusy(false);
  };

  return (
    <div className="fade-in">
      <div className="card" style={{ marginBottom: 18 }}>
        <div className="card-title">💬 Trade copilot</div>
        <div className="card-sub">Answers grounded in your live dataset — entities, demands, opportunities and FX. Every answer cites evidence.</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask about suppliers, risks, pricing, opportunities…" onKeyDown={(e) => e.key === 'Enter' && ask()} />
          <button className="btn" onClick={ask} disabled={busy}>{busy ? 'Thinking…' : 'Ask'}</button>
        </div>
        <div style={{ marginTop: 10, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {['Best suppliers for sulphur?', 'What risks are on my deals?', 'How does the market look for activated carbon?'].map((s) => (
            <span key={s} className="tag" style={{ cursor: 'pointer' }} onClick={() => setQ(s)}>{s}</span>
          ))}
        </div>
      </div>

      {chat.length === 0 ? <Empty icon="💬" text="Ask the copilot anything about your trade network." /> : (
        chat.map((c, i) => (
          <div key={i} className="card fade-in" style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 10 }}>🧑‍💻 {c.q}</div>
            <div style={{ fontSize: 13.5, lineHeight: 1.6 }}>{c.a.answer}</div>
            {(c.a.evidence || []).length > 0 && (
              <div style={{ marginTop: 10 }}>
                <Badge kind="acc">Evidence</Badge>
                <ul style={{ fontSize: 12, color: 'var(--text-dim)', paddingLeft: 18, marginTop: 6 }}>
                  {(c.a.evidence as string[]).slice(0, 4).map((ev: string, j: number) => <li key={j}>{ev}</li>)}
                </ul>
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Trade memory
// ---------------------------------------------------------------------------

function Memory() {
  const [data, setData] = useState<any>(null);
  React.useEffect(() => {
    (async () => { try { const r = await api.get('/api/trade-memory'); setData(r.data); } catch { /* fallback */ } })();
  }, []);

  if (!data) return <Spinner label="Loading trade memory…" />;

  return (
    <div className="fade-in">
      <div className="grid grid-4" style={{ marginBottom: 18 }}>
        <Stat label="Trade records" value={data.memoryHealth?.tradeRecords ?? data.graph?.nodes?.length ?? 0} />
        <Stat label="Memory coverage" value={pct(data.memoryHealth?.coveragePercent)} foot="From persisted records" />
        <Stat label="Settled" value={data.outcomes?.settled ?? 0} />
        <Stat label="Win rate" value={pct(data.outcomes?.winRate)} />
      </div>

      <div className="split">
        <div className="card">
          <div className="card-title">🧠 Learned patterns</div>
          <div className="card-sub">Built exclusively from human-approved, persisted records — no automatic model training</div>
          {(data.patterns || []).length === 0 ? <Empty icon="🧠" text={data.recommendation || 'No patterns yet.'} /> : (
            (data.patterns as any[]).map((p: any, i: number) => (
              <div key={i} style={{ padding: '10px 0', borderBottom: '1px solid var(--border-soft)' }}>
                <Badge kind="acc">{p.type}</Badge>
                <div style={{ fontSize: 13, marginTop: 6 }}>{p.description}</div>
                <div style={{ fontSize: 11.5, color: 'var(--text-faint)' }}>Strength {pct(p.strength)}</div>
              </div>
            ))
          )}
        </div>
        <div className="card">
          <div className="card-title">📦 Product patterns</div>
          <div className="card-sub">Most-traded commodities in your network</div>
          {(data.productPatterns || []).length === 0 ? <Empty icon="📦" text="No product data yet." /> : (
            (data.productPatterns as any[]).map((p: any, i: number) => (
              <div key={i} style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 4 }}>
                  <span>{p.product}</span><span className="mono">{p.trades} trades · {pct(p.share)}</span>
                </div>
                <ScoreBar value={p.share} max={Math.max(50, p.share * 2)} />
              </div>
            ))
          )}
          <p style={{ marginTop: 12, fontSize: 11.5, color: 'var(--text-faint)' }}>{data.privacy}</p>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Operator console
// ---------------------------------------------------------------------------

function OperatorConsole({ user }: { user: TVUser }) {
  const [data, setData] = useState<any>(null);
  const toast = useToast();

  React.useEffect(() => {
    (async () => {
      try { const r = await api.get('/api/admin/intelligence'); setData(r.data); }
      catch (e: any) { toast.push(e.message || 'Operator data requires operator role', 'err'); setData({ denied: true }); }
    })();
  }, []);

  if (!data) return <Spinner label="Loading operator console…" />;
  if (data.denied || user.role !== 'operator') return <div className="card"><Empty icon="🔒" text="Operator console is restricted to authorized operator accounts." /></div>;

  return (
    <div className="fade-in">
      <div className="grid grid-4" style={{ marginBottom: 18 }}>
        <Stat label="Accounts" value={data.users?.total ?? 0} foot={`${data.users?.buyers ?? 0} buyers · ${data.users?.sellers ?? 0} sellers`} />
        <Stat label="Verification rate" value={pct(data.users?.verificationRate)} foot={`${data.users?.verified ?? 0} verified`} />
        <Stat label="Page views" value={data.traffic?.pageViews ?? 0} foot={`${data.traffic?.uniqueVisitors ?? 0} unique visitors`} />
        <Stat label="Pipeline value" value={data.revenue?.tradeValue ?? '$0'} foot={`${data.revenue?.activeTrades ?? 0} active trades`} />
      </div>

      <div className="split" style={{ marginBottom: 16 }}>
        <div className="card">
          <div className="card-title">📈 Funnel & traffic</div>
          <div className="card-sub">Conversion across visitors → logins → verification → RFQ</div>
          <div className="grid grid-3">
            <Stat label="Conversion rate" value={pct(data.traffic?.conversionRate)} small />
            <Stat label="Logins" value={data.traffic?.logins ?? 0} small />
            <Stat label="CTA clicks" value={data.traffic?.ctaClicks ?? 0} small />
          </div>
          {(data.traffic?.topPages || []).map((p: any, i: number) => (
            <div key={i} style={{ marginTop: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 3 }}>
                <span className="mono">{p.page}</span><span>{p.views} views</span>
              </div>
              <ScoreBar value={p.views} max={Math.max(1, ...(data.traffic?.topPages || []).map((x: any) => x.views))} />
            </div>
          ))}
        </div>

        <div className="card">
          <div className="card-title">🗄️ Data fabric</div>
          <div className="card-sub">Captured operational inventory</div>
          <table className="table">
            <thead><tr><th>Table</th><th>Records</th><th>Use</th></tr></thead>
            <tbody>
              {(data.captured?.inventory || []).map((inv: any, i: number) => (
                <tr key={i}><td className="mono">{inv.table}</td><td>{inv.records}</td><td style={{ fontSize: 12 }}>{inv.use}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <div className="card-title">✅ Verification queue</div>
          <div className="card-sub">Evidence submissions awaiting review</div>
          {(data.verification?.queue || []).length === 0 ? <Empty icon="✅" text="No pending verifications." /> : (
            (data.verification.queue as any[]).map((v: any, i: number) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border-soft)' }}>
                <div><b style={{ fontSize: 13 }}>{v.company}</b><div style={{ fontSize: 11.5, color: 'var(--text-faint)' }}>{v.role} · submitted {timeAgo(v.submitted)}</div></div>
                <Badge kind="warn">{v.status}</Badge>
              </div>
            ))
          )}
        </div>
        <div className="card">
          <div className="card-title">📊 Recent trades</div>
          <div className="card-sub">Active pipeline snapshot</div>
          {(data.recent?.trades || []).length === 0 ? <Empty icon="📊" text="No recent trades." /> : (
            (data.recent.trades as any[]).map((t: any, i: number) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '9px 0', borderBottom: '1px solid var(--border-soft)' }}>
                <span style={{ fontSize: 13 }}>{t.product}</span>
                <span><Badge kind="acc">{t.status}</Badge> <span className="mono" style={{ marginLeft: 8, fontSize: 12 }}>{t.value}</span></span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Pricing
// ---------------------------------------------------------------------------

function Pricing({ user }: { user: TVUser }) {
  const [data, setData] = useState<any>(null);
  React.useEffect(() => {
    (async () => { try { const r = await api.get('/api/access'); setData(r.data); } catch { /* fallback */ } })();
  }, []);

  if (!data) return <Spinner label="Loading pricing…" />;

  const PLANS: Record<string, { price: string; feats: string[] }> = {
    buyer_free: { price: '$0', feats: ['AI demand intake', 'Basic matching', '2 introductions / month', 'Risk engine gating'] },
    buyer_pro: { price: '$79/mo', feats: ['Everything in Free', 'Unlimited matching', 'Priority introductions', 'Predictive alerts', 'Trade room'] },
    seller_free: { price: '$0', feats: ['Profile listing', 'Demand radar', 'Quote submission'] },
    seller_verified: { price: '$99/mo', feats: ['Verified badge', 'Demand radar + alerts', 'Unlimited quotes', 'KYB screening'] },
    seller_pro: { price: '$299/mo', feats: ['Everything in Verified', 'Priority placement', 'Dedicated trade room', 'Growth advisor'] },
    operator: { price: 'Platform', feats: ['Full data fabric', 'Agent dispatch', 'Verification control', 'Sanctions graph'] },
  };
  const plan = data.plan || 'buyer_free';
  const meta = PLANS[plan] || PLANS.buyer_free;

  return (
    <div className="fade-in">
      <div className="hero">
        <h1>Your plan: <span>{data.role} · {plan.replace('_', ' ')}</span></h1>
        <p>Current tier <b>{meta.price}</b>. Introductions available: {data.introductions?.length ?? 0} · Contact details protected for {data.protection?.tailPeriodMonths ?? 24} months after a trade.</p>
        <div className="hero-actions">
          <button className="btn">Upgrade plan</button>
          <button className="btn btn-ghost">Compare tiers</button>
        </div>
      </div>

      <div className="grid grid-3">
        {Object.entries(PLANS).filter(([k]) => k.startsWith(data.role === 'seller' ? 'seller' : data.role === 'buyer' ? 'buyer' : 'op')).map(([k, p]) => (
          <div className="card" key={k} style={{ borderColor: k === plan ? 'var(--accent)' : undefined }}>
            <div className="card-title">{k.split('_').map((w) => w[0].toUpperCase() + w.slice(1)).join(' ')} {k === plan && <Badge kind="ok">Current</Badge>}</div>
            <div style={{ fontSize: 26, fontWeight: 800, margin: '8px 0 12px' }}>{p.price}</div>
            <ul style={{ fontSize: 12.5, color: 'var(--text-dim)', paddingLeft: 18, listStyle: 'none' }}>
              {p.feats.map((f, i) => <li key={i} style={{ padding: '4px 0' }}>✓ {f}</li>)}
            </ul>
            <button className="btn" style={{ marginTop: 14, width: '100%' }} disabled={k === plan}>{k === plan ? 'Current plan' : 'Choose'}</button>
          </div>
        ))}
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <div className="card-title">🔐 Protection & governance</div>
        <div className="card-sub">Platform-level safeguards on every introduction</div>
        <div className="grid grid-3">
          <Stat label="Contact details" value={data.protection?.contactDetails || 'Protected'} small />
          <Stat label="Protection window" value={(data.protection?.tailPeriodMonths ?? 24) + ' months'} small />
          <Stat label="Audit trail" value={data.protection?.auditTrail || 'Enabled'} small />
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Profile
// ---------------------------------------------------------------------------

function Profile({ user }: { user: TVUser }) {
  const toast = useToast();
  const [p, setP] = useState<any>(user);
  const [evidence, setEvidence] = useState('');
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    try {
      const r = await api.post('/api/profile/update', p);
      setP(r.data);
      toast.push('Profile updated', 'ok');
    } catch (e: any) { toast.push(e.message || 'Save failed', 'err'); }
    setBusy(false);
  };

  const submitVerification = async () => {
    if (!evidence.trim()) { toast.push('Add evidence links or notes first', 'err'); return; }
    setBusy(true);
    try {
      const r = await api.post('/api/profile/submit-verification', { notes: evidence, evidence: [evidence] });
      setP(r.data);
      toast.push('Verification submitted — awaiting operator review', 'ok');
    } catch (e: any) { toast.push(e.message || 'Submit failed', 'err'); }
    setBusy(false);
  };

  const FIELDS: { k: string; label: string }[] = [
    { k: 'company', label: 'Company' }, { k: 'legalName', label: 'Legal name' },
    { k: 'country', label: 'Country' }, { k: 'website', label: 'Website' },
    { k: 'industry', label: 'Industry' }, { k: 'address', label: 'Address' },
    { k: 'city', label: 'City' }, { k: 'taxId', label: 'Tax ID' },
    { k: 'registrationNumber', label: 'Registration no.' }, { k: 'contactName', label: 'Contact name' },
    { k: 'contactTitle', label: 'Contact title' }, { k: 'phone', label: 'Phone' },
  ];

  return (
    <div className="fade-in">
      <div className="hero" style={{ padding: '26px 28px' }}>
        <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
          <div className="user-avatar" style={{ width: 54, height: 54, fontSize: 22 }}>{(p.name || 'U').slice(0, 1).toUpperCase()}</div>
          <div>
            <h1 style={{ fontSize: 22 }}>{p.name}</h1>
            <p style={{ marginTop: 4 }}>{p.email} · <Badge kind="acc">{p.role}</Badge> {p.verificationStatus === 'verified' ? <Badge kind="ok">Verified</Badge> : p.verificationStatus === 'review' ? <Badge kind="warn">Under review</Badge> : <Badge kind="bad">Not verified</Badge>}</p>
            {p.company && <p style={{ fontSize: 13, color: 'var(--text-dim)', marginTop: 4 }}>{p.company} · {p.country || '—'}</p>}
          </div>
        </div>
      </div>

      <div className="split">
        <div className="card">
          <div className="card-title">🏢 Company details</div>
          <div className="card-sub">Shown to counterparties only after a controlled introduction</div>
          <div className="grid grid-2">
            {FIELDS.map((f) => (
              <div className="field-wrap" key={f.k}>
                <label className="field">{f.label}</label>
                <input className="input" value={p[f.k] || ''} onChange={(e) => setP({ ...p, [f.k]: e.target.value })} />
              </div>
            ))}
          </div>
          <button className="btn" onClick={save} disabled={busy}>Save profile</button>
        </div>

        <div className="card">
          <div className="card-title">🛡️ Verification & KYB</div>
          <div className="card-sub">Submit evidence to unlock transaction access (required for quotes, RFQs and introductions)</div>
          <label className="field">Evidence (links, registration numbers, certificates)</label>
          <textarea className="input" value={evidence} onChange={(e) => setEvidence(e.target.value)} placeholder={'e.g. https://company.com/registry \nNIB: 1234567890123 \nISO 9001 certificate ref…'} />
          <button className="btn" style={{ marginTop: 12 }} onClick={submitVerification} disabled={busy}>Submit for verification</button>
          <div style={{ marginTop: 16, fontSize: 12, color: 'var(--text-faint)' }}>
            Verification unlocks: RFQ creation, quote submission, introductions and trade execution.
          </div>
        </div>
      </div>
    </div>
  );
}
