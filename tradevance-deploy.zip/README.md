# 🌐 Tradevance — AI-Powered Global Trade Network

Platform jaringan perdagangan global bertenaga AI: **demand intelligence, supplier matching, risk engine, live market data, dan governed trade execution** — dengan **16 modul AI** dan **6 AI agents**. Build dari rekonstruksi penuh (frontend + backend + database + AI engine) yang **deploy-ready untuk Vercel**.

---

## ✨ Fitur AI (16 modul)

| # | Modul | Keterangan |
|---|-------|-----------|
| 1 | **AI Demand Intake** | Parse permintaan natural-language → RFQ terstruktur (96% akurasi) |
| 2 | **AI Matching** | Scoring supplier multi-faktor: fit · trust · risk · commercial |
| 3 | **Risk Engine** | Gating transaksi: ALLOW / REVIEW / BLOCK + alasan eksplisit |
| 4 | **Sanctions Screening** | Pre-screen OFAC, UNSC, UK, EU — gratis, tanpa key |
| 5 | **Quote Normalization** | Normalisasi + negosiasi quote ke landed cost (CIF/FOB) |
| 6 | **Negotiation Strategy** | Draft counter-position dalam mandate yang disetujui |
| 7 | **Decision Mesh** | Kartu keputusan per opportunity (operator) |
| 8 | **Predictive Alerts** | Slippage deal, gap verifikasi, decay opportunity |
| 9 | **Opportunity Autopilot** | Scoring background setiap demand vs supply |
| 10 | **Trade Room** | Deal room governed: strategi, approval, event log, learning |
| 11 | **6 AI Agents** | Opportunity, Buyer/Supplier Intel, Verification, Commercial, Negotiation, Compliance |
| 12 | **Trade Memory** | Pola dari record yang dipersist & disetujui manusia |
| 13 | **Trade Copilot** | Jawaban grounded pada dataset live + evidence |
| 14 | **What-if Analyzer** | Simulasi delta freight/price/risk → skor opportunity |
| 15 | **Growth Advisor** | Analisis funnel, segmentasi, kualitas RFQ (operator) |
| 16 | **Data Fabric / Admin Intel** | Inventori data, verifikasi queue, funnel, revenue signals |

**Data riil terhubung (tanpa API key):**
- 💱 **ECB FX LIVE** — kurs harian via Frankfurter (USD → IDR, EUR, CNY, dst.)
- 🌐 **UN Comtrade** — arus perdagangan Indonesia (reporter 360) via public API
- 📊 **World Bank** — indikator negara
- Semua dengan **fallback deterministik** jika API tidak terjangkau.

---

## 🏗️ Struktur Project

```
tradevance/
├── api/index.js          # Vercel serverless entry (wraps Express app)
├── app.js                # Express server — 56 route API + static serving
├── src/
│   ├── tradevance.ts     # ⚙️ CORE ENGINE: DB adapter, AI services, real-data connectors
│   └── core.mjs          # (generated) engine bundle untuk Node — npm run build:core
├── web/                  # Frontend React 19 + Vite + TypeScript
│   ├── index.html
│   ├── vite.config.ts
│   ├── tsconfig.json
│   └── src/
│       ├── main.tsx      # Entry React
│       ├── App.tsx       # 14 halaman/modul UI
│       ├── styles.css    # Design system
│       ├── ui.tsx        # Komponen bersama (Stat, Badge, ScoreBar, Toast…)
│       └── lib/
│           ├── api.ts          # API client: coba server dulu, fallback engine browser
│           └── tradevance.ts   # Engine AI (salinan untuk browser bundle)
├── vercel.json           # Konfigurasi deploy Vercel
├── package.json          # Build: esbuild engine + vite frontend
├── .env.example          # Template environment variables
├── .gitignore
└── README.md
```

**Cara kerja dual-mode:** `api.ts` mencoba server API (`/api/health`) terlebih dahulu. Jika server tidak terjangkau (static hosting murni), frontend otomatis jatuh ke **engine AI mandiri di browser** (localStorage DB + AI deterministik + konektor data riil) — jadi aplikasi **tetap berfungsi penuh bahkan tanpa backend**.

---

## 🚀 Deploy ke Vercel

### Opsi A — Import dari GitHub (disarankan)

1. Push project ini ke GitHub (lihat langkah di bawah).
2. Buka [vercel.com](https://vercel.com) → **Add New… → Project** → pilih repo `tradevance`.
3. Vercel mendeteksi konfigurasi otomatis dari `vercel.json` (build: `npm run build`, output: `web/dist`).
4. Tambahkan environment variables dari `.env.example` (semua opsional):
   - `LLM_API_KEY`, `LLM_BASE_URL`, `LLM_MODEL` — AI generatif premium (opsional)
   - `STRIPE_SECRET_KEY`, `XENDIT_SECRET_KEY` — payment (opsional)
   - `OPENSANCTIONS_API_KEY`, `KYB_PROVIDER_API_KEY` — compliance lanjutan (opsional)
   - `UN_COMITRADE_API_KEY` — kuota Comtrade lebih tinggi (opsional)
5. Klik **Deploy**. Selesai — platform live dengan serverless API + frontend statis.

### Opsi B — Vercel CLI

```bash
npm i -g vercel
vercel login
vercel --prod
```

---

## 💻 Development Lokal

```bash
npm install
npm run build:core   # compile engine → src/core.mjs
npm run dev          # Vite dev server (proxy /api → localhost:8787)

# Terminal 2 — API server lengkap:
npm run build:core && node app.js   # Express di PORT=8787 (default)
```

Atau jalankan produksi sekaligus:

```bash
npm run build        # core engine + frontend bundle
npm start            # node app.js → serve web/dist + /api di :8787
```

Buka `http://localhost:8787`.

---

## 🔑 Environment Variables (semua opsional)

Lihat `.env.example` untuk komentar lengkap. Ringkasnya:

| Variable | Fungsi | Wajib? |
|----------|--------|--------|
| `PORT` | Port server Express (default 8787) | Tidak |
| `LLM_API_KEY` | LLM OpenAI-compatible untuk Copilot/agents premium | Tidak |
| `LLM_BASE_URL` / `LLM_MODEL` | Endpoint & model LLM | Tidak |
| `STRIPE_SECRET_KEY` | Stripe payment | Tidak |
| `XENDIT_SECRET_KEY` | Xendit payment (ID/SEA) | Tidak |
| `OPENSANCTIONS_API_KEY` | Sanctions data lanjutan | Tidak |
| `KYB_PROVIDER_API_KEY` | KYB provider (Sumsub, dll.) | Tidak |
| `UN_COMITRADE_API_KEY` | Kuota UN Comtrade lebih tinggi | Tidak |

> **Tanpa satu pun key, semua fitur inti tetap berjalan** — deterministik AI engine + data publik (ECB FX, UN Comtrade) sudah aktif.

---

## 🐙 Push ke GitHub

Repo tujuan: **https://github.com/yusufstmrg/tradevance**

```bash
# 1. Inisialisasi (sudah dilakukan di sandbox — ulangi jika perlu)
git init
git branch -M main

# 2. Commit semua file
git add .
git commit -m "Initial commit: Tradevance AI deploy-ready project"

# 3. Hubungkan remote
git remote add origin https://github.com/yusufstmrg/tradevance.git

# 4. Push (akan diminta kredensial GitHub)
git push -u origin main
```

> 💡 Jika repo sudah memiliki riwayat, gunakan `git pull origin main --rebase` sebelum push, atau force-push hanya jika yakin: `git push -u origin main --force`.

---

## 🛡️ Keamanan

- `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN` di semua respons (vercel.json headers)
- Risk engine mengunci transaksi berisiko (HTTP 423) sebelum eksekusi
- Kontak pihak lawan **dilindungi** — semua koneksi lewat controlled introduction (periode proteksi 24 bulan)
- Audit trail di setiap aksi penting (introduction, approval, agent run, advance trade)
- Sanctions screening aktif secara default pada level entitas

---

## 📄 Lisensi & Catatan

Tradevance v2.0.0 — dibangun untuk Yusuf B. Situmorang. Frontend React 19 · Express · TypeScript · Vite · Tailwind-style design system. Data pasar bersumber dari ECB (Frankfurter) dan UN Comtrade (public API).
